from abc import abstractmethod


class FlowExtension:
    """
    流程扩展节点接口, 该接口定义了流程扩展节点的基本行为
    """

    @abstractmethod
    def id(self) -> str:
        """
        流程扩展节点标识. 要求该标识在平台中唯一
        :return: 节点标识
        """
        pass

    @abstractmethod
    def name(self) -> str:
        """
        流程扩展节点名称
        :return: 节点名称
        """
        pass

    @abstractmethod
    def start(self):
        """
        流程扩展节点启动时执行的动作, 该方法会在节点启动时被调用, 可以在该方法中执行一些初始化操作
        :return:
        """
        pass

    @abstractmethod
    def stop(self):
        """"
        流程扩展节点停止时执行的动作, 该方法会在节点停止时被调用, 可以在该方法中执行一些清理操作
        """
        pass

    @abstractmethod
    async def schema(self) -> str:
        """
        获取流程扩展节点的 schema, 该方法会在节点被调用时被调用, 该方法必须是异步方法
        :return: schema 内容
        """
        pass

    @abstractmethod
    async def run(self, params: dict) -> dict:
        """
        处理流程扩展节点的请求, 该方法会在节点被调用时被调用, 该方法必须是异步方法
        :param params: 请求参数. 参数内容由  schema 定义
        :return: 执行结果
        """
        pass
