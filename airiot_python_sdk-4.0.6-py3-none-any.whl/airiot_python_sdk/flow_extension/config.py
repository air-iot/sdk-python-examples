class FlowExtensionConfig:
    """
    流程扩展节点配置

    Attributes:
        host: 流程引擎服务地址
        port: 流程引擎服务端口
        health_check_interval: 心跳检测间隔, 单位: s. 默认: 30s
    """

    # 流程引擎服务地址
    host: str = "flow-engine"
    # 流程引擎服务端口
    port: int = 2333
    # 心跳检测间隔, 单位: s
    health_check_interval: int = 30

    def __str__(self):
        return "FlowExtensionConfig(host={}, port={}, health_check_interval={})".format(
            self.host, self.port, self.health_check_interval
        )
