import asyncio
import json
import logging
import traceback
from typing import Optional, Callable

import grpc
import jsons
from grpc.aio import Metadata, StreamStreamCall

from airiot_python_sdk.flow_extension import FlowExtension
from airiot_python_sdk.flow_extension.config import FlowExtensionConfig
from airiot_python_sdk.flow_extension.protos.engine_pb2 import ExtensionRunRequest, ExtensionResult, \
    ExtensionHealthCheckRequest, ExtensionHealthCheckResponse
from airiot_python_sdk.flow_extension.protos.engine_pb2_grpc import ExtensionServiceStub

logger = logging.getLogger("flow_extension_launcher")


class FlowExtensionLauncher:
    """
    流程扩展节点启动器
    """

    json_encoder = json.JSONEncoder()

    config: FlowExtensionConfig
    extension: FlowExtension

    servicer: ExtensionServiceStub
    channel: Optional[grpc.aio.Channel]

    schema_stream: Optional[StreamStreamCall]
    run_stream: Optional[StreamStreamCall]

    running: bool = False

    def __init__(self, config: FlowExtensionConfig, extension: FlowExtension):
        self.config = config
        self.channel = None
        self.extension = extension
        self.register_stream = None
        self.stop_request_fired = asyncio.Event()

    async def start(self):
        """
        启动流程插件
        :return:
        """

        if self.running:
            return

        self.running = True

        logger.info("start extension: id=%s, name = %s", self.extension.id(), self.extension.name())

        self.extension.start()

        # connect to flow_plugin engine
        await self.__connect__()

        # wait for stop signal
        try:
            await self.stop_request_fired.wait()
        except asyncio.CancelledError:
            pass

    async def stop(self):
        """
        停止流程扩展节点
        :return:
        """

        if not self.running:
            return

        logger.info("stopping extension")

        self.running = False

        # call plugin stop callback
        self.extension.stop()

        if self.register_stream is not None:
            self.register_stream.cancel()

        # close grpc channel
        if self.channel is not None:
            await self.channel.close(grace=5)

        # send stop signal
        self.stop_request_fired.set()

        logger.info("extension stopped")

    async def __connect__(self):
        # 如果已经停止则不再重连
        if not self.running:
            return

        # 关闭现有的 channel
        if self.channel is not None:
            await self.channel.close(grace=5)

        # connect to flow_plugin engine
        await self.__connect_grpc__()

        # create all streams
        self.__create_streams__()

    async def __connect_grpc__(self):
        """
        连接到流程引擎的gRPC服务
        :return:
        """

        logger.info("start to connect flow_plugin engine: grpc://%s:%d", self.config.host, self.config.port)

        self.channel = grpc.aio.insecure_channel("{}:{}".format(self.config.host, self.config.port))
        self.servicer = ExtensionServiceStub(self.channel)

        await self.channel.channel_ready()

        logger.info("connected to flow_plugin engine: grpc://%s:%d", self.config.host, self.config.port)

    def __create_streams__(self):
        logger.info("start to create streams")

        loop = asyncio.get_event_loop()

        tasks = [loop.create_task(self.__schema__()),
                 loop.create_task(self.__run__()),
                 loop.create_task(self.__health_check__(self.__connect__))
                 ]

        asyncio.gather(*tasks, return_exceptions=True)

    def __grpc_metadata__(self) -> Metadata:
        metadata = Metadata()
        metadata.add("id", self.extension.id().encode("utf-8").hex())
        metadata.add("name", self.extension.name().encode("utf-8").hex())
        return metadata

    async def __schema__(self):
        metadata = self.__grpc_metadata__()
        self.schema_stream = self.servicer.SchemaStream(metadata=metadata)
        logger.info("flow_plugin extension schema stream start successfully, start to receive requests")

        async for request in self.schema_stream:
            if request == grpc.aio.EOF:
                logger.info("schema stream closed")
                break
            try:
                schema = await self.extension.schema()
                await self.schema_stream.write(
                    ExtensionResult(request=request.request, status=True, result=schema.encode("utf-8")))
            except Exception as e:
                logger.error("获取 schema 异常, request=%s, exception=%s", request.request, e)
                traceback.print_exception(e)
                await self.schema_stream.write(
                    ExtensionResult(request=request.request, status=False, info="", detail=f"{e}"))

    async def __run__(self):
        metadata = self.__grpc_metadata__()
        self.run_stream = self.servicer.RunStream(metadata=metadata)
        logger.info("flow_plugin extension run stream start successfully, start to receive requests")

        async for request in self.run_stream:
            if request == grpc.aio.EOF:
                logger.info("run stream closed")
                break

            response = await self.__handle_request__(request)
            await self.run_stream.write(response)

    async def __handle_request__(self, request: ExtensionRunRequest) -> ExtensionResult:
        if logger.isEnabledFor(logging.DEBUG):
            logger.debug("收到请求, request=%s, data=%s", request.request, request.data.decode("utf-8"))

        try:
            result = await self.extension.run(jsons.loads(request.data.decode("utf-8")))

            logger.debug("执行结果, request=%s, result=%s", request.request, result)

            return ExtensionResult(request=request.request, status=True, result=jsons.dumps(result).encode("utf-8"))
        except Exception as e:
            traceback.print_stack()
            logger.error("执行异常, request=%s, data=%s, exception=%s",
                         request.request, request.data.decode("utf-8"), e)
            return ExtensionResult(request=request.request, status=False, info="执行异常", detail=f"{e}")

    async def __health_check__(self, reconnect: Callable):
        """
        健康检查
        :param reconnect: 重连方法
        :return:
        """

        id = self.extension.id()
        interval = 30 if self.config.health_check_interval <= 0 else self.config.health_check_interval

        logger.info("start health check, id = %s, name = %s, interval = %d", id, self.extension.name(), interval)

        while self.running:
            try:
                tasks = asyncio.as_completed([
                    asyncio.sleep(interval),
                    self.stop_request_fired.wait()
                ])

                for task in tasks:
                    await task
                    break

                if not self.running:
                    break

                logger.info("send health check request, id = %s", id)
                response: ExtensionHealthCheckResponse = await self.servicer.HealthCheck(
                    ExtensionHealthCheckRequest(id=id), timeout=5)

                if response.status == ExtensionHealthCheckResponse.SERVING:
                    logger.info("health check success, id = %s", id)
                else:
                    logger.error("health check failed, id = %s, status = %d", id, response.status)
                    break
            except Exception as e:
                traceback.print_exception(e)
                logger.error("health check exception, id = %s, exception = %s", id, e)
                break
        # 心跳检测失败, 重连
        await reconnect()
