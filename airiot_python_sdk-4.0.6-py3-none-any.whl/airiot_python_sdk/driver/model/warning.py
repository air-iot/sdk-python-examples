import dataclasses
import uuid
from dataclasses import dataclass
from datetime import datetime, timezone
from enum import Enum
from typing import List, Optional

from airiot_python_sdk.driver.model.tag import Tag


class WarningStatus(Enum):
    confirmed = "已确认"
    unconfirmed = "未确认"


class WarningProcessed(Enum):
    processed = "已处理"
    unprocessed = "未处理"


@dataclass
class Table:
    id: str

    def __str__(self):
        return f"Table{{id='{self.id}'}}"


@dataclass
class TableData:
    id: str

    def __str__(self):
        return f"TableData{{id='{self.id}'}}"


@dataclass
class WarningField:
    """
    报警关联的数据点信息

    Attributes:
    :param id: 数据点标识
    :param name: 数据点名称
    :param value: 报警时或报警恢复时的值
    """

    def __init__(self, id: str, value, name: Optional[str] = None):
        self.id = id
        self.name = name
        self.value = value


@dataclass
class WarningData:
    id: str
    table: Table
    tableData: TableData
    level: str
    ruleid: str
    fields: List[WarningField]
    type: List[str]
    processed: str
    status: str
    time: datetime
    alert: bool
    handle: bool
    desc: str

    def __str__(self):
        return (
            f"Warning{{id='{self.id}', table={self.table}, table_data={self.tableData}, "
            f"level='{self.level}', ruleid='{self.ruleid}', fields={self.fields}, "
            f"type={self.type}, processed='{self.processed}', status='{self.status}', "
            f"time={self.time}, alert={self.alert}, handle={self.handle}, desc='{self.desc}'}}"
        )


def _validate_text(value, message):
    if not value:
        raise ValueError(message)


def _validate_not_empty(value, message):
    if not value:
        raise ValueError(message)


class WarningBuilder:
    id: str
    table_id: str
    table_dat_id: str
    level: str
    rule_id: str
    fields: List[WarningField]
    warning_types: List[str]
    processed: str
    status: str
    alert: bool
    handle: bool
    description: str

    def __init__(self):
        self.id = uuid.uuid4().hex.replace("-", "")
        self.table_id = ""
        self.table_data_id = ""
        self.rule_id = ""
        self.level = ""
        self.fields = []
        self.warning_types = []
        self.processed = WarningProcessed.unprocessed.value
        self.status = WarningStatus.unconfirmed.value
        self.time = datetime.now(timezone.utc)
        self.alert = True
        self.handle = True

    def set_id(self, id: str):
        _validate_text(id, "报警ID不能为空")
        self.id = id
        return self

    def set_table_id(self, table_id: str):
        _validate_text(table_id, "报警所属表标识不能为空")
        self.table_id = table_id
        return self

    def set_device_id(self, device_id: str):
        _validate_text(device_id, "产生报警设备的标识不能为空")
        self.table_data_id = device_id
        return self

    def set_level(self, level: str):
        _validate_text(level, "报警等级不能为空")
        self.level = level
        return self

    def set_rule_id(self, rule_id: str):
        _validate_text(rule_id, "报警规则ID不能为空")
        self.rule_id = rule_id
        return self

    def set_time(self, time: datetime):
        if time is None:
            raise ValueError("报警产生的时间不能为空")
        self.time = time
        return self

    def set_alert(self, alert: bool):
        self.alert = alert
        return self

    def disable_alert(self):
        self.alert = False
        return self

    def set_handle(self, handle: bool):
        self.handle = handle
        return self

    def disable_handle(self):
        self.handle = False
        return self

    def set_warning_types(self, warning_types: List[str]):
        _validate_not_empty(warning_types, "报警类型不能为空")
        if any(not w for w in warning_types):
            raise ValueError("报警类型不能为空")
        self.warning_types = warning_types
        return self

    def set_processed(self, processed: WarningProcessed):
        _validate_not_empty(processed, "报警的处理状态不能为空")
        self.processed = processed.value
        return self

    def set_status(self, status: WarningStatus):
        _validate_not_empty(status, "报警的确认状态不能为空")
        self.status = status.value
        return self

    def set_field(self, tag: Tag, value: any):
        _validate_not_empty(tag, "报警关联的数据点信息不能为空")
        _validate_text(tag.id, "报警关联的数据点 ID 不能为空")
        self.fields.append(WarningField(tag.id, tag.name, value))
        return self

    def set_field_with_default_name(self, id: str, value: any):
        return self.fields.append(WarningField(id, value, None))

    def set_fields(self, fields: list[WarningField]):
        for field in fields:
            if not field:
                raise ValueError("报警关联的数据点信息不能为空")
            self.fields.append(field)
        return self

    def set_fields_varargs(self, *fields):
        for field in fields:
            if not field:
                raise ValueError("报警关联的数据点信息不能为空")
            self.fields.append(field)
        return self

    def set_description(self, description: str):
        self.description = description
        return self

    def build(self) -> WarningData:
        _validate_text(self.table_id, "报警设备所属表标识不能为空")
        _validate_text(self.table_data_id, "报警设备的编号不能为空")
        _validate_text(self.level, "报警等级不能为空")
        _validate_text(self.rule_id, "报警规则ID不能为空")
        _validate_not_empty(self.warning_types, "报警类型不能为空")
        _validate_text(self.description, "报警描述信息不能为空")

        warning = WarningData
        warning.id = self.id if self.id else str(uuid.uuid4()).replace("-", "")
        warning.table = Table(self.table_id)
        warning.tableData = TableData(self.table_data_id)
        warning.level = self.level
        warning.ruleid = self.rule_id
        warning.fields = self.fields
        warning.type = self.warning_types
        warning.processed = self.processed
        warning.status = self.status
        warning.time = self.time
        warning.alert = self.alert
        warning.handle = self.handle
        warning.desc = self.description

        return warning


@dataclasses.dataclass
class WarningRecoveryData:
    def __init__(self, time, fields: List[WarningField]):
        self.recoveryTime = time
        self.recoveryFields = fields

    def __str__(self):
        return f"WarnRecoveryData{{recoveryTime={self.recoveryTime}, recoveryFields={self.recoveryFields}}}"


@dataclasses.dataclass
class WarningRecovery:
    def __init__(self, id: list[str], data: WarningRecoveryData):
        self.id = id
        self.data = data

    def __str__(self):
        return f"WarningRecovery{{id={self.id}, data={self.data}}}"
