import math
from _decimal import Decimal

from . import DataHandler, tag_value_cache
from ..model.tag import Tag, Range


class InvalidRangeValueDataHandler(DataHandler):
    """
    无效范围值
    """

    def name(self) -> str:
        return "无效范围值"

    def support(self, table_id: str, device_id: str, tag: Tag, value: any) -> bool:
        if tag is None or value is None:
            return False

        if tag.range is None:
            return False

        if not isinstance(value, int) and not isinstance(value, float):
            return False

        range_value: Range = tag.range
        if range_value.method != "invalid":
            return False

        # 未添加任何有效范围条件时, 不进行处理
        if range_value.conditions is None or len(range_value.conditions) == 0:
            return False

        # 如果有任何一个条件不正确, 则不进行处理
        for condition in range_value.conditions:
            if not condition.is_ok():
                return False

        return True

    async def handle(self, table_id: str, device_id: str, tag: Tag, value: any) -> dict[str, any]:
        if math.isnan(value) or math.isinf(value):
            return {}

        val = Decimal.from_float(value)

        # 缓存值
        cache_value = await tag_value_cache.get(table_id, device_id, tag.id)

        ok = True
        invalid_condition = None

        range_config = tag.range
        for condition in range_config.conditions:
            # 如果任意一个条件匹配, 则表示该数据无效
            if condition.matched(val, cache_value):
                ok = False
                invalid_condition = condition
                break

        if ok:
            return {tag.id: value}

        valid_val = None
        if range_config.active == "fixedValue":
            valid_val = range_config.fixedValue
        elif range_config.active == "latest":
            valid_val = cache_value

        values = {
            "{}__invalid__type".format(tag.id): invalid_condition.invalidType
        }

        # 如果设置了保存无效值
        if range_config.invalidAction == "save":
            values["{}__invalid".format(tag.id)] = value

        # 计算最终值
        if valid_val is not None:
            values[tag.id] = valid_val

        return values

    def order(self) -> int:
        return 201
