import math
from _decimal import Decimal

from airiot_python_sdk.driver.handler import DataHandler
from airiot_python_sdk.driver.model.tag import Tag


class RoundAndScaleDataHandler(DataHandler):
    """
    数值缩放及保留小数位数. 将采集到的数据 * 缩放比例(mod), 然后再保留小数位数(fixed).
    如果 mod 为 None, 则不进行缩放, 如果 fixed 为 None, 则不进行保留小数位数

    例如: 采集到的数值为 123456, 数据点设置的 mod 为 0.001, fixed 为 2, 则计算方式为:
        第1步: 123456 * 0.001 = 123.456
        第2步: 123.456 保留2位小数, 并四舍五入
        最终计算结果为: 123.46

    """

    def name(self) -> str:
        return "数值缩放及保留小数位数"

    def support(self, table_id: str, device_id: str, tag: Tag, value: any) -> bool:
        if tag is None or value is None:
            return False

        # 数据数据点的值不是数值类型时
        if not isinstance(value, int) and not isinstance(value, float):
            return False

        if tag.tagValue is None:
            return False

        # 如果 fixed 和 mod 都为 None, 则不进行处理
        if tag.fixed is None and tag.mod is None:
            return False

        return True

    async def handle(self, table_id: str, device_id: str, tag: Tag, value: any) -> dict[str, any]:
        if math.isnan(value) or math.isinf(value):
            return {}

        val = Decimal.from_float(value)

        # scale the value
        if tag.mod is not None:
            val = val * Decimal.from_float(tag.mod)

        if tag.fixed is not None and tag.fixed == 0:
            val = val.to_integral_value(rounding='ROUND_HALF_UP')
        elif tag.fixed is not None:
            val = val.quantize(Decimal("0." + ("0" * tag.fixed)), rounding='ROUND_HALF_UP')

        return {tag.id: float(val)}

    def order(self) -> int:
        return 100
