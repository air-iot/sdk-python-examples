import logging
from abc import abstractmethod
from typing import List, Optional

from .tag_value_cache import TagValueCache
from ..model.point import Point, SimplePoint
from ..model.tag import Tag

logger = logging.getLogger(name="data_handler_chain")

tag_value_cache = TagValueCache()


class DataHandler:
    """
        数据处理器, 用于处理驱动发送到平台的设备数据.
        向平台发送设备采集数据时, 每个数据点的值会经过一系列的数据处理器的处理, 然后将处理后的数据发送到平台.
    """

    @abstractmethod
    def name(self) -> str:
        """
        数据处理器名称
        :return: 处理器名称
        """

    @abstractmethod
    def support(self, table_id: str, device_id: str, tag: Tag, value: any) -> bool:
        """
        判断该数据处理器是否支持处理该数据

        :param table_id: 设备所属工作表标识
        :param device_id: 设备编号
        :param tag: 数据点信息
        :param value: 数据点值
        :return: 如果支持处理该数据则返回 True, 否则返回 False
        """

    @abstractmethod
    async def handle(self, table_id: str, device_id: str, tag: Tag, value: any) -> dict[str, any]:
        """
        处理数据. 如果需要丢弃该数据时, 返回 dict 不包含任何该数据点标识的数据即可. 同时, 可以增加额外的数据

        :param table_id: 设备所属工作表标识
        :param device_id: 设备编号
        :param tag: 数据点信息
        :param value: 数据点值
        :return: 处理结果. 字典, key 为数据点标识, value 为处理后的数据点值
        """

    @abstractmethod
    def order(self) -> int:
        """
        获取该数据处理器的优先级. 值越小, 优先级越高.
        在向平台发送设备采集数据时, 每个数据点的数据处理器都会被调用, 优先级高的数据处理器会先被调用.

        :return: 优先级
        """


class DataHandlerChain:
    """
    数据处理器链, 用于对设备采集到的数据进行处理.
    将驱动发送到平台的设备数据交给该链进行处理, 该链会按照处理器的顺序依次处理数据, 直到所有处理器都处理完毕, 并返回最终的处理结果.
    """

    # 数据处理器列表
    handlers: List[DataHandler]

    def __init__(self, handlers: List[DataHandler]):
        self.handlers = handlers
        self.handlers.sort(key=lambda handler: handler.order())

    async def __handle__(self, table_id: str, device_id: str, tag: Tag, value: any) -> Optional[dict[str, any]]:
        """
        处理数据点的数据.

        :param table_id: 设备所属工作表标识
        :param device_id: 设备编号
        :param tag: 数据点信息
        :param value: 数据点值
        :return: 处理结果. 字典, key 为数据点标识, value 为处理后的数据点值. 如果该数据点的数据被丢弃, 则返回 None
        """

        final_value = {tag.id: value}
        if len(self.handlers) == 0:
            return final_value

        log_extra = {"table": table_id, "device": device_id, "tag": tag.id}

        for handler in self.handlers:
            tag_value = final_value.get(tag.id)
            logger.debug("数据处理器[%s]: %s", handler.name(), tag_value, extra=log_extra)
            if not handler.support(table_id, device_id, tag, tag_value):
                logger.debug("数据处理器[%s]: 不支持处理该数据点, 跳过该处理器", handler.name(), extra=log_extra)
                continue

            new_value = await handler.handle(table_id, device_id, tag, tag_value)
            if new_value is None:
                logger.debug("数据处理器[%s]: 返回 None", handler.name(), extra=log_extra)
                continue

            logger.debug("数据处理器[%s]: 处理结果 %s", handler.name(), new_value, extra=log_extra)

            # 合并处理结果
            final_value.update(new_value)
            if new_value.get(tag.id) is None:
                # 如果该处理器未返回该数据点的数据, 则认为该数据点的数据被丢弃
                logger.debug("数据处理器[%s]: 未返回该数据点的值, 丢弃数据点的数据", handler.name(),
                             extra=log_extra)
                final_value.pop(tag.id)

        # 缓冲最新有效值
        if tag.id in final_value:
            await tag_value_cache.set_value(table_id, device_id, tag.id, final_value[tag.id])

        return final_value

    async def handle(self, point: Point) -> Optional[SimplePoint]:
        """
        处理数据驱动发送到平台的设备数据
        :param point: 设备数据
        :return: 处理后的设备数据. 如果发送的数据无效, 或所有数据点的数据都被丢弃, 则返回 None
        """

        log_extra = {"table": point.table, "device": point.id}

        if point.fields is None or len(point.fields) == 0:
            logger.debug("未定义任何数据点信息, %s", point, extra=log_extra)
            return None

        new_fields = {}
        for field in point.fields:
            if field is None or field.tag is None:
                logger.warning("字段信息或数据点信息为空, %s", point, extra=log_extra)
                continue

            new_value = await self.__handle__(point.table, point.id, field.tag, field.value)
            if new_value is None or len(new_value) == 0:
                logger.info("数据点[%s]的处理结果为 None, 原始值: %s", field.tag.id, field.value, extra=log_extra)
                continue

            new_fields.update(new_value)
            logger.debug("数据点[%s]的最终处理结果 %s", field.tag.id, new_value, extra=log_extra)

        if len(new_fields) == 0:
            logger.warning("所有数据点的数据都被丢弃, %s", point, extra=log_extra)
            return None

        return SimplePoint(point.table, point.id, new_fields, cid=point.cid, time=point.time,
                           field_types=point.fieldTypes)
