from . import DataHandler
from ..model.tag import Tag


class BooleanToIntegerDataHandler(DataHandler):
    """
    布尔值转换为整数. 如果布尔值为 True, 则转换为 1, 否则转换为 0
    """

    def name(self) -> str:
        return "布尔值转换为整数"

    def support(self, table_id: str, device_id: str, tag: Tag, value: any) -> bool:
        if tag is None or value is None:
            return False
        # 数据点的值为布尔值
        return isinstance(value, bool)

    async def handle(self, table_id: str, device_id: str, tag: Tag, value: any) -> dict[str, any]:
        if value is True:
            return {tag.id: 1}
        else:
            return {tag.id: 0}

    def order(self) -> int:
        return 1000
