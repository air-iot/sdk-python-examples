import json
from abc import abstractmethod

from airiot_python_sdk.driver.handler import DataHandlerChain
from airiot_python_sdk.driver.model import Response, ok, fail
from airiot_python_sdk.driver.model.event import Event
from airiot_python_sdk.driver.model.log import RunLog
from airiot_python_sdk.driver.model.point import Point, SimplePoint
from airiot_python_sdk.driver.model.warning import WarningRecovery, WarningData
from airiot_python_sdk.driver.protos.driver_pb2 import Request, Response as GrpcResponse
from airiot_python_sdk.driver.protos.driver_pb2_grpc import DriverService


class DataSender:
    """
    数据发送器, 用于向平台发送数据
    """

    json_encoder = json.JSONEncoder()

    # 项目ID
    project_id: str
    # 驱动ID
    driver_id: str
    # 驱动名称
    driver_name: str
    # 驱动实例ID
    service_id: str

    # 数据处理器链
    handler_chain: DataHandlerChain
    # driver listener client
    driver_servicer: DriverService

    def __init__(self, project_id: str, driver_id: str, driver_name: str, service_id: str, chain: DataHandlerChain):
        self.project_id = project_id
        self.driver_id = driver_id
        self.driver_name = driver_name
        self.service_id = service_id
        self.handler_chain = chain

    @abstractmethod
    def start(self):
        """
        启动数据发送器
        :return:
        """
        pass

    @abstractmethod
    def stop(self):
        """
        停止数据发送器
        :return:
        """
        pass

    async def write_point(self, point: Point):
        """
        向平台发送设备采集到的数据
        :param point: 设备采集到的数据
        :return:
        :raise ValueError: point is None
        """

        if point is None:
            raise ValueError("point is None")

        result = await self.handler_chain.handle(point)
        if result is None:
            return

        self.__write_point__(result)

    def write_event(self, event: Event) -> Response:
        """
        向平台发送事件信息
        :param event: 事件信息
        :return: 事件发送结果
        :raises ValueError: event is None
        """

        if event is None:
            raise ValueError("event is None")

        req = Request()
        req.project = self.project_id
        req.data = self.json_encoder.encode(event)
        resp: GrpcResponse = self.driver_servicer.Event()

        if resp.status:
            return ok(resp.info, resp.detail)

        return fail(resp.code, resp.info, resp.detail)

    def update_table_data(self, table_id: str, device_id: str, fields: dict[str, any]) -> Response:
        """
        更新设备数据
        :param table_id: 设备所属工作表标识
        :param device_id: 设备编号
        :param fields: 更新的字段信息. key 为字段名, value 为字段值.
        :return: 设备信息修改结果
        :raise ValueError: the table_id, device_id or fields is None or empty
        """

        if table_id is None or table_id.strip() == "":
            raise ValueError("table_id is None or empty")

        if device_id is None or device_id.strip() == "":
            raise ValueError("device_id is None or empty")

        if fields is None or len(fields) == 0:
            raise ValueError("fields is None or empty")

        req = Request()
        req.project = self.project_id
        req.data = self.json_encoder.encode({"table": table_id, "id": device_id, "fields": fields})

        resp: GrpcResponse = self.driver_servicer.UpdateTableData(req)
        if resp.status:
            return ok(resp.info, resp.detail)

        return fail(resp.code, resp.info, resp.detail)

    def write_run_log(self, log: RunLog) -> Response:
        """
        向平台发送指令执行日志
        :param log: 执行日志
        :return: 日志发送结果
        :raise ValueError: log is None
        """

        if log is None:
            raise ValueError("log is None")

        req = Request()
        req.project = self.project_id
        req.data = self.json_encoder.encode(log)
        resp: GrpcResponse = self.driver_servicer.Event(req)

        if resp.status:
            return ok(resp.info, resp.detail)

        return fail(resp.code, resp.info, resp.detail)

    def log_debug(self, table_id: str, device_id: str, message: str):
        """
        发送 DEBUG 日志. 该日志信息可以在 "设备配置" 中的 "设备调试" 面板中查看.
        :param table_id: 设备所属工作表标识
        :param device_id: 设备编号
        :param message: 日志内容
        :return:
        """
        self.__log__("debug", table_id, device_id, message)

    def log_info(self, table_id: str, device_id: str, message: str):
        """
        发送 INFO 日志. 该日志信息可以在 "设备配置" 中的 "设备调试" 面板中查看.
        :param table_id: 设备所属工作表标识
        :param device_id: 设备编号
        :param message: 日志内容
        :return:
        """
        self.__log__("info", table_id, device_id, message)

    def log_warn(self, table_id: str, device_id: str, message: str):
        """
        发送 WARN 日志. 该日志信息可以在 "设备配置" 中的 "设备调试" 面板中查看.
        :param table_id: 设备所属工作表标识
        :param device_id: 设备编号
        :param message: 日志内容
        :return:
        """
        self.__log__("warn", table_id, device_id, message)

    def log_error(self, table_id: str, device_id: str, message: str):
        """
        发送 ERROR 日志. 该日志信息可以在 "设备配置" 中的 "设备调试" 面板中查看.
        :param table_id: 设备所属工作表标识
        :param device_id: 设备编号
        :param message: 日志内容
        :return:
        """
        self.__log__("error", table_id, device_id, message)

    @abstractmethod
    def __write_point__(self, point: SimplePoint):
        """
        向平台发送设备采集到的数据
        :param point: 处理后的设备采集到的数据
        :return:
        """

    @abstractmethod
    def __log__(self, level: str, table_id: str, device_id: str, message: str):
        """
        发送日志. 该日志信息可以在 "设备配置" 中的 "设备调试" 面板中查看.
        :param level: 日志级别. 可选值: debug, info, warn, error
        :param table_id: 设备所属工作表标识
        :param device_id: 设备编号
        :param message: 日志内容
        :return:
        """

    @abstractmethod
    def send_warning(self, warning: WarningData):
        """
        发送报警信息
        :param warning: 报警信息
        """
        pass

    @abstractmethod
    def send_warning_recovery(self, table_id: str, device_id: str, recovery: WarningRecovery):
        """
        发送报警恢复信息
        :param table_id 报警设备所属表标识
        :param device_id 报警设备标识
        :param recovery: 报警恢复信息
        """
