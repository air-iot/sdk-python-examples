import dataclasses
from typing import Collection, Optional

import jsons

# 常用日期格式化字符串
# 按分钟汇总
DATE_FORMAT_OF_MINUTE = "%Y-%m-%dT%H:%M:00"
# 按小时汇总
DATE_FORMAT_OF_HOUR = "%Y-%m-%dT%H:00:00"
# 按天汇总
DATE_FORMAT_OF_DAY = "%Y-%m-%d"
# 按周汇总
DATE_FORMAT_OF_WEEK = "%Y-%V"
# 按月汇总
DATE_FORMAT_OF_MONTH = "%Y-%m"
# 按年汇总
DATE_FORMAT_OF_YEAR = "%Y"


class AggregateBuilder:
    """
    聚合查询字段构造器. 例如: MAX(field) AS maxValue, SUM(field) AS countValue 等
    """

    def __init__(self, builder, field: str):
        if not field:
            raise ValueError("the aggregate 'field' cannot be null or empty")
        self.builder = builder
        self.field = field

    def op(self, op, alias: str = None) -> 'QueryBuilder':
        """
        自定义聚合操作
        :param op: 聚合操作. 例如: $max, $min, $avg, $sum 等
        :param alias:
        :return:
        """
        if alias is None:
            return self.builder.update_group_fields({self.field: {op: self.field}})
        else:
            return self.builder.update_group_fields({alias: {op: self.field}})

    def count(self, alias: str = None) -> 'QueryBuilder':
        """
        统计数量
        :param alias: 统计字段别名
        :return:
        """

        if alias:
            return self.op("$count", alias)
        else:
            return self.op("$count")

    def min(self, alias: str = None) -> 'QueryBuilder':
        """
        最小值
        :param alias: 统计字段别名
        :return:
        """
        if alias:
            return self.op("$min", alias)
        else:
            return self.op("$min")

    def max(self, alias: str = None) -> 'QueryBuilder':
        """
        最大值
        :param alias: 统计字段别名
        :return:
        """
        if alias:
            return self.op("$max", alias)
        else:
            return self.op("$max")

    def avg(self, alias: str = None) -> 'QueryBuilder':
        """
        平均值
        :param alias: 统计字段别名
        :return:
        """
        if alias:
            return self.op("$avg", alias)
        else:
            return self.op("$avg")

    def sum(self, alias: str = None) -> 'QueryBuilder':
        """
        求和
        :param alias: 统计字段别名
        :return:
        """
        if alias:
            return self.op("$sum", alias)
        else:
            return self.op("$sum")

    def first(self, alias: str = None) -> 'QueryBuilder':
        """
        取符合条件的第一个值
        :param alias: 统计字段别名
        :return:
        """
        if alias:
            return self.op("$first", alias)
        else:
            return self.op("$first")

    def last(self, alias: str = None) -> 'QueryBuilder':
        """
        取符合条件的最后一个值
        :param alias: 统计字段别名
        :return:
        """
        if alias:
            return self.op("$last", alias)
        else:
            return self.op("$last")


class FilterBuilder:
    """
    过滤条件构造器, 用于构造过滤条件
    """

    def __init__(self, builder, filters):
        """
        构造函数
        :param builder: 所属的查询构造器 QueryBuilder
        :param filters: 已添加的过滤条件. 后续添加的过滤条件将会追加到该对象中
        """
        self.builder = builder
        self.filters = filters

    def end(self) -> 'QueryBuilder':
        """
        完成过滤条件的构造, 返回所属的查询构造器 QueryBuilder. 当过滤条件构造完成后, 需要调用该方法返回所属的查询构造器
        :return:
        """
        return self.builder

    def eq(self, field: str, value) -> 'FilterBuilder':
        """
        相等过滤条件
        :param field: 字段名
        :param value: 字段值
        :return:
        """
        if not field:
            raise ValueError("Query: the field name of condition 'eq' cannot be empty")

        self.filters[field.strip()] = value
        return self

    def ne(self, field: str, value) -> 'FilterBuilder':
        """
        不相等过滤条件
        :param field: 字段名
        :param value: 字段值
        :return:
        """
        if not field:
            raise ValueError("Query: the field name of condition 'ne' cannot be empty")

        self.filters[field.strip()] = {"$ne": value}
        return self

    def in_(self, field: str, value: list) -> 'FilterBuilder':
        """
        包含过滤条件, 表示字段的值在指定的集合中. 例如: {"name": {"$in": ["张三", "李四"]}} 查询张三和李四的信息
        :param field: 字段名
        :param value: 字段值
        :return:
        """
        if not field:
            raise ValueError("Query: the field name of condition 'in' cannot be empty")

        if isinstance(value, Collection):
            value = list(value)

        self.filters[field.strip()] = {"$in": value}
        return self

    def not_in(self, field: str, values) -> 'FilterBuilder':
        """
        不包含过滤条件, 表示字段的值不在指定的集合中. 例如: {"name": {"$nin": ["张三", "李四"]}} 查询不姓张也不姓李的人
        :param field: 字段名
        :param values: 字段值
        :return:
        """
        if not field:
            raise ValueError("Query: the field name of condition 'not in' cannot be empty")

        self.filters[field.strip()] = {"$nin": values}
        return self

    def regex(self, field: str, regex) -> 'FilterBuilder':
        """
        正则表达式过滤条件, 与 SQL 中的 LIKE 类似. 例如: {"name": {"$regexp": "张"}} 查询所有姓张的人
        :param field: 字段名
        :param regex: 正则表达式
        :return:
        """
        if not field:
            raise ValueError("Query: the field name of condition 'regex' cannot be empty")
        if not regex:
            raise ValueError("Query: the regex expression of condition 'regex' cannot be empty")

        self.filters[field.strip()] = {"$regex": regex}
        return self

    def lt(self, field: str, value) -> 'FilterBuilder':
        """
        小于过滤条件. 例如: age < 20
        :param field: 字段名
        :param value: 字段值
        :return:
        """
        if not field:
            raise ValueError("Query: the field name of condition 'lt' cannot be empty")

        self.filters[field.strip()] = {"$lt": value}
        return self

    def lte(self, field: str, value) -> 'FilterBuilder':
        """
        小于等于过滤条件. 例如: age <= 20
        :param field: 字段名
        :param value: 字段值
        :return:
        """
        if not field:
            raise ValueError("Query: the field name of condition 'lte' cannot be empty")

        self.filters[field.strip()] = {"$lte": value}
        return self

    def gt(self, field: str, value) -> 'FilterBuilder':
        """
        大于过滤条件. 例如: age > 20
        :param field: 字段名
        :param value: 字段值
        :return:
        """
        if not field:
            raise ValueError("Query: the field name of condition 'gt' cannot be empty")

        self.filters[field.strip()] = {"$gt": value}
        return self

    def gte(self, field: str, value) -> 'FilterBuilder':
        """
        大于等于过滤条件. 例如: age >= 20
        :param field: 字段名
        :param value: 字段值
        :return:
        """
        if not field:
            raise ValueError("Query: the field name of condition 'gte' cannot be empty")

        self.filters[field.strip()] = {"$gte": value}
        return self

    def between(self, field: str, min_value, max_value) -> 'FilterBuilder':
        """
        区间过滤条件(注意: 该区间两边都是闭区间), 类似于 SQL 中的 between. 例如: 20 <= age <= 30
        :param field: 字段名
        :param min_value: 最小值
        :param max_value: 最大值
        :return:
        """
        if not field:
            raise ValueError("Query: the field name of condition 'between' cannot be empty")

        self.filters[field.strip()] = {"$gte": min_value, "$lte": max_value}
        return self

    def between_exclude_left(self, field: str, min_value, max_value) -> 'FilterBuilder':
        """
        区间过滤条件(注意: 该区间左边是开区间, 右边是闭区间). 例如: 20 < age <= 30
        :param field: 字段名
        :param min_value: 最小值(不包含该值)
        :param max_value: 最大值
        :return:
        """
        if not field:
            raise ValueError("Query: the field name of condition 'betweenExcludeLeft' cannot be empty")

        if min_value > max_value:
            raise ValueError(f"Query: the minValue '{min_value}' cannot be greater than maxValue '{max_value}'")

        self.filters[field.strip()] = {"$gt": min_value, "$lte": max_value}
        return self

    def between_exclude_right(self, field: str, min_value, max_value) -> 'FilterBuilder':
        """
        区间过滤条件(注意: 该区间左边是闭区间, 右边是开区间). 例如: 20 <= age < 30
        :param field: 字段名
        :param min_value: 最小值
        :param max_value: 最大值(不包含该值)
        :return:
        """
        if not field:
            raise ValueError("Query: the field name of condition 'betweenExcludeRight' cannot be empty")

        self.filters[field.strip()] = {"$gte": min_value, "$lt": max_value}
        return self

    def between_exclude_all(self, field: str, min_value, max_value) -> 'FilterBuilder':
        """
        区间过滤条件(注意: 该区间两边都是开区间). 例如: 20 < age < 30
        :param field: 字段名
        :param min_value: 最小值(不包含该值)
        :param max_value: 最大值(不包含该值)
        :return:
        """
        if not field:
            raise ValueError("Query: the field name of condition 'betweenExcludeAll' cannot be empty")

        self.filters[field.strip()] = {"$gt": min_value, "$lt": max_value}
        return self


class OrFilterBuilder:
    """
    or 过滤条件构造器, 用于构造过滤条件
    """

    def __init__(self, builder, filters: list[dict]):
        """
        构造函数
        :param builder: 所属的查询构造器 QueryBuilder
        :param filters: 已添加的过滤条件. 后续添加的过滤条件将会追加到该对象中
        """
        self.builder = builder
        self.filters = filters

    def end(self) -> 'QueryBuilder':
        """
        完成过滤条件的构造, 返回所属的查询构造器 QueryBuilder. 当过滤条件构造完成后, 需要调用该方法返回所属的查询构造器
        :return:
        """
        return self.builder

    def eq(self, field: str, value) -> 'OrFilterBuilder':
        """
        相等过滤条件
        :param field: 字段名
        :param value: 字段值
        :return:
        """
        if not field:
            raise ValueError("Query: the field name of condition 'eq' cannot be empty")

        fv = next((x for x in self.filters if field in x), None)
        if not fv:
            self.filters.append({field: value})
        else:
            fv[field] = value
        return self

    def ne(self, field: str, value) -> 'OrFilterBuilder':
        """
        不相等过滤条件
        :param field: 字段名
        :param value: 字段值
        :return:
        """
        if not field:
            raise ValueError("Query: the field name of condition 'ne' cannot be empty")

        fv = next((x for x in self.filters if field in x), None)
        if not fv:
            self.filters.append({field: {"$ne": value}})
        else:
            fv[field] = {"$ne": value}
        return self

    def in_(self, field: str, value: list) -> 'OrFilterBuilder':
        """
        包含过滤条件, 表示字段的值在指定的集合中. 例如: {"name": {"$in": ["张三", "李四"]}} 查询张三和李四的信息
        :param field: 字段名
        :param value: 字段值
        :return:
        """
        if not field:
            raise ValueError("Query: the field name of condition 'in' cannot be empty")

        if isinstance(value, Collection):
            value = list(value)

        self.filters.append({field: {"$in": value}})
        return self

    def not_in(self, field: str, values) -> 'OrFilterBuilder':
        """
        不包含过滤条件, 表示字段的值不在指定的集合中. 例如: {"name": {"$nin": ["张三", "李四"]}} 查询不姓张也不姓李的人
        :param field: 字段名
        :param values: 字段值
        :return:
        """
        if not field:
            raise ValueError("Query: the field name of condition 'not in' cannot be empty")

        self.filters.append({field: {"$nin": values}})
        return self

    def regex(self, field: str, regex) -> 'OrFilterBuilder':
        """
        正则表达式过滤条件, 与 SQL 中的 LIKE 类似. 例如: {"name": {"$regexp": "张"}} 查询所有姓张的人
        :param field: 字段名
        :param regex: 正则表达式
        :return:
        """
        if not field:
            raise ValueError("Query: the field name of condition 'regex' cannot be empty")
        if not regex:
            raise ValueError("Query: the regex expression of condition 'regex' cannot be empty")

        self.filters.append({field: {"$regex": regex}})
        return self

    def lt(self, field: str, value) -> 'OrFilterBuilder':
        """
        小于过滤条件. 例如: age < 20
        :param field: 字段名
        :param value: 字段值
        :return:
        """
        if not field:
            raise ValueError("Query: the field name of condition 'lt' cannot be empty")

        self.filters.append({field: {"$lt": value}})
        return self

    def lte(self, field: str, value) -> 'OrFilterBuilder':
        """
        小于等于过滤条件. 例如: age <= 20
        :param field: 字段名
        :param value: 字段值
        :return:
        """
        if not field:
            raise ValueError("Query: the field name of condition 'lte' cannot be empty")

        self.filters.append({field: {"$lte": value}})
        return self

    def gt(self, field: str, value) -> 'OrFilterBuilder':
        """
        大于过滤条件. 例如: age > 20
        :param field: 字段名
        :param value: 字段值
        :return:
        """
        if not field:
            raise ValueError("Query: the field name of condition 'gt' cannot be empty")

        self.filters.append({field: {"$gt": value}})
        return self

    def gte(self, field: str, value) -> 'OrFilterBuilder':
        """
        大于等于过滤条件. 例如: age >= 20
        :param field: 字段名
        :param value: 字段值
        :return:
        """
        if not field:
            raise ValueError("Query: the field name of condition 'gte' cannot be empty")

        self.filters.append({field: {"$gte": value}})
        return self

    def between(self, field: str, min_value, max_value) -> 'OrFilterBuilder':
        """
        区间过滤条件(注意: 该区间两边都是闭区间), 类似于 SQL 中的 between. 例如: 20 <= age <= 30
        :param field: 字段名
        :param min_value: 最小值
        :param max_value: 最大值
        :return:
        """
        if not field:
            raise ValueError("Query: the field name of condition 'between' cannot be empty")

        self.filters.append({field: {"$gte": min_value, "$lte": max_value}})
        return self

    def between_exclude_left(self, field: str, min_value, max_value) -> 'OrFilterBuilder':
        """
        区间过滤条件(注意: 该区间左边是开区间, 右边是闭区间). 例如: 20 < age <= 30
        :param field: 字段名
        :param min_value: 最小值(不包含该值)
        :param max_value: 最大值
        :return:
        """
        if not field:
            raise ValueError("Query: the field name of condition 'betweenExcludeLeft' cannot be empty")

        if min_value > max_value:
            raise ValueError(f"Query: the minValue '{min_value}' cannot be greater than maxValue '{max_value}'")

        self.filters.append({field: {"$gt": min_value, "$lte": max_value}})
        return self

    def between_exclude_right(self, field: str, min_value, max_value) -> 'OrFilterBuilder':
        """
        区间过滤条件(注意: 该区间左边是闭区间, 右边是开区间). 例如: 20 <= age < 30
        :param field: 字段名
        :param min_value: 最小值
        :param max_value: 最大值(不包含该值)
        :return:
        """
        if not field:
            raise ValueError("Query: the field name of condition 'betweenExcludeRight' cannot be empty")

        self.filters.append({field: {"$gte": min_value, "$lt": max_value}})
        return self

    def between_exclude_all(self, field: str, min_value, max_value) -> 'OrFilterBuilder':
        """
        区间过滤条件(注意: 该区间两边都是开区间). 例如: 20 < age < 30
        :param field: 字段名
        :param min_value: 最小值(不包含该值)
        :param max_value: 最大值(不包含该值)
        :return:
        """
        if not field:
            raise ValueError("Query: the field name of condition 'betweenExcludeAll' cannot be empty")

        self.filters.append({field: {"$gt": min_value, "$lt": max_value}})
        return self


class GroupByBuilder:

    def __init__(self, builder, field: str):
        self.builder = builder
        self.field = field

    def same_to_field(self):
        self.builder.update_group_bys({self.field: f"${self.field}"})
        return self.builder

    def alias(self, alias: str):
        """
        设置分组字段的别名. 例如: {"maxAge": {"$max": "age"}}, 其中 maxAge 为别名, age 为分组字段
        :param alias: 别名
        :return:
        """
        if not alias:
            raise ValueError(f"the alias of group by '{self.field}' cannot be null or empty")

        self.builder.update_group_bys({alias: f"${self.field}"})
        return self.builder

    def date_format(self, alias: str, date_format: str):
        """
        设置日期格式化分组.
        例如: {"day": {"$dateToString": {"format": "%Y-%m-%d", "date": "$createTime"}}} 将 createTime 字段按照 "%Y-%m-%d" 格式化再分组.
        :param alias: 别名
        :param date_format: 日期格式化字符串, 例如: "%Y-%m-%d". 详细的格式化字符串请参考: https://docs.mongodb.com/manual/reference/operator/aggregation/dateToString/#format-specifiers
        :return:
        """
        if not alias:
            raise ValueError(f"the alias of group by '{self.field}' cannot be null or empty")

        if not date_format:
            raise ValueError(f"the format of group by '{self.field}' cannot be null or empty")

        props = {
            "format": date_format,
            "date": f"${self.field}"
        }

        self.builder.update_group_bys({alias: {"$dateToString": props}})
        return self.builder

    def date_format_per_minute(self, alias: str):
        """
        按分钟格式化日期分组, 即分钟进行分组
        :param alias: 别名
        :return:
        """
        return self.date_format(alias, DATE_FORMAT_OF_MINUTE)

    def date_format_per_hour(self, alias: str):
        """
        按小时格式化日期分组, 即小时进行分组
        :param alias: 别名
        :return:
        """
        return self.date_format(alias, DATE_FORMAT_OF_HOUR)

    def date_format_per_day(self, alias: str):
        """
        按天格式化日期分组, 即天进行分组
        :param alias: 别名
        :return:
        """
        return self.date_format(alias, DATE_FORMAT_OF_DAY)

    def date_format_per_week(self, alias: str):
        """
        按周格式化日期分组, 即周进行分组
        :param alias: 别名
        :return:
        """
        return self.date_format(alias, DATE_FORMAT_OF_WEEK)

    def date_format_per_month(self, alias: str):
        """
        按月格式化日期分组, 即月进行分组
        :param alias: 别名
        :return:
        """
        return self.date_format(alias, DATE_FORMAT_OF_MONTH)

    def date_format_per_year(self, alias: str):
        """
        按年格式化日期分组, 即年进行分组
        :param alias: 别名
        :return:
        """
        return self.date_format(alias, DATE_FORMAT_OF_YEAR)


class QueryBuilder:
    ASC = 1
    DESC = -1

    def __init__(self):
        self.exclude_projects = set()
        self.projects = None
        self.filters = None
        self.group_bys = None
        self.group_fields = None
        self.sort = None
        self.skip = None
        self.limit = None
        self.with_count = None

    def get_exclude_projects(self):
        """
        获取排除的字段列表, 即不包含在查询结果中的字段列表
        :return:
        """
        return self.exclude_projects

    def get_projects(self) -> dict:
        """
        获取查询的字段列表
        :return:
        """
        return self.projects

    def set_projects(self, projects: dict):
        """
        设置查询的字段列表
        :param projects: 字段列表, 例如: {"name": 1, "age": 1, "address": {"station": 1, "city": 1}}
        :return:
        """
        self.projects = projects

    def get_filters(self) -> dict:
        """
        获取过滤条件
        :return: {"name": "张三", "age": {"$gt": 20}, "address": {"$regex": "北京"}}
        """
        return self.filters

    def set_filters(self, filters: dict):
        """
        设置过滤条件
        :param filters: 过滤条件. 例如: {"name": "张三", "age": {"$gt": 20}, "address": {"$regex": "北京"}}
        :return:
        """
        self.filters = filters

    def get_group_bys(self):
        """
        获取分组字段列表
        :return:
        """
        return self.group_bys

    def update_group_bys(self, group_bys):
        """
        更新分组字段列表
        :param group_bys: 增加的分组字段列表
        :return:
        """

        if self.group_bys is None:
            self.group_bys = group_bys
        else:
            self.group_bys.update(group_bys)

    def get_group_fields(self):
        """
        获取分组查询字段列表, 例如: {"age": {"$max": "maxAge"}}
        :return:
        """
        return self.group_fields

    def set_group_fields(self, group_fields):
        """
        设置分组查询字段列表, 例如: {"maxAge": {"$max": "age"}}
        :param group_fields:
        :return:
        """
        self.group_fields = group_fields

    def update_group_fields(self, group_fields) -> 'QueryBuilder':
        """
        更新分组查询字段列表, 例如: {"maxAge": {"$max": "$age"}}
        :param group_fields:
        :return:
        """
        if self.group_fields is None:
            self.group_fields = group_fields
        else:
            self.group_fields.update(group_fields)
        return self

    def get_sort(self) -> dict:
        """
        获取排序规则, 例如: {"name": 1, "age": -1} 按名称升序, 按年龄降序
        :return:
        """
        return self.sort

    def set_sort(self, sort: dict):
        """
        设置排序规则
        :param sort: 排序规则. 例如: {"name": 1, "age": -1} 按名称升序, 按年龄降序
        :return:
        """
        self.sort = sort

    def get_skip(self) -> int:
        """
        获取跳过的记录数, 通常用于分页查询
        :return:
        """
        return self.skip

    def set_skip(self, skip: int):
        """
        设置跳过的记录数, 通常用于分页查询
        :param skip:
        :return:
        """

        if skip < 0:
            raise ValueError("the skip cannot be less than 0")

        self.skip = skip

    def get_limit(self) -> int:
        """
        获取查询的记录数, 通常用于分页查询
        :return:
        """
        return self.limit

    def set_limit(self, limit: int):
        """
        设置查询的记录数, 通常用于分页查询
        :param limit:
        :return:
        """

        if limit <= 0:
            raise ValueError("the limit cannot be less than or equal to 0")

        self.limit = limit

    def get_with_count(self) -> bool:
        """
        是否返回符合条件的记录总数
        :return:
        """
        return self.with_count

    def set_with_count(self, with_count: bool):
        """
        设置是否返回符合条件的记录总数
        :param with_count:
        :return:
        """
        self.with_count = with_count

    def filter(self) -> FilterBuilder:
        """
        获取过滤条件构造器
        :return:
        """
        if self.filters is None:
            self.filters = {}
        return FilterBuilder(self, self.filters)

    def or_filter(self) -> OrFilterBuilder:
        """
        获取 or 条件构造器
        :return:
        """
        or_filters = []
        if self.filters is None:
            self.filters = {"$or": or_filters}
        else:
            or_filters = self.filters.get("$or", None)
            if or_filters is None:
                or_filters = []
                self.filters["$or"] = or_filters
        return OrFilterBuilder(self, or_filters)

    def contains_select_field(self, field: str) -> bool:
        """
        是否包含指定的查询字段
        :param field:
        :return:
        """
        if self.projects is None:
            return False
        return field in self.projects

    def select(self, *fields) -> 'QueryBuilder':
        """
        设置查询字段列表
        :param fields: 字段列表, 例如: name, age
        :return:
        """
        if self.projects is None:
            self.projects = {}

        for field in fields:
            if field in self.exclude_projects:
                continue

            if not field:
                raise ValueError("Query: the select field cannot be empty")
            elif field in self.exclude_projects:
                continue
            self.projects[field] = 1
        return self

    def select_sub_fields(self, field: str, *sub_fields) -> 'QueryBuilder':
        """
        设置查询嵌套字段列表. 例如: address.station, address.city, 则 field 为 address, sub_fields 为 station, city
        :param field: 字段名, 即嵌套对象的字段名, 例如: address
        :param sub_fields: 嵌套字段列表, station, city
        :return:
        """

        # 如果当前嵌套对象字段已经被排除, 则直接返回
        if field in self.exclude_projects:
            return self

        if not field:
            raise ValueError("Query: the select field cannot be empty")

        if sub_fields is None or len(sub_fields) == 0:
            raise ValueError("Query: the select sub fields cannot be empty")

        s_fields = {}
        for sub_field in sub_fields:
            s_fields[sub_field] = 1

        if self.projects is None:
            self.projects = {field: sub_fields}
        else:
            project_field = self.projects.get(field)
            if project_field is None:
                self.projects[field] = s_fields
            elif isinstance(project_field, dict):
                project_field.update(s_fields)
            else:
                raise ValueError("Query: the select field '" + field + "' has been set to a non-nested object")
        return self

    def exclude(self, *columns) -> 'QueryBuilder':
        """
        排除指定的字段, 即不包含在查询结果中. 注: 该方法不支持排除嵌套字段
        :param columns: 字段列表, 例如: name, age
        :return:
        """

        # 保存排除的字段列表, 后续添加添加字段时过滤掉排除的字段
        self.exclude_projects.update(columns)

        if not columns or not self.projects:
            return self
        for column in columns:
            if column in self.projects:
                del self.projects[column]
        return self

    def group_by(self, field: str) -> GroupByBuilder:
        """
        分组字段构造器
        :param field: 字段名
        :return:
        """
        group_by_builder = GroupByBuilder(self, field)
        return group_by_builder

    def summary(self, field: str) -> AggregateBuilder:
        """
        聚合字段构造器
        :param field: 字段名
        :return:
        """
        aggregate_builder = AggregateBuilder(self, field)
        return aggregate_builder

    def order_asc(self, *fields) -> 'QueryBuilder':
        """
        设置升序排序字段列表
        :param fields: 字段列表, 例如: name, age
        :return:
        """
        if not fields:
            return self
        if self.sort is None:
            self.sort = {}
        for field in fields:
            field = field.strip()
            if not field:
                raise ValueError("Query: the field name of order_asc cannot be empty")
            self.sort[field] = QueryBuilder.ASC
        return self

    def order_desc(self, *fields) -> 'QueryBuilder':
        """
        设置降序排序字段列表
        :param fields: 字段列表, 例如: name, age
        :return:
        """
        if not fields:
            return self
        if self.sort is None:
            self.sort = {}
        for field in fields:
            field = field.strip()
            if not field:
                raise ValueError("Query: the field name of order_desc cannot be empty")
            self.sort[field] = QueryBuilder.DESC
        return self

    def with_skip(self, skip: int) -> 'QueryBuilder':
        """
        设置跳过的记录数, 通常用于分页查询
        :param skip: 跳过的记录数
        :return:
        """
        if skip < 0:
            raise ValueError("Query: skip cannot be less than 0")
        self.skip = skip
        return self

    def with_limit(self, limit: int) -> 'QueryBuilder':
        """
        设置查询的记录数, 通常用于分页查询
        :param limit: 查询的记录数
        :return:
        """
        if limit < 0:
            raise ValueError("Query: limit cannot be less than 0")
        self.limit = limit
        return self

    def enable_count(self) -> 'QueryBuilder':
        """
        启用返回符合条件的记录总数
        :return:
        """
        self.with_count = True
        return self

    def build(self) -> 'Query':
        return Query(self.projects, self.filters, self.group_bys, self.group_fields,
                     self.sort, self.skip, self.limit, self.with_count, self)


@dataclasses.dataclass
class Query:
    """
    查询条件对象.
    """

    def __init__(self, project, filter, groupBy, groupFields, sort, skip, limit, withCount, builder: QueryBuilder):
        self.project = project
        self.filter = filter
        self.groupBy = groupBy
        self.groupFields = groupFields
        self.sort = sort
        self.skip = skip
        self.limit = limit
        self.withCount = withCount
        self.__builder__ = builder

    @staticmethod
    def new_builder() -> QueryBuilder:
        return QueryBuilder()

    def to_builder(self) -> QueryBuilder:
        return self.__builder__

    def has_select_fields(self) -> bool:
        return self.project is not None

    def has_filters(self):
        return self.filter is not None

    def get_project(self):
        return self.project

    def get_filters(self):
        return self.filter

    def get_group_bys(self):
        return self.groupBy

    def get_group_fields(self):
        return self.groupFields

    def get_sort(self) -> Optional[dict[str, int]]:
        return self.sort

    def get_limit(self) -> Optional[int]:
        return self.limit

    def get_skip(self) -> Optional[int]:
        return self.skip

    def is_with_count(self) -> bool:
        return self.withCount is not None and self.withCount

    def __dict__(self):
        data = {}
        if self.project:
            data["project"] = self.project
        if self.filter:
            data["filter"] = self.filter
        if self.groupBy:
            data["groupBy"] = self.groupBy
        if self.groupFields:
            data["groupFields"] = self.groupFields
        if self.sort:
            data["sort"] = self.sort
        if self.skip:
            data["skip"] = self.skip
        if self.limit:
            data["limit"] = self.limit
        if self.withCount:
            data["withCount"] = self.withCount
        return data

    def serialize(self) -> bytes:
        return jsons.dumps(self.__dict__(), jdkwargs={'ensure_ascii': False}).encode('utf-8')

    def serialize_to_string(self) -> str:
        return jsons.dumps(self.__dict__(), jdkwargs={'ensure_ascii': False})

    def serialize_filter(self) -> bytes:
        if self.filter is None:
            return "{}".encode("utf-8")
        return jsons.dumps(self.filter, jdkwargs={'ensure_ascii': False}).encode('utf-8')

    def serialize_filter_to_string(self) -> str:
        if self.filter is None:
            return "{}"
        return jsons.dumps(self.filter, jdkwargs={'ensure_ascii': False})
