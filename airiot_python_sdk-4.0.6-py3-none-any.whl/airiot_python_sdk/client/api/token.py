import dataclasses


@dataclasses.dataclass
class Token:
    """
    平台访问令牌

    Attributes:
        accessToken: 访问令牌
        expiresAt: 令牌过期时间(时间戳)
        isAdmin: 是否为超级管理员
        token: 令牌
        tokenType: 令牌类型
        userId: 用户 ID
    """

    # 访问令牌
    accessToken: str
    # 令牌过期时间
    expiresAt: int
    # 是否为超级管理员
    isAdmin: bool
    # 令牌
    token: str
    # 令牌类型
    tokenType: str
    # 用户 ID
    userId: str
