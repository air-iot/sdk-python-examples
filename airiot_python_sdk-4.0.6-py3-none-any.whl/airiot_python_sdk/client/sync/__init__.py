from typing import Optional


from .. import Clients, SPMProjectClient, LatestClient, WorkTableDataClient, TimingDataClient
from ..api.spm import SPMUserClient
from ..api.system_variable import SystemVariableClient
from ..authentication import AuthorizationType, Authentication
from ..sync._base_client import BaseClient
from ..sync._latest import SyncLatestClient
from ..sync._spm import SyncSPMUserClient, SyncSPMProjectClient
from ..sync._system_variable import SyncSystemVariableClient
from ..sync._timing_data import SyncTimingDataClient
from ..sync._worktable_data import SyncWorkTableDataClient


def create_base_client(base_url: str, auth_type: AuthorizationType = None, app_key: str = None, app_secret: str = None,
                       project_id: Optional[str] = None,
                       authentication: Authentication = None) -> BaseClient:
    """
    创建同步 BaseClient
    :param base_url: 平台网关地址
    :param auth_type 授权类型
    :param app_key 应用授权 key
    :param app_secret 应用授权密钥
    :param project_id 项目ID, 当授权类型为 project 时必须填写
    :param authentication 认证拦截器, 如果传递了该参数, 则忽略其它认证配置. 例如: auth_type, app_key, app_secret, project_id 等
    :return: BaseClient
    """
    return BaseClient(base_url, auth_type=auth_type, app_key=app_key, app_secret=app_secret, project_id=project_id,
                      authentication=authentication)


class SyncClients(Clients):
    """
    同步请求客户端
    """

    base_client: BaseClient

    # 应用授权信息
    app_key: str
    app_secret: str

    def __init__(self, base_url: str, auth_type: AuthorizationType = None, app_key: str = None, app_secret: str = None,
                 project_id: Optional[str] = None, authentication: Authentication = None):
        self.base_client = create_base_client(base_url, auth_type=auth_type, app_key=app_key, app_secret=app_secret,
                                              project_id=project_id, authentication=authentication)

    def get_spm_user_client(self) -> SPMUserClient:
        return SyncSPMUserClient(self.base_client)

    def get_spm_project_client(self) -> SPMProjectClient:
        return SyncSPMProjectClient(self.base_client)

    def get_system_variable_client(self) -> SystemVariableClient:
        return SyncSystemVariableClient(self.base_client)

    def get_latest_client(self) -> LatestClient:
        return SyncLatestClient(self.base_client)

    def get_timing_data_client(self) -> TimingDataClient:
        return SyncTimingDataClient(self.base_client)

    def get_worktable_client(self) -> WorkTableDataClient:
        return SyncWorkTableDataClient(self.base_client)
