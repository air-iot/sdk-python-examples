import json
from typing import Optional

from airiot_python_sdk.client.api import Response, InsertResult, set_project_header
from airiot_python_sdk.client.api.query import Query
from airiot_python_sdk.client.api.system_variable import SystemVariableClient, SystemVariable
from airiot_python_sdk.client.sync import BaseClient


class SyncSystemVariableClient(SystemVariableClient):
    """
    系统变量(数据字典)客户端接口
    """

    base_client: BaseClient

    def __init__(self, base_client: BaseClient):
        self.base_client = base_client

    def get(self, project_id: str, query: Query, headers: Optional[dict[str, str]] = None) -> Response[
        list[SystemVariable]]:
        headers = set_project_header(project_id, headers)
        query_str = query.serialize_to_string()
        return self.base_client.perform_get(f"/core/systemVariable?query={query_str}", headers=headers,
                                            cls=list[SystemVariable])

    def get_by_id(self, project_id: str, id: str, headers: Optional[dict[str, str]] = None) -> Response[SystemVariable]:
        headers = set_project_header(project_id, headers)
        return self.base_client.perform_get(f"/core/systemVariable/{id}", headers=headers, cls=SystemVariable)
    
    def create(self, project_id: str, variable: SystemVariable, headers: Optional[dict[str, str]] = None) -> Response[
        InsertResult]:
        headers = set_project_header(project_id, headers)
        return self.base_client.perform_post("/core/systemVariable", data=json.dumps(variable, default=vars),
                                             headers=headers, cls=InsertResult)

    def update(self, project_id: str, variable: SystemVariable, headers: Optional[dict[str, str]] = None) -> Response:
        if variable.id is None:
            raise ValueError("系统变量的 id 不能为空")

        headers = set_project_header(project_id, headers)
        return self.base_client.perform_patch(f"/core/systemVariable/{variable.id}",
                                              data=json.dumps(variable, default=vars), headers=headers)

    def update_value(self, project_id: str, id: str, value: any, headers: Optional[dict[str, str]] = None) -> Response:
        headers = set_project_header(project_id, headers)
        data = {"value": value}
        return self.base_client.perform_patch(f"/core/systemVariable/{id}", data=data, headers=headers)

    def delete(self, project_id: str, id: str, headers: Optional[dict[str, str]] = None) -> Response:
        headers = set_project_header(project_id, headers)
        return self.base_client.perform_delete(f"/core/systemVariable/{id}", headers=headers)
