from typing import Optional

from airiot_python_sdk.client.api import Response, BatchInsertResult, InsertResult, set_project_header
from airiot_python_sdk.client.api.query import Query
from airiot_python_sdk.client.api.worktable_data import WorkTableDataClient
from airiot_python_sdk.client.sync import BaseClient


class SyncWorkTableDataClient(WorkTableDataClient):
    base_client: BaseClient

    def __init__(self, base_client: BaseClient):
        self.base_client = base_client

    def query(self, project_id: str, table_id: str, query: Query, headers: Optional[dict[str, str]] = None) -> Response[
        list[dict]]:
        headers = set_project_header(project_id, headers)
        query_str = query.serialize_to_string()
        return self.base_client.perform_get(f"/core/t/{table_id}/d?query={query_str}", headers=headers, cls=list[dict])

    def query_by_id(self, project_id: str, table_id: str, row_id: str, headers: Optional[dict[str, str]] = None) -> \
    Response[dict]:
        headers = set_project_header(project_id, headers)
        return self.base_client.perform_get(f"/core/t/{table_id}/d/{row_id}", headers=headers)

    def create(self, project_id: str, table_id: str, data, headers: Optional[dict[str, str]] = None) -> Response[
        InsertResult]:
        headers = set_project_header(project_id, headers)
        return self.base_client.perform_post(f"/core/t/{table_id}/d", data=data, headers=headers, cls=InsertResult)

    def create_batch(self, project_id: str, table_id: str, data, headers: Optional[dict[str, str]] = None) -> Response[
        BatchInsertResult]:
        headers = set_project_header(project_id, headers)
        return self.base_client.perform_post(f"/core/t/{table_id}/d/many", data=data, headers=headers,
                                             cls=BatchInsertResult)

    def update(self, project_id: str, table_id: str, row_id: str, data,
               headers: Optional[dict[str, str]] = None) -> Response:
        headers = set_project_header(project_id, headers)
        return self.base_client.perform_patch(f"/core/t/{table_id}/d/{row_id}", data=data, headers=headers)

    def update_many(self, project_id: str, table_id: str, filter_query: Query, data,
                    headers: Optional[dict[str, str]] = None) -> Response:
        headers = set_project_header(project_id, headers)
        filter_str = filter_query.serialize_filter_to_string()
        return self.base_client.perform_patch(f"/core/t/{table_id}/d/many?query={filter_str}", data=data, headers=headers)

    def delete_by_id(self, project_id: str, table_id: str, row_id: str,
                     headers: Optional[dict[str, str]] = None) -> Response:
        headers = set_project_header(project_id, headers)
        return self.base_client.perform_delete(f"/core/t/{table_id}/d/{row_id}", headers=headers)

    def delete(self, project_id: str, table_id: str, filter_query: Query,
               headers: Optional[dict[str, str]] = None) -> Response:
        headers = set_project_header(project_id, headers)
        filter_str = filter_query.serialize_filter_to_string()
        return self.base_client.perform_delete(f"/core/t/{table_id}/d/many?query={filter_str}", headers=headers)
