from typing import Optional

import grpc

from airiot_python_sdk.client.etcd.protos.rpc_pb2 import AuthenticateRequest, AuthenticateResponse, RangeRequest, \
    RangeResponse
from airiot_python_sdk.client.etcd.protos.rpc_pb2_grpc import AuthStub, KVStub


class Client:

    def __init__(self, host: str, port: int = 2379, username: str = None, password: str = None):
        self.call_credentials = None
        self.metadata = None
        self.host = host
        self.port = port
        self.username = username
        self.password = password

    def get(self, key: str) -> Optional[str]:
        with grpc.insecure_channel("{}:{}".format(self.host, self.port)) as channel:
            if self.username and self.password:
                auth = AuthStub(channel)
                auth_response: AuthenticateResponse = auth.Authenticate(
                    AuthenticateRequest(name=self.username, password=self.password))
                self.metadata = (('token', auth_response.token),)

            kv = KVStub(channel)
            response: RangeResponse = kv.Range(RangeRequest(key=key.encode("utf-8"), limit=1),
                                               timeout=5,
                                               metadata=self.metadata)
            if response.count == 0:
                return None
            return response.kvs[0].value.decode("utf-8")

