class AlgorithmGrpcConfig:
    """
    平台算法服务 gRPC 配置

    Attributes:
        host: driver 服务地址
        port: driver 服务端口, 默认为 9236
        health_check_interval: 健康检查间隔, 默认为 30s
    """

    host: str = "algorithm"
    port: int = 9236
    health_check_interval: int = 30

    def __str__(self):
        return "AlgorithmGrpcConfig(host={}, port={}, health_check_interval={})".format(
            self.host, self.port, self.health_check_interval
        )


class AlgorithmConfig:
    """
    算法服务配置信息
    """

    # 算法服务ID. 每个算法服务都要有一个唯一的标识
    id: str
    # 算法服务名称
    name: str
    # 算法服务实例ID
    service_id: str
    # 最大线程数量. 如果为 0 则取当前 CPU 核数
    max_threads: int = 1
    # 平台算法服务配置信息
    algorithm_grpc: AlgorithmGrpcConfig = AlgorithmGrpcConfig()

    def __init__(self, id: str = None, name: str = None, service_id: str = None, algorithm_grpc: AlgorithmGrpcConfig = None):
        self.id = id
        self.name = name
        self. service_id = service_id
        self.algorithm_grpc = algorithm_grpc
