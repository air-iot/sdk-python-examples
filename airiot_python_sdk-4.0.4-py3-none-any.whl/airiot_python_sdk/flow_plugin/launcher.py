import asyncio
import json
import logging
import traceback
from typing import Optional, Callable

import grpc
from grpc.aio import Metadata, StreamStreamCall

from airiot_python_sdk.flow_plugin import FlowPlugin, FlowTask, DebugTask
from airiot_python_sdk.flow_plugin.config import FlowPluginConfig
from airiot_python_sdk.flow_plugin.protos.engine_pb2 import FlowRequest, FlowResponse, HealthCheckRequest, \
    HealthCheckResponse, DebugRequest, DebugResponse
from airiot_python_sdk.flow_plugin.protos.engine_pb2_grpc import PluginServiceStub

logger = logging.getLogger("flow_plugin_launcher")


class FlowPluginLauncher:
    """
    流程插件启动器
    """

    json_encoder = json.JSONEncoder()

    config: FlowPluginConfig
    plugin: FlowPlugin

    servicer: PluginServiceStub
    channel: Optional[grpc.aio.Channel]

    register_stream: Optional[StreamStreamCall]
    debug_stream: Optional[StreamStreamCall]

    running: bool = False

    def __init__(self, config: FlowPluginConfig, plugin: FlowPlugin):
        self.config = config
        self.channel = None
        self.plugin = plugin
        self.register_stream = None
        self.debug_stream = None
        self.stop_request_fired = asyncio.Event()

    async def start(self):
        """
        启动流程插件
        :return:
        """

        if self.running:
            return

        self.running = True

        logger.info("start plugin: name = %s, mode = %s", self.plugin.get_name(), self.plugin.get_type())

        self.plugin.start()

        # connect to flow_plugin-enginerpc
        await self.__connect__()

        # wait for stop signal
        try:
            await self.stop_request_fired.wait()
        except asyncio.CancelledError:
            pass

    async def stop(self):
        """
        停止流程插件
        :return:
        """

        if not self.running:
            return

        logger.info("stopping plugin")

        self.running = False

        # call plugin connection state change callback
        self.plugin.on_connection_state_changed(False)

        # call plugin stop callback
        self.plugin.stop()

        if self.register_stream is not None:
            self.register_stream.cancel()

        if self.debug_stream is not None:
            self.debug_stream.cancel()

        # close grpc channel
        await self.channel.close(grace=5)

        # send stop signal
        self.stop_request_fired.set()

        logger.info("plugin stopped")

    async def __connect__(self):
        # 如果已经停止则不再重连
        if not self.running:
            return

        # 关闭现有的 channel
        if self.channel is not None:
            # call plugin connection state change callback
            self.plugin.on_connection_state_changed(False)
            await self.channel.close(grace=5)

        # connect to flow_plugin engine
        await self.__connect_grpc__()

        # create all streams
        self.__create_streams__()

    async def __connect_grpc__(self):
        """
        连接到流程引擎的gRPC服务
        :return:
        """

        logger.info("start to connect flow_plugin enginerpc: grpc://%s:%d", self.config.host, self.config.port)

        metadata = Metadata()
        metadata.add("name", self.plugin.get_name().encode("utf-8").hex())
        metadata.add("mode", self.plugin.get_type().value.encode("utf-8").hex())

        logger.debug("grpc metadata: %s", metadata)

        self.channel = grpc.aio.insecure_channel("{}:{}".format(self.config.host, self.config.port))
        self.servicer = PluginServiceStub(self.channel)

        await self.channel.channel_ready()

        # call plugin connection state change callback
        logger.info("connected to flow_plugin enginerpc: grpc://%s:%d", self.config.host, self.config.port)

        self.plugin.on_connection_state_changed(True)

    def __create_streams__(self):
        logger.info("start to create streams")

        loop = asyncio.get_event_loop()

        tasks = [loop.create_task(self.__register__()),
                 loop.create_task(self.__debug_stream__()),
                 loop.create_task(self.__health_check__(self.__connect__))
                 ]

        asyncio.gather(*tasks, return_exceptions=True)

    async def __register__(self):
        metadata = Metadata()
        metadata.add("name", self.plugin.get_name().encode("utf-8").hex())
        metadata.add("mode", self.plugin.get_type().value.encode("utf-8").hex())

        self.register_stream = self.servicer.Register(metadata=metadata)
        logger.info("plugin register successfully, start to receive requests")

        async for request in self.register_stream:
            if request == grpc.aio.EOF:
                logger.info("register stream closed")
                break

            response = await self.__handle_request__(request)
            await self.register_stream.write(response)

    async def __handle_request__(self, request: FlowRequest) -> FlowResponse:
        logger.debug("收到请求, project=%s, flowId=%s, job=%s, elementId=%s, elementJob=%s, config=%s",
                     request.projectId, request.flowId, request.job,
                     request.elementId, request.elementJob, request.config)

        try:
            result = await self.plugin.execute(
                FlowTask(request.projectId, request.flowId, request.job, request.elementId,
                         request.elementJob, request.config))

            logger.debug("执行结果, project=%s, flowId=%s, job=%s, elementId=%s, elementJob=%s, result=%s",
                         request.projectId, request.flowId, request.job,
                         request.elementId, request.elementJob, result)

            return FlowResponse(status=True, elementJob=request.elementJob,
                                info=result.message, detail=result.details,
                                result=self.json_encoder.encode(result.data).encode("utf-8"))
        except Exception as e:
            traceback.print_stack()
            logger.error("执行异常, project=%s, flowId=%s, job=%s, elementId=%s, elementJob=%s, exception=%s",
                         request.projectId, request.flowId, request.job,
                         request.elementId, request.elementJob, e)
            return FlowResponse(status=False, elementJob=request.elementJob,
                                info="执行异常, {}".format(e), detail="")

    async def __debug_stream__(self):
        metadata = Metadata()
        metadata.add("name", self.plugin.get_name().encode("utf-8").hex())
        metadata.add("mode", self.plugin.get_type().value.encode("utf-8").hex())

        self.debug_stream = self.servicer.DebugStream(metadata=metadata)
        logger.info("plugin debug register successfully, start to receive debug requests")

        async for request in self.debug_stream:
            if request == grpc.aio.EOF:
                logger.info("debug stream closed")
                break

            response = await self.__handle_debug_request__(request)
            await self.debug_stream.write(response)

    async def __handle_debug_request__(self, request: DebugRequest) -> DebugResponse:
        logger.debug("收到调试请求, project=%s, flowId=%s, elementId=%s, config=%s",
                     request.projectId, request.flowId, request.elementId, request.config)

        try:
            result = await self.plugin.debug(
                DebugTask(request.projectId, request.flowId, request.elementId, request.config))

            logger.debug("执行结果, project=%s, flowId=%s, elementId=%s, result=%s",
                         request.projectId, request.flowId, request.elementId, result)

            return DebugResponse(status=result.success, elementJob=request.elementJob,
                                 info=result.reason, detail=result.detail,
                                 result=self.json_encoder.encode({"logs": result.logs, "value": result.value}).encode(
                                     "utf-8"))
        except Exception as e:
            traceback.print_stack()
            logger.error("执行异常, project=%s, flowId=%s, elementId=%s, exception=%s",
                         request.projectId, request.flowId, request.elementId, e)
            return DebugResponse(status=False, elementJob=request.elementJob,
                                 info="执行异常, {}".format(e), detail="")

    async def __health_check__(self, reconnect: Callable):
        """
        健康检查
        :param reconnect: 重连方法
        :return:
        """

        name = self.plugin.get_name()
        interval = 30 if self.config.health_check_interval <= 0 else self.config.health_check_interval

        logger.info("start health check, name = %s, interval = %d", name, interval)

        while self.running:
            try:
                tasks = asyncio.as_completed([
                    asyncio.sleep(interval),
                    self.stop_request_fired.wait()
                ])

                for task in tasks:
                    await task
                    break

                if not self.running:
                    break

                logger.info("send health check request, name = %s", name)
                response: HealthCheckResponse = await self.servicer.HealthCheck(HealthCheckRequest(name=name),
                                                                                timeout=5)
                if response.errors is not None and len(response.errors) > 0:
                    for error in response.errors:
                        logger.error("health check failed, code = %d, message = %s", error.code, error.message)
                elif response.status == HealthCheckResponse.SERVING:
                    logger.info("health check success, name = %s", name)
                else:
                    logger.error("health check failed, name = %s, status = %d", name, response.status)
                    break
            except Exception as e:
                traceback.print_exception(e)
                logger.error("health check exception, name = %s, exception = %s", name, e)
                break
        # 心跳检测失败, 重连
        await reconnect()
