# -*- coding: utf-8 -*-
from typing import Optional, Type, TypeVar

import jsons
import requests
from requests import Response as ClientResponse

from ..api import Response, ok_only_data, fail
from ..authentication import AuthorizationType, Authentication

T = TypeVar('T')


def json_dumps(obj: any) -> str:
    return jsons.dumps(obj, jdkwargs={"ensure_ascii": False, "default": vars, 'separators': (',', ':')})


def parse_response(resp: ClientResponse, cls: Optional[Type[T]] = None) -> Response:
    body = resp.json()
    if resp.ok:
        body = jsons.load(body, cls=cls)
        return ok_only_data(body)
    else:
        body = resp.json()
        return fail(body["code"], body["message"], body.get("detail", ""), body.get("field", ""))


class BaseClient:
    # 平台地址
    host: str

    session: requests.sessions.Session

    def __init__(self, host: str, auth_type: AuthorizationType, app_key: str, app_secret: str,
                 project_id: Optional[str] = None, authentication: Authentication = None):
        if host.startswith("http://") or host.startswith("https://"):
            self.host = host
        else:
            self.host = f"http://{host}"
        
        self.session = requests.sessions.Session()
        if authentication is not None:
            self.session.auth = authentication
        else:
            self.session.auth = Authentication(base_host=host, auth_type=auth_type, app_key=app_key,
                                               app_secret=app_secret,
                                               project_id=project_id)

    def perform_get(self, path: str, headers: dict[str, str] = None, params: dict[str, any] = None,
                    cls: Optional[Type[T]] = None) -> Response[T]:
        """
        发起 GET 请求
        :param path: 请求路径
        :param headers: 请求头
        :param params: 请求参数
        :param cls: 请求结果类型
        :return:
        """

        response = self.session.get("{}{}".format(self.host, path), headers=headers, data=params)
        return parse_response(response, cls=cls)

    def perform_post(self, path: str, headers=None, data: any = None,
                     cls: Optional[Type[T]] = None) -> Response[T]:
        """
        发起 POST 请求
        :param path: 请求路径
        :param headers: 请求头
        :param data: 请求体
        :param cls: 请求结果类型
        :return:
        """

        if headers is None:
            headers = {}
        headers = {"Content-Type": "application/json; charset=utf-8", **headers}

        if isinstance(data, str) or isinstance(data, bytes):
            response = self.session.post(f"{self.host}{path}", headers=headers, data=data)
        else:
            response = self.session.post(f"{self.host}{path}", headers=headers, data=json_dumps(data).encode("utf-8"))
        return parse_response(response, cls=cls)

    def perform_put(self, path: str, headers: dict[str, str] = None, data: any = None,
                    cls: Optional[Type[T]] = None) -> Response[T]:
        """
        发起 PUT 请求
        :param path: 请求路径
        :param headers: 请求头
        :param data: 请求体
        :param cls: 请求结果类型
        :return:
        """

        if headers is None:
            headers = {}
        headers = {"Content-Type": "application/json", **headers}

        if isinstance(data, str) or isinstance(data, bytes):
            response = self.session.put(f"{self.host}{path}", headers=headers, data=data)
        else:
            response = self.session.put(f"{self.host}{path}", headers=headers, data=json_dumps(data).encode("utf-8"))
        return parse_response(response, cls=cls)

    def perform_patch(self, path: str, headers: dict[str, str] = None, data: any = None,
                      cls: Optional[Type[T]] = None) -> Response[T]:
        """
        发起 PATCH 请求
        :param path: 请求路径
        :param headers: 请求头
        :param data: 请求体
        :param cls: 请求结果类型
        :return:
        """

        if headers is None:
            headers = {}
        headers = {"Content-Type": "application/json", **headers}

        if isinstance(data, str) or isinstance(data, bytes):
            response = self.session.patch(f"{self.host}{path}", headers=headers, data=data)
        else:
            response = self.session.patch(f"{self.host}{path}", headers=headers, data=json_dumps(data).encode("utf-8"))
        return parse_response(response, cls=cls)

    def perform_delete(self, path: str, headers=None, params=None) -> Response:
        """
        发起 DELETE 请求
        :param path: 请求路径
        :param headers: 请求头
        :param params: 请求参数, 该参数会被编码到 URL 中
        :return:
        """

        if params is None:
            params = {}
        if headers is None:
            headers = {}

        response = self.session.delete("{}{}".format(self.host, path), headers=headers, data=params)
        return parse_response(response)
