import enum
import threading
from datetime import datetime
from typing import Optional, Callable

import jsons
import requests
from airiot_python_sdk.client.api import PROJECT_HEADER_KEY
from airiot_python_sdk.client.api.token import Token
from airiot_python_sdk.client.etcd.client import Client
from requests import PreparedRequest
from requests.auth import AuthBase


class AuthorizationType(enum.Enum):
    """
    授权类型

    Tenant: 租户授权
    Project: 项目授权
    """
    Tenant = "Tenant"
    Project = "Project"


def new_auth_type(auth_type: str) -> AuthorizationType:
    if auth_type.lower() == "tenant":
        return AuthorizationType.Tenant
    elif auth_type.lower() == "project":
        return AuthorizationType.Project
    else:
        raise BaseException("不支持的认证类型: {}".format(auth_type))


class Authentication(AuthBase):
    lock = threading.Lock()

    # 平台接口地址
    base_host: str
    # 授权类型
    auth_type: AuthorizationType
    # 项目ID
    project_id: Optional[str]
    # 应用授权信息
    app_key: str
    app_secret: str

    # 已获取得的 token
    token: Optional[Token] = None

    white_list: dict[str, bool] = {}

    # 获取 token 的方法
    get_token_fn: Callable

    def __init__(self, base_host: str, auth_type: AuthorizationType, app_key: str, app_secret: str,
                 project_id: Optional[str] = None, white_list: list[str] = ["/spm/token", "/core/auth/token"]):
        if auth_type == AuthorizationType.Project and project_id is None:
            raise ValueError("授权类型为 project 时, project_id 不能为空")
        if base_host.startswith("http://") or base_host.startswith("https://"):
            self.base_host = base_host
        else:
            self.base_host = f"http://{base_host}"

        self.auth_type = auth_type
        self.project_id = project_id
        self.app_key = app_key
        self.app_secret = app_secret
        self.get_token_fn = self.__get_tenant_token if auth_type == AuthorizationType.Tenant else self.__get_project_token

        if white_list is not None:
            for path in white_list:
                self.white_list[path] = True

    def __call__(self, request: PreparedRequest):
        self.__check_token__()
        request.headers.update({"Authorization": self.token.token})
        return request

    def __check_token__(self):
        """
        检查 token 是否有效, 如果未获取到 token 或 token 过期则重新请求 token
        :return:
        """
        # 如果未过期则直接返回
        if self.token is not None and self.token.expiresAt > int(datetime.now().timestamp()):
            return

        self.lock.acquire(blocking=True)
        try:
            # 二次检查
            if self.token is not None and self.token.expiresAt > int(datetime.now().timestamp()):
                return
            self.get_token_fn()
        finally:
            self.lock.release()

    def __get_project_token(self):
        url = "{}/core/auth/token?appkey={}&appsecret={}".format(self.base_host, self.app_key, self.app_secret)
        response: requests.Response = requests.get(url, headers={PROJECT_HEADER_KEY: self.project_id})
        if response.ok:
            self.token = jsons.loads(response.content.decode("utf-8"), Token)
            return
        raise ValueError(
            "获取 token 失败, 响应码: {}, 响应体: {}".format(response.status_code, response.content.decode("utf-8")))

    def __get_tenant_token(self):
        url = "{}/spm/token".format(self.base_host)
        response: requests.Response = requests.post(url, json={"ak": self.app_key, "sk": self.app_secret})
        if response.ok:
            self.token = jsons.loads(response.content.decode("utf-8"), Token)
            return
        raise ValueError(
            "获取 token 失败, 响应码: {}, 响应体: {}".format(response.status_code, response.content.decode("utf-8")))


def create_auth_from_etcd(base_host: str, endpoint: str, username: str = None, password: str = None,
                          config_key: str = "/airiot/config/pro.json", project_id: str = None):
    """
    根据 etcd 中的配置创建授权对象. 使用 etcd 中配置的授权信息
    :param base_host: 平台接口地址
    :param endpoint: etcd 服务地址, 格式为 host:port
    :param username: etcd 用户名
    :param password: etcd 密码
    :param config_key: 配置信息的 key
    :param project_id 项目ID
    :return:
    """

    if not endpoint or len(endpoint) == 0:
        raise ValueError("etcd 服务地址不能为空")

    fields = endpoint.split(":")
    if len(fields) == 1:
        host = endpoint
        port = 2379
    else:
        host = fields[0]
        port = int(fields[1])

    if not config_key or len(config_key) == 0:
        raise ValueError("配置文件 key 不能为空")

    client = Client(host=host, port=port, username=username, password=password)
    config = client.get(config_key)
    config_value = jsons.loads(config)

    # config_value["App"]["API"]
    if 'App' not in config_value:
        raise ValueError("配置文件中未找到 App 配置项")

    app = config_value["App"]
    if 'API' not in app and 'api' not in app:
        raise ValueError("配置文件中未找到 App.API 配置项")

    api = app.get("api")
    if not api:
        api = app["API"]

    if not project_id:
        if 'projectId' in api:
            project_id = api["projectId"]

    auth_type = api.get("type")
    app_key = api.get("ak")
    app_secret = api.get("sk")

    if not auth_type:
        auth_type = api["Type"]

    if not app_key:
        app_key = api["AK"]

    if not app_secret:
        app_secret = api["SK"]

    return Authentication(base_host, auth_type=new_auth_type(auth_type), app_key=app_key, app_secret=app_secret,
                          project_id=project_id)