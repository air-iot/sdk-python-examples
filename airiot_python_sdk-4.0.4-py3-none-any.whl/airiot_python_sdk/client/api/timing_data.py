import dataclasses
from abc import abstractmethod
from datetime import datetime
from typing import List, Set, Dict, Optional

import jsons

from airiot_python_sdk.client.api import Response

# 时序库中资产编号字段名
TIMING_DEVICE_ID = "id"
DATE_TIME_FORMATTER = "%Y-%m-%d %H:%M:%S"


class Builder:
    """
    时序数据查询构建器
    """

    queries: List['TimingDataQuery'] = []

    fields: List[str] = []
    tableId: str = ""
    nodeId: Optional[str] = None
    departments: Set[str] = set()
    where: dict[str, dict[str, any]] = {}
    group: list[str] = []
    fill: Optional[str] = None
    order: dict[str, str] = {}
    limit: Optional[int] = None
    offset: Optional[int] = None

    def __init__(self, fields: list[str] = None, table_id: str = None, node_id: str = None,
                 departments: Set[str] = None, where: dict[str, dict[str, any]] = None, group: list[str] = None,
                 fill: str = None, order: dict[str, str] = None, limit: int = None, offset: int = None):
        self.queries = []
        self.fields = fields or []
        self.tableId = table_id
        self.nodeId = node_id
        self.departments = departments or set()
        self.where = where or {}
        self.group = group or []
        self.fill = fill
        self.order = order or {}
        self.limit = limit
        self.offset = offset

    def select(self, *fields: str) -> 'Builder':
        """
        查询的字段列表
        :param fields: 字段名称列表
        :return:
        """
        if not fields:
            raise ValueError("the select fields cannot be empty")
        self.fields.extend(fields)
        return self

    def select_as(self, field: str, alias: str) -> 'Builder':
        """
        设置查询字段及别名. 例如: select_as("max(\"score\")", "maxScore")
        :param field: 字段名称
        :param alias: 别名
        :return:
        """
        self.fields.append(f'{field} as {alias}')
        return self

    def table(self, table_id: str) -> 'Builder':
        """
        设置要查询的工作表标识. 该字段为必填项
        :param table_id: 工作表标识
        :return:
        """
        if not table_id:
            raise ValueError("the table_id cannot be empty")
        self.tableId = table_id.strip()
        return self

    def device(self, device_id: str) -> 'Builder':
        """
        设置要查询的资产编号
        :param device_id: 资产编号
        :return:
        """
        if not device_id:
            raise ValueError("the device_id cannot be empty")
        self.nodeId = device_id
        return self

    def department(self, *departments: str) -> 'Builder':
        """
        设置查询的资产所属部门
        :param departments: 部门ID列表
        :return:
        """
        if not departments:
            raise ValueError("the departments cannot be empty")
        self.departments.update(departments)
        return self

    def eq(self, tag: str, value: any) -> 'Builder':
        """
        相等条件
        :param tag: 数据点或标签名称
        :param value: 比较值
        :return:
        """
        if not tag:
            raise ValueError("the tag of where cause cannot be empty")
        self.where[tag] = {"$eq": value}
        return self

    def not_eq(self, tag: str, value: any) -> 'Builder':
        """
        不相等条件
        :param tag: 数据点或标签名称
        :param value: 比较值
        :return:
        """
        if not tag:
            raise ValueError("the tag of where cause cannot be empty")
        self.where[tag] = {"$ne": value}
        return self

    def lt(self, tag: str, value: any) -> 'Builder':
        """
        小于条件
        :param tag: 数据点或标签名称
        :param value: 比较值
        :return:
        """
        if not tag:
            raise ValueError("the tag of where cause cannot be empty")
        self.where[tag] = {"$lt": value}
        return self

    def lte(self, tag: str, value: any) -> 'Builder':
        """
        小于等于条件
        :param tag: 数据点或标签名称
        :param value: 比较值
        :return:
        """
        if not tag:
            raise ValueError("the tag of where cause cannot be empty")
        self.where[tag] = {"$lte": value}
        return self

    def gt(self, tag: str, value: any) -> 'Builder':
        """
        大于条件
        :param tag: 数据点或标签名称
        :param value: 比较值
        :return:
        """
        if not tag:
            raise ValueError("the tag of where cause cannot be empty")
        self.where[tag] = {"$gt": value}
        return self

    def gte(self, tag: str, value: any) -> 'Builder':
        """
        大于等于条件
        :param tag: 数据点或标签名称
        :param value: 比较值
        :return:
        """
        if not tag:
            raise ValueError("the tag of where cause cannot be empty")
        self.where[tag] = {"$gte": value}
        return self

    def time_between(self, start_time: datetime, end_time: datetime) -> 'Builder':
        """
        设置时间范围
        :param start_time: 开始时间
        :param end_time: 结束时间
        :return:
        """
        if not start_time or not end_time:
            raise ValueError("the start time and end time cannot be empty")
        causes = self.where.get("time", {})
        causes["$gte"] = f"'{start_time.strftime(DATE_TIME_FORMATTER)}'"
        causes["$lte"] = f"'{end_time.strftime(DATE_TIME_FORMATTER)}'"
        self.where["time"] = causes
        return self

    def start_time(self, start_time: datetime) -> 'Builder':
        """
        设置开始时间
        :param start_time: 开始时间
        :return:
        """
        if not start_time:
            raise ValueError("the start time cannot be empty")
        causes = self.where.get("time", {})
        causes["$gte"] = f"'{start_time.strftime(DATE_TIME_FORMATTER)}'"
        self.where["time"] = causes
        return self

    def end_time(self, end_time: datetime) -> 'Builder':
        """
        设置结束时间
        :param end_time: 结束时间
        :return:
        """
        if not end_time:
            raise ValueError("the end time cannot be empty")
        causes = self.where.get("time", {})
        causes["$lte"] = f"'{end_time.strftime(DATE_TIME_FORMATTER)}'"
        self.where["time"] = causes
        return self

    def since(self, since: str, contains_start_time: bool = False) -> 'Builder':
        """
        设置查询最近一段时间的数据
        :param since: 时间段. 例如: 1d 表示 1 天, 1h 表示 1 小时, 1m 表示 1 分钟
        :param contains_start_time: 是否包含开始时间
        :return:
        """
        if not since:
            raise ValueError("the since cannot be empty")
        causes = self.where.get("time", {})
        if contains_start_time:
            causes["$gte"] = f"now() - {since}"
        else:
            causes["$gt"] = f"now() - {since}"
        self.where["time"] = causes
        return self

    def group_by(self, column: str) -> 'Builder':
        """
        设置分组条件
        :param column: 分组字段
        :return:
        """
        if not column:
            raise ValueError("the group field cannot be empty")
        self.group.append(column)
        return self

    def group_by_device(self) -> 'Builder':
        """
        按资产分组
        :return:
        """
        self.group.append(TIMING_DEVICE_ID)
        return self

    def group_by_time(self, interval: str) -> 'Builder':
        """
        按时间段分组
        :param interval: 时间段. 例如: 1h 表示 1 小时, 1d 表示 1 天
        :return:
        """
        if not interval:
            raise ValueError("the interval of time group cannot be empty")
        self.group.append(f"time({interval})")
        return self

    def with_fill(self, value: str) -> 'Builder':
        """
        设置填充方式
        :param value: 填充方式. 可选值: none, null, previous, value 等
        :return:
        """
        if value:
            self.fill = value
        return self

    def order_by_time_desc(self) -> 'Builder':
        """
        按时间降序排序
        :return:
        """
        self.order.clear()
        self.order["time"] = "desc"
        return self

    def order_by_time_asc(self) -> 'Builder':
        """
        按时间升序排序
        :return:
        """
        self.order.clear()
        self.order["time"] = "asc"
        return self

    def order_by_asc(self, field: str) -> 'Builder':
        """
        按指定字段升序排序
        :param field: 字段名称
        :return:
        """
        self.order.clear()
        self.order[field] = "asc"
        return self

    def order_by_desc(self, field: str) -> 'Builder':
        """
        按指定字段降序排序
        :param field: 字段名称
        :return:
        """
        self.order.clear()
        self.order[field] = "desc"
        return self

    def with_limit(self, limit: int) -> 'Builder':
        """
        限制查询的记录数量
        :param limit: 记录数量
        :return:
        """
        if limit <= 0:
            raise ValueError("the limit must be greater than 0")
        self.limit = limit
        return self

    def with_offset(self, offset: int) -> 'Builder':
        """
        设置返回记录的偏移量
        :param offset: 偏移量
        :return:
        """
        if offset <= 0:
            raise ValueError("the offset must be greater than 0")
        self.offset = offset
        return self

    def finish(self):
        query = TimingDataQuery()

        if not self.fields or len(self.fields) == 0:
            raise ValueError("必须设置要查询的字段")

        query.fields = list(self.fields)

        if self.tableId or len(self.tableId) > 0:
            query.tableId = self.tableId
        else:
            raise ValueError("必须设置 tableId 字段")

        # 资产编号
        if self.nodeId:
            query.id = self.nodeId

        if self.departments and len(self.departments) > 0:
            query.deartment = list(self.departments)

        if self.fill:
            query.fill = self.fill

        if self.limit:
            query.limit = self.limit
        if self.offset:
            query.offset = self.offset

        if self.group and len(self.group) > 0:
            query.group = list(self.group)

        if self.order and len(self.order) > 0:
            order_str = ""
            for field, order_type in self.order.items():
                order_str += f"{field} {order_type} "
            query.order = order_str

        if self.where and len(self.where) > 0:
            where_causes = []
            for field, causes_map in self.where.items():
                for op, value in causes_map.items():
                    # value = f"'{value}'" if isinstance(value, str) else value
                    if op == "$eq":
                        where_causes.append(f"{field} = {value}")
                    elif op == "$ne":
                        where_causes.append(f"{field} != {value}")
                    elif op == "$gt":
                        where_causes.append(f"{field} > {value}")
                    elif op == "$gte":
                        where_causes.append(f"{field} >= {value}")
                    elif op == "$lt":
                        where_causes.append(f"{field} < {value}")
                    elif op == "$lte":
                        where_causes.append(f"{field} <= {value}")
                    else:
                        raise ValueError(f"不支持的逻辑运算符: {op}")

            query.where = where_causes

        self.queries.append(query)

        self.fields.clear()
        self.departments.clear()
        self.where.clear()
        self.group.clear()
        self.order.clear()

        self.tableId = ""
        self.nodeId = ""

        self.fill = ""

        self.limit = 0
        self.offset = 0

        return self

    def build(self) -> 'TimingDataQueries':
        return TimingDataQueries(self.queries)


class TimingDataQueries:
    queries: list['TimingDataQuery']

    def __init__(self, queries: list['TimingDataQuery']):
        self.queries = queries

    def serialize(self) -> str:
        data = [x.__dict__() for x in self.queries]
        return jsons.dumps(data, jdkwargs={'ensure_ascii': False, 'separators': (',', ':')})

    @staticmethod
    def new_builder() -> 'Builder':
        return Builder()


@dataclasses.dataclass
class TimingDataQuery:
    """
    时序数据查询
    """

    fields: List[str]
    tableId: str
    departments: Set[str]
    where: dict[str, dict[str, any]]
    group: list[str]
    order: dict[str, str]
    id: Optional[str] = None
    fill: Optional[str] = None
    limit: Optional[int] = None
    offset: Optional[int] = None

    def __init__(self, fields: list[str] = None, table_id: str = None, id: str = None,
                 departments: Set[str] = None, where: dict[str, dict[str, any]] = None, group: list[str] = None,
                 fill: str = None, order: dict[str, str] = None, limit: int = None, offset: int = None):
        self.fields = fields
        self.tableId = table_id
        self.id = id
        self.departments = departments
        self.where = where
        self.group = group
        self.fill = fill
        self.order = order
        self.limit = limit
        self.offset = offset

    def __dict__(self) -> dict:
        data = {"fields": self.fields, "tableId": self.tableId}
        if self.id:
            data["id"] = self.id
        if self.departments and len(self.departments) > 0:
            data["deartment"] = self.departments
        if self.where and len(self.where) > 0:
            data["where"] = self.where
        if self.group and len(self.group) > 0:
            data["group"] = self.group
        if self.fill:
            data["fill"] = self.fill
        if self.order and len(self.order) > 0:
            data["order"] = self.order
        if self.limit:
            data["limit"] = self.limit
        if self.offset:
            data["offset"] = self.offset
        return data


@dataclasses.dataclass
class Value:
    time: datetime
    values: dict[str, any]

    def __init__(self, columns: list[str], values: list):
        self.time = values[0]
        self.values = {columns[i]: values[i] for i in range(len(columns))}

    def get_time(self):
        return self.time

    def get_values(self):
        return self.values

    def get_value(self, column):
        return self.values.get(column)

    @staticmethod
    def from_data(columns: list[str], values: list) -> 'Value':
        time = datetime.fromisoformat(values[0])
        return Value(columns, values)


class TimingDataSeries:
    """
    时序数据序列.

    Attributes:
        name: 工作表标识
        tags: 标签信息. 如果查询时没有设置 group by, 则 tags 为空
        columns: 字段名称列表
        values: 时序数据列表
    """

    name: str
    tags: dict[str, str]
    columns: list[str]
    values: list[Value]

    def __init__(self, name, tags: Dict[str, str], columns: List[str], values: List[Value]):
        self.name = name
        self.tags = tags
        self.columns = columns
        self.values = values

    def get_tag(self, tag_name: str) -> Optional[str]:
        return self.tags.get(tag_name)


@dataclasses.dataclass
class TimingData:
    series: List[TimingDataSeries]

    def __init__(self, series: list[TimingDataSeries]):
        self.series = series


@dataclasses.dataclass
class BuiltinTimingDataSeries:
    name: str
    tags: dict[str, str]
    columns: list[str]
    values: list[list]

    def __init__(self, name: str, columns: list[str], values: list[list], tags: dict[str, str] = None):
        self.name = name
        self.tags = tags
        self.columns = columns
        self.values = values

    def get_name(self):
        return self.name

    def get_tags(self):
        return self.tags

    def get_columns(self):
        return self.columns

    def get_values(self):
        return self.values

    def parse(self):
        if self.name is None or self.columns is None or self.values is None:
            return None

        values = [Value(self.columns, v) for v in self.values]
        return TimingDataSeries(self.name, self.tags or {}, self.columns, values)


@dataclasses.dataclass
class BuiltinTimingDataSeriesBody:
    series: list[BuiltinTimingDataSeries]

    def __init__(self, series: list[BuiltinTimingDataSeries] = None):
        self.series = series or []


@dataclasses.dataclass
class BuiltinTimingDataQueryResult:
    results: list[BuiltinTimingDataSeriesBody]

    def __init__(self, results: list[BuiltinTimingDataSeriesBody] = None):
        self.results = results or []

    def parse(self):
        if not self.results or len(self.results) == 0:
            return []

        timing_data = []
        for result in self.results:
            if not result.series:
                continue
            series = []
            for s in result.series:
                if s is None:
                    continue
                ss = s.parse()
                if ss is not None:
                    series.append(ss)
            timing_data.append(TimingData(series))

        return timing_data


class TimingDataClient:
    """
    时序数据查询客户端
    """

    @abstractmethod
    def query(self, project_id: str, query: TimingDataQueries, headers: Optional[dict[str, str]] = None) -> Response[
        TimingData]:
        """
        查询时序数据
        :param project_id: 项目ID
        :param query: 查询信息
        :param headers: 自定义请求头
        :return:
        """
        pass
