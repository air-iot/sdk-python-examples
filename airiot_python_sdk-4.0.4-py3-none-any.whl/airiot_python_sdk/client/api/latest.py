import dataclasses
from abc import abstractmethod
from typing import Optional

import jsons

from airiot_python_sdk.client.api import Response


@dataclasses.dataclass
class LatestQuery:
    """
    查询数据点最新数据请求参数. 查询时, 可以查询设备下所有数据点的最新数据, 也可以查询指定数据点的最新数据.
    如果查询设备下所有数据点的最新数据, 需要设置 allTags 为 true. 如果查询指定数据点的最新数据, 需要设置 tagId 为目标数据点标识.
    如果要查询设备的部分数据点的最新数据, 可以添加多个 LatestQuery 对象到数组中.
    例如: [LatestQuery("SN001", tag_id: "tag1"), LatestQuery("SN001", tag_id: "tag2")]

    Attributes:
        tableId: 资产所属工作表标识, 必填.
        id: 资产编号, 必填.
        allTag: 查询所有数据点时设置为 True, 选填.
        tagId: 查询指定数据点时设置为目标数据点的标识, 选填.
    """

    def __init__(self, table_id: str, device_id: str, all_tag: Optional[bool] = None, tag_id: Optional[str] = None):
        self.tableId = table_id
        self.id = device_id
        self.allTag = all_tag
        self.tagId = tag_id

    # 资产所属工作表标识
    tableId: str
    # 资产编号
    id: str
    # 是否查询该设备下所有数据点
    allTag: Optional[bool] = None
    # 数据点标识
    tagId: Optional[str] = None

    def __dict__(self) -> dict:
        data = {"tableId": self.tableId, "id": self.id}
        if self.allTag is not None:
            data["allTag"] = self.allTag
        if self.tagId is not None:
            data["tagId"] = self.tagId
        return data


@dataclasses.dataclass
class LatestQueries:
    queries: list[LatestQuery]

    def __init__(self, queries: list[LatestQuery] = None):
        self.queries = [] if not queries else queries

    def append(self, query: LatestQuery):
        self.queries.append(query)

    def serialize(self) -> str:
        data = [x.__dict__() for x in self.queries]
        return jsons.dumps(data, jdkwargs={'ensure_ascii': False})


@dataclasses.dataclass
class LatestData:
    """
    数据点最新数据查询结果. 查询结果中包含了数据点的标识, 最新数据的时间戳和值.

    Attributes:
        tableId: 资产所属工作表标识
        id: 资产编号
        tagId: 数据点标识
        time: 最新数据的时间戳
        value: 最新数据的值. 如果该数据点没有数据, 则为 None
    """

    def __init__(self, tableId: str, id: str, tagId: str, time: int, value):
        self.tableId = tableId
        self.id = id
        self.tagId = tagId
        self.time = time
        self.value = value

    # 资产所属工作表标识
    tableId: str
    # 资产编号
    id: str
    # 数据点标识
    tagId: str
    # 时间戳(ms)
    time: int
    # 最新数据的值
    value: any


class LatestClient:
    """
    查询数据点最新数据客户端接口
    """

    @abstractmethod
    def get(self, project_id: str, query: LatestQueries, headers: Optional[dict[str, str]] = None) -> Response[
        list[LatestData]]:
        """
        查询数据点最新数据
        :param project_id: 项目ID
        :param query: 查询的设备和数据点信息
        :param headers: 自定义请求头
        :return:
        """
        pass

    def get_by_device_id(self, project_id: str, table_id: str, device_id: str,
                         headers: Optional[dict[str, str]] = None) -> Response[
        list[LatestData]]:
        """
        根据设备编号查询所有数据点最新数据
        :param project_id: 项目ID
        :param table_id: 资产所属工作表标识
        :param device_id: 设备编号
        :param headers: 自定义请求头
        :return:
        """
        return self.get(project_id, LatestQueries([LatestQuery(table_id, device_id, all_tag=True)]), headers)

    def get_device_tag(self, project_id: str, table_id: str, device_id: str, tag_id: str,
                       headers: Optional[dict[str, str]] = None) -> Response[
        list[LatestData]]:
        """
        根据设备编号和数据点标识查询最新数据
        :param project_id: 项目ID
        :param table_id: 资产所属工作表标识
        :param device_id: 设备编号
        :param tag_id: 数据点标识
        :param headers: 自定义请求头
        :return:
        """
        return self.get(project_id, LatestQueries([LatestQuery(table_id, device_id, tag_id=tag_id)]), headers)

    def get_device_tags(self, project_id: str, table_id: str, device_id: str, tag_ids: list[str],
                        headers: Optional[dict[str, str]] = None) -> Response[
        list[LatestData]]:
        """
        查询一个设备下多个数据点的最新数据
        :param project_id: 项目ID
        :param table_id: 资产所属工作表标识
        :param device_id: 设备编号
        :param tag_ids: 数据点标识列表
        :param headers: 自定义请求头
        :return:
        """
        return self.get(project_id,
                        LatestQueries([LatestQuery(table_id, device_id, tag_id=tag_id) for tag_id in tag_ids]), headers)

    def get_every_device(self, project_id: str, table_id: str, device_ids: list[str], tag_id: str,
                         headers: Optional[dict[str, str]] = None) -> Response[list[LatestData]]:
        """
        查询多个设备的同一个数据点的最新数据
        :param project_id: 项目ID
        :param table_id: 资产所属工作表标识
        :param device_ids: 设备编号列表
        :param tag_id: 数据点标识
        :param headers: 自定义请求头
        :return:
        """
        return self.get(project_id,
                        LatestQueries([LatestQuery(table_id, device_id, tag_id=tag_id) for device_id in device_ids]),
                        headers)
