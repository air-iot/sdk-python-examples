

class Response:
    """
    请求响应
    """

    # 请求是否成功标识
    success = True
    # 请求响应状态码. 请求成功时为200, 请求失败时为相应的业务错误码
    code: int = 200
    # 响应信息. 当请求失败时保存错误信息
    message: str = "OK"
    # 详细信息. 当请求失败时保存详细错误信息
    detail: str = ""
    # 请求响应数据
    data: any = None

    def __str__(self):
        return "Response{" + \
               "success=" + str(self.success) + \
               ", code=" + str(self.code) + \
               ", message='" + str(self.message) + '\'' + \
               ", detail='" + str(self.detail) + '\'' + \
               ", data=" + str(self.data) + \
               '}'


def ok(message: str, detail: str) -> Response:
    """
    请求成功响应, 该请求响应中不包含数据
    :param message: 响应信息
    :param detail: 详细信息
    :return: 响应信息
    """
    resp = Response()
    resp.message = message
    resp.detail = detail
    return resp


def ok_only_data(data: any) -> Response:
    """
    请求成功响应, 该请求响应中只包含数据
    :param data: 响应数据
    :return: 响应信息
    """
    resp = Response()
    resp.data = data
    return resp


def ok_with_data(message: str, detail: str, data: any) -> Response:
    """
    请求成功响应, 该请求响应中包含响应信息和数据
    :param message: 响应信息
    :param detail: 详细信息
    :param data: 响应数据
    :return: 响应信息
    """
    resp = Response()
    resp.message = message
    resp.detail = detail
    resp.data = data
    return resp


def fail(code: int, message: str, detail: str) -> Response:
    """
    请求失败响应
    :param code: 响应码
    :param message: 响应信息
    :param detail: 详细信息
    :return: 响应信息
    """
    resp = Response()
    resp.success = False
    resp.code = code
    resp.message = message
    resp.detail = detail
    return resp
