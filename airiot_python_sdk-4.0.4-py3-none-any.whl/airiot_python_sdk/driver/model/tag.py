import dataclasses
from typing import List, Optional

from _decimal import Decimal


@dataclasses.dataclass
class TagValue:
    """
    数据点 - 数值转换配置信息

    Attributes:
        minValue: 最小值
        maxValue: 最大值
        minRaw: 原始最小值
        maxRaw: 原始最大值
    """

    # 最小值
    minValue: Optional[float]
    # 最大值
    maxValue: Optional[float]
    # 原始最小值
    minRaw: Optional[float]
    # 原始最大值
    maxRaw: Optional[float]


@dataclasses.dataclass
class RangeCondition:
    """
    数据点 - 有效范围或无效范围配置信息

    Attributes:
        mode: 处理模式. 取值: number(数值), rate(变化率), delta(差值)
            number 比较当前采集到的数据是否在设定的有效范围内
            rate 比较当前采集到的数据与上一次采集到的数据的变化率是否在设定的有效范围内
            delta 比较当前采集到的数据与上一次采集到的数据的差值是否在设定的有效范围内
        condition: 判断条件类型, 取值: range(范围值), greater(大于), less (小于)
            range 当前采集到的数据必须在设定的有效范围内. 即: minValue <= value <= maxValue
            greater 当前采集到的数据必须大于设定的有效范围. 即: value > maxValue
            less 当前采集到的数据必须小于设定的有效范围. 即: value < minValue
        minValue: 最小值
        maxValue: 最大值
        value: 大于或小于的有效值, 只有当 condition 为 greater 或 less 时有效
        defaultCondition: 是否为默认处理条件, 当所有条件都不满足时, 是否使用该条件进行处理
        invalidType: 无效值类型. 只在无效范围时有效. 该信息会被一直发送到平台
    """

    # 处理模式
    mode: Optional[str]
    # 判断条件类型
    condition: Optional[str]
    # 最小值
    minValue: Optional[float]
    # 最大值
    maxValue: Optional[float]
    # 大于或小于的有效值
    value: Optional[float]
    # 是否为默认处理条件
    defaultCondition: bool
    # 无效值类型. 只在无效范围时有效
    invalidType: Optional[str]

    def is_ok(self):
        """
        判断配置是否正确
        :return:
        """
        if self.mode not in ["number", "rate", "delta"]:
            return False

        if self.condition not in ["range", "greater", "less"]:
            return False

        if self.condition == "range":
            if self.minValue is None or self.maxValue is None:
                return False
            elif self.minValue > self.maxValue:
                return False
        elif self.condition == "greater":
            if self.maxValue is None:
                return False
        elif self.condition == "less":
            if self.minValue is None:
                return False

        return True

    def matched(self, new_value: Decimal, cache_value: Optional[Decimal]) -> bool:
        # 如果是变化率或差值并且缓存值不存在, 则不进行处理
        if (self.mode == "rate" or self.mode == "delta") and cache_value is None:
            return True

        val = float(self.calc_value(new_value, cache_value))

        if self.condition == "range":
            return self.minValue <= val <= self.maxValue
        elif self.condition == "greater":
            return val >= self.maxValue
        elif self.condition == "less":
            return val <= self.minValue

        return False

    def calc_value(self, new_value: Decimal, cache_value: Decimal) -> Decimal:
        if self.mode == "number":
            return new_value
        elif self.mode == "rate":
            return (new_value - cache_value) / cache_value
        elif self.mode == "delta":
            return new_value - cache_value

    def calc_valid_value(self, new_value: Decimal, cache_value: Decimal) -> float:
        val = self.calc_value(new_value, cache_value)
        if self.mode == "number":
            if self.condition == "range":
                if val < self.minValue:
                    return self.minValue
                elif val > self.maxValue:
                    return self.maxValue
            elif self.condition == "greater":
                return self.maxValue
            elif self.condition == "less":
                return self.minValue
        elif self.mode == "rate":
            min_val = float(self.minValue / 100 * cache_value + cache_value)
            max_val = float(self.maxValue / 100 * cache_value + cache_value)
            if self.condition == "range":
                if val < self.minValue:
                    return min_val
                elif val > self.maxValue:
                    return max_val
            elif self.condition == "greater":
                return max_val
            elif self.condition == "less":
                return min_val
        elif self.mode == "delta":
            if self.condition == "range":
                if val < self.minValue:
                    return float(cache_value + self.minValue)
                elif val > self.maxValue:
                    return float(cache_value + self.maxValue)
            elif self.condition == "greater":
                return float(cache_value + self.maxValue)
            elif self.condition == "less":
                return float(cache_value + self.minValue)


@dataclasses.dataclass
class Range:
    """
    数据点 - 有效范围或无效范围配置信息

    Attributes:
        method: 配置类型. 取值: valid(有效范围), invalid(无效范围)
        conditions: 范围配置
        minValue: 最小值
        maxValue: 最大值
        fixedValue: 固定值
        active: 范围不匹配时的处理动作. 取值: fixed(固定值, 即 fixedValue 为作最终值), boundary(边界值), latest(最新有效值), discard(丢弃)
        invalidAction: 无效值处理动作. 当数据判定为无效时的动作. 取值: save(保存无效值)
    """

    # 配置类型. 取值: valid(有效范围), invalid(无效范围)
    method: Optional[str]
    # 范围配置
    conditions: List[RangeCondition]
    # 最小值
    minValue: Optional[float]
    # 最大值
    maxValue: Optional[float]
    # 最大值
    fixedValue: Optional[float]
    # 范围不匹配时的处理动作. 取值: fixed(固定值), boundary(边界值), latest(最新有效值), discard(丢弃)
    active: Optional[str]
    # 无效值处理动作. 当数据判定为无效时的动作. 取值: save(保存无效值)
    invalidAction: Optional[str]


@dataclasses.dataclass
class Tag:
    """
    数据点基础信息

    Attributes:
        id: 数据点标识
        name: 数据点名称
        tagValue: 数据点 - 数值转换配置信息
        range: 数据点 - 有效范围或无效范围配置信息
        fixed: 数据点-小数位数
        mod: 数据点-缩放比例
    """

    # 数据点标识
    id: str
    # 数据点名称
    name: str
    # 数据点 - 数值转换配置信息
    tagValue: Optional[TagValue]
    # 数据点 - 有效范围或无效范围配置信息
    range: Optional[Range]
    # 数据点-小数位数配置
    fixed: Optional[int]
    # 数据点-缩放比例配置
    mod: Optional[int]
