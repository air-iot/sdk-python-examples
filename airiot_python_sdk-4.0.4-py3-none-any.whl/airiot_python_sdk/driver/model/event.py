

class Event:
    """
    事件信息

    Attributes:
        id: 设备编号
        table: 设备所属工作表标识
        eventId: 事件ID
        time: 事件产生的时间(时间戳)
        data: 事件数据
    """

    # 设备编号
    id: str
    # 设备所属工作表标识
    table: str
    # 事件ID
    eventId: str
    # 事件产生的时间(时间戳)
    time: int
    # 事件数据
    data: any
