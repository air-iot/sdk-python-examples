import json
import logging
from typing import Optional

import jsons
from paho.mqtt import client as mqtt_client

from airiot_python_sdk.driver.config import MqttConfig
from airiot_python_sdk.driver.handler import DataHandlerChain
from airiot_python_sdk.driver.model.point import SimplePoint
from airiot_python_sdk.driver.model.warning import WarningRecovery, WarningData
from airiot_python_sdk.driver.service import DataSender

logger = logging.getLogger("mqtt_data_sender")


class MQTTDataSender(DataSender):
    """
    MQTT 协议数据发送器, 用于向平台发送数据
    """

    # mqtt 客户端
    client: Optional[mqtt_client.Client] = None
    # mqtt config
    config: MqttConfig
    # 连接状态
    connected: bool = False

    def __init__(self, project_id: str, driver_id: str, driver_name: str, service_id: str, config: MqttConfig,
                 chain: DataHandlerChain):
        super().__init__(project_id, driver_id, driver_name, service_id, chain)
        self.config = config
        self.json_encoder = json.JSONEncoder()

    def __write_point__(self, point: SimplePoint):
        if not self.client.is_connected():
            raise Exception("mqtt data sender is disconnected")

        topic = "data/{}/{}/{}".format(self.project_id, point.table, point.id)
        point.source = "device"
        payload = jsons.dumps(point)
        self.client.publish(topic, payload=payload, qos=0)

    def __log__(self, level: str, table_id: str, device_id: str, message: str):
        topic = "logs/{}/{}/{}/{}".format(self.project_id, level, table_id, device_id)
        self.client.publish(topic, payload=message, qos=0)

    def send_warning(self, warning: WarningData):
        topic = f"warningStorage/{self.project_id}/{warning.table.id}/{warning.tableData.id}"
        message = jsons.dumps(warning)
        result = self.client.publish(topic, payload=message, qos=0)
        result.wait_for_publish(timeout=5)
        print("send warning result: ", result.is_published())

    def send_warning_recovery(self, table_id: str, device_id: str, recovery: WarningRecovery):
        topic = f"warningUpdate/{self.project_id}/{table_id}/{device_id}"
        message = jsons.dumps(recovery)
        result = self.client.publish(topic, payload=message, qos=0)
        result.wait_for_publish(timeout=5)
        print("send warning recovery result: ", result.is_published())

    def start(self):

        logger.info("start connect to mqtt server, %s", self.config)

        self.client = mqtt_client.Client("driver_{}_{}".format(self.driver_id, self.service_id),
                                         clean_session=True, protocol=self.config.version)
        self.client.username_pw_set(self.config.username, self.config.password)
        self.client._connect_timeout = self.config.connect_timeout
        self.client.reconnect_delay_set(min_delay=1, max_delay=120)
        self.client.on_connect = self.__on_connect__
        self.client.on_disconnect = self.__on_disconnect__
        self.client.connect(host=self.config.host, port=self.config.port, keepalive=self.config.keepalive)
        self.client.loop_start()

    def stop(self):
        if self.client is not None:
            self.client.loop_stop(force=True)
            self.client.disconnect()
            self.client = None

    def __on_connect__(self, client, userdata, flags, rc):
        logger.info("mqtt data sender is connected")

    def __on_disconnect__(self, client, userdata, rc):
        logger.error("mqtt data sender disconnected, reasonCode = %d", rc)
