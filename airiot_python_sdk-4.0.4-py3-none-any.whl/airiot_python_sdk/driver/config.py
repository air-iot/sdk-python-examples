from enum import Enum
from typing import Optional


class DataSenderType(str, Enum):
    """
    数据发送方式

    Attributes:
        MQTT: MQTT 协议
        KAFKA: Kafka 协议
    """

    MQTT = "mqtt"
    KAFKA = "kafka"


class MqttConfig:
    host: str = "mqtt"
    port: int = 1883
    username: str = "admin"
    password: str = "public"
    version: int = 4
    keepalive: int = 60
    reconnect_interval: int = 30
    connect_timeout: int = 15
    publish_timeout: int = 5

    def __str__(self) -> str:
        return "MqttConfig(host={}, port={}, username={}, password={}, version={}, keepalive={}, reconnect_interval={}, connect_timeout={}, publish_timeout={})".format(
            self.host, self.port, self.username, self.password, self.version, self.keepalive, self.reconnect_interval,
            self.connect_timeout, self.publish_timeout
        )


class KafkaConfig:
    # kafka brokers
    brokers: list[str] = ["kafka:9092"]
    # 自定义发送分区
    partition: Optional[int] = None
    # 连接超时(s)
    connect_timeout: int = 5
    # 重连间隔(s)
    reconnect_interval: int = 5
    # 请求超时(s)
    deliver_timeout: int = 5

    def __str__(self) -> str:
        return "KafkaConfig(brokers={}, partition={}, connect_timeout={}, reconnect_interval={}, deliver_timeout={})".format(
            self.brokers, self.partition, self.connect_timeout, self.reconnect_interval, self.deliver_timeout
        )


class DataConfig:
    """
    数据发送配置
    """

    type: DataSenderType = DataSenderType.MQTT
    mqtt: MqttConfig = MqttConfig()
    kafka: KafkaConfig = KafkaConfig()

    def __str__(self):
        return "DataConfig(type={}, mqtt={}, rabbitmq={})".format(
            self.type, self.mqtt, self.rabbitmq
        )


class DriverGrpcConfig:
    """
    driver gRPC 服务配置

    Attributes:
        host: driver 服务地址
        port: driver 服务端口, 默认为 9224
        health_check_interval: 健康检查间隔, 默认为 30s
    """

    host: str = "driver"
    port: int = 9224
    health_check_interval: int = 30

    def __str__(self):
        return "DriverGrpcConfig(host={}, port={}, health_check_interval={})".format(
            self.host, self.port, self.health_check_interval
        )


class DriverConfig:
    """
    驱动启动配置
    """

    # 项目ID
    project_id: str
    # 驱动ID
    id: str
    # 驱动名称
    name: str
    # 驱动实例ID
    service_id: str
    distributed: str

    # driver 服务配置
    driver_grpc: DriverGrpcConfig = DriverGrpcConfig()
    # DataSender 配置
    data: DataConfig = DataConfig()

    def __init__(self, project: str = None, service_id: str = None, id: str = None, name: str = None,
                 distributed: str = None,
                 driver_grpc: DriverGrpcConfig = None, mq: DataConfig = None):
        self.project_id = project
        self.id = id
        self.name = name
        self.service_id = service_id
        self.distributed = distributed
        self.driver_grpc = driver_grpc
        self.data = DataConfig() if not mq else mq

    def __str__(self):
        return "DriverConfig(projectId={}, id={}, name={}, serviceId={}, distributed={}, driverGrpc={}, data={})".format(
            self.project_id, self.id, self.name, self.service_id, self.distributed, self.driver_grpc, self.data
        )
