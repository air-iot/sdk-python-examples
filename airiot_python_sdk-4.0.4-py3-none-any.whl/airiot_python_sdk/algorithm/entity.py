import dataclasses


@dataclasses.dataclass
class Request:
    """
    算法执行请求

    Attributes:
        projectID: 项目ID
        function: 算法函数名
        input: 算法输入
    """

    projectID: str
    function: str
    input: dict


class Response:
    """
    算法执行响应

    Attributes:
        code: 响应码
        error: 错误信息
        result: 算法执行结果
    """

    code: int = 200
    error: str = ""
    result: any = None

    def __str__(self):
        return f"Response{{code={self.code}, error='{self.error}', result={self.result}}}"
