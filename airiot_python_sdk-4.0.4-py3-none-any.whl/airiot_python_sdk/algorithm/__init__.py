from abc import abstractmethod


def algorithm_function(**kwds):
    """
    算法函数装饰器, 通过该装饰器可以将一个函数注册为算法函数.
    该装饰器修饰的函数必须是一个异步函数, 函数名不能以 __ 开头和结尾,
    并且第 1 个参数是 str 类型, 用于接收发送请求的项目ID, 第 2 个参数是 dict[str, any] 类型, 用于接收请求参数.
    :param kwds: 要求装饰器必须传入一个 name 参数, 该参数是算法函数的名称.
    :return:
    """

    if "name" not in kwds:
        raise ValueError("algorithm function name is required")

    def decorate(fn):
        fn.__annotations__["algorithm_function"] = kwds["name"]
        return fn

    return decorate


class AlgorithmApp:
    """
    算法应用程序基类, 通过继承该类可以实现一个算法应用程序.
    """

    @abstractmethod
    def id(self) -> str:
        """
        算法应用程序ID
        :return:
        """
        pass

    @abstractmethod
    def name(self) -> str:
        """
        算法应用程序名称
        :return:
        """

    @abstractmethod
    def start(self):
        """
        算法应用程序启动时执行的方法. 可以在此方法中进行一些初始化操作.
        :return:
        """
        pass

    @abstractmethod
    def stop(self):
        """
        算法应用程序停止时执行的方法. 可以在此方法中进行一些清理操作.
        :return:
        """
        pass

    @abstractmethod
    async def schema(self) -> str:
        """
        算法应用程序的 schema 定义.
        :return:
        """
        pass

    @abstractmethod
    async def run(self, project_id: str, function: str, params: dict[str, any]) -> [dict[str, any] | object]:
        """
        算法执行方法. 该方法会在算法执行请求到达时被调用.
        :param project_id: 请求执行算法的项目ID
        :param function: 请求执行的算法函数名
        :param params: 请求执行的算法参数
        :return: 算法执行结果
        """
        pass
