from typing import Optional

from airiot_python_sdk.client.api import Response, set_project_header
from airiot_python_sdk.client.api.timing_data import TimingDataClient, TimingData, TimingDataQueries, \
    BuiltinTimingDataQueryResult
from airiot_python_sdk.client.sync import BaseClient


class SyncTimingDataClient(TimingDataClient):
    base_client: BaseClient

    def __init__(self, base_client: BaseClient):
        self.base_client = base_client

    def query(self, project_id: str, query: TimingDataQueries, headers: Optional[dict[str, str]] = None) -> Response[
        TimingData]:
        headers = set_project_header(project_id, headers)
        query_str = query.serialize()
        response = self.base_client.perform_get(f"/core/data/query?query={query_str}", headers=headers,
                                                cls=BuiltinTimingDataQueryResult)
        if not response.success or response.data is None:
            return Response(success=False, message=response.message, detail=response.detail, field=response.field,
                            code=response.code)

        timing_data = response.data.parse()
        return Response(success=True, data=timing_data, message=response.message, detail=response.detail,
                        field=response.field, code=response.code)
