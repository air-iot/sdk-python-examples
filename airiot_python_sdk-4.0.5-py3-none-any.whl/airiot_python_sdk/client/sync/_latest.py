from typing import Optional

import jsons

from airiot_python_sdk.client.api import Response, set_project_header
from airiot_python_sdk.client.api.latest import LatestClient, LatestQueries, LatestData
from airiot_python_sdk.client.sync import BaseClient


class SyncLatestClient(LatestClient):
    base_client: BaseClient

    def __init__(self, base_client: BaseClient):
        self.base_client = base_client

    def get(self, project_id: str, query: LatestQueries, headers: Optional[dict[str, str]] = None) -> Response[
        list[LatestData]]:
        headers = set_project_header(project_id, headers)
        query_str = query.serialize()
        return self.base_client.perform_get(f"/core/data/latest?query={query_str}", headers=headers, cls=list[LatestData])
