from abc import abstractmethod
from typing import List

from airiot_python_sdk.driver.service import DataSender


class DriverApp:
    """
    驱动程序接口. 该接口定义驱动程序与平台交互的方法. 所有驱动程序都需要实现该接口.
    """

    @abstractmethod
    def get_version(self) -> str:
        """
        获取驱动版本号. 例如: v4.0.0
        :return: 驱动版本号
        """
        pass

    @abstractmethod
    def http_proxy_enabled(self) -> bool:
        """
        是否启用 HTTP 请求代理. 用于代理驱动中的 HTTP 请求, 可以将驱动中的一些功能通过 grpc 代理暴露给平台, 由平台代理驱动中的 HTTP 请求.
        :return: 是否启用 HTTP 请求代理. 返回 False 表示不启用, 返回 True 表示启用.
        """
        return False

    @abstractmethod
    async def http_proxy(self, request_type: str, headers: dict[str, List[str]], data: str) -> any:
        """
        HTTP 请求代理. 用于代理驱动中的 HTTP 请求, 例如: 获取设备数据, 获取设备属性, 控制设备等.\r\n
        当前端请求驱动时, 会将请求转发给平台的 driver 服务, 由 driver 服务通过 listener 协议转发到驱动中, 由驱动自行处理请求并返回响应结果.\r\n
        前端 <- http -> driver <- listener -> DriverApp
        :param request_type: 请求类型标识, 每个请求类型标识对应一个请求. 例如: getDevices 表示查询设备列表请求.
        :param headers: 请求头, 即前端请求时传递的 headers.
        :param data: 请求参数.
        :return: 请求响应结果
        """
        pass

    @abstractmethod
    async def start(self, config: str):
        """
        启动驱动. 当驱动程序启动时, SDK 会连接平台 driver 服务, 连接成功后会调用此方法.
        :param config: 驱动配置, 即使用该驱动实例的工作表、设备等信息.
        :return:
        """
        pass

    @abstractmethod
    async def stop(self):
        """
        停止驱动. 当驱动程序停止时, SDK 会断开平台 driver 服务的连接, 断开连接后会调用此方法.
        :return:
        """
        pass

    @abstractmethod
    async def run(self, serial_no: str, table_id: str, device_id: str, command: str) -> any:
        """
        执行设备命令. 当前端需要控制设备时, 会调用此方法.
        :param serial_no: 平台指令序列号, 每次发送指令时, 平台会生成一个唯一的序列号, 用于标识本次指令.
        :param table_id: 设备所属工作表 ID.
        :param device_id: 设备编号.
        :param command: 指令内容.
        :return: 指令执行结果
        """
        pass

    @abstractmethod
    async def batch_run(self, serial_no: str, table_id: str, device_ids: List[str], command: str) -> any:
        """
        批量执行设备命令. 当前端需要控制多个设备时, 会调用此方法.
        :param serial_no: 平台指令序列号, 每次发送指令时, 平台会生成一个唯一的序列号, 用于标识本次指令.
        :param table_id: 设备所属工作表 ID.
        :param device_ids: 设备编号列表.
        :param command: 指令内容.
        :return: 指令执行结果
        """
        pass

    @abstractmethod
    async def write_tag(self, serial_no: str, table_id: str, device_id: str, tag: str) -> any:
        """
        向设备的指定数据点写入数据. 只有数据点的 rw 为 true 的数据点, 才能被写入数据.
        :param serial_no: 平台指令序列号, 每次发送指令时, 平台会生成一个唯一的序列号, 用于标识本次指令.
        :param table_id: 设备所属工作表 ID.
        :param device_id: 设备编号列表.
        :param tag: 数据点信息及写入的值.
        :return: 指令执行结果
        """
        pass

    @abstractmethod
    async def debug(self, debug: str) -> str:
        """
        驱动调试. 当前端需要调试驱动时, 会调用此方法.(该方法暂未开放)
        :param debug: 调试内容.
        :return: 调试结果
        """
        pass

    @abstractmethod
    async def schema(self) -> str:
        """
        获取驱动的 schema. 当前端需要获取驱动的 schema 时, 会调用此方法.
        :return: 驱动的 schema 定义
        """


class DriverAppFactory:
    """
    驱动程序实例构造工厂接口. 该接口定义驱动程序实例构造工厂的方法. 所有驱动程序实例构造工厂都需要实现该接口.
    """

    @abstractmethod
    def create(self, service_id: str, data_sender: DataSender) -> DriverApp:
        """
        驱动程序实例构造工厂
        :param service_id: 驱动实例ID
        :param data_sender: 数据发送器
        :return: 驱动程序实例
        """
        pass
