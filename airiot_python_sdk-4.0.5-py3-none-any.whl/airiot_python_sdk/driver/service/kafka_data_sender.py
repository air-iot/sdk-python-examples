import json
import logging
from typing import Optional

import confluent_kafka
import jsons

from airiot_python_sdk.driver.config import KafkaConfig
from airiot_python_sdk.driver.handler import DataHandlerChain
from airiot_python_sdk.driver.model.point import SimplePoint
from airiot_python_sdk.driver.model.warning import WarningRecovery, WarningData
from airiot_python_sdk.driver.service import DataSender

logger = logging.getLogger("kafka_data_sender")


class KafkaDataSender(DataSender):
    """
    Kafka 协议数据发送器, 用于向平台发送数据
    """

    # kafka producer
    client: Optional[confluent_kafka.Producer] = None
    # mqtt config
    config: KafkaConfig
    # 连接状态
    connected: bool = False

    def __init__(self, project_id: str, driver_id: str, driver_name: str, service_id: str, config: KafkaConfig,
                 chain: DataHandlerChain):
        super().__init__(project_id, driver_id, driver_name, service_id, chain)
        self.config = config
        self.json_encoder = json.JSONEncoder()

    def __write_point__(self, point: SimplePoint):
        key = "{}/{}/{}".format(self.project_id, point.table, point.id)
        point.source = "device"
        message = jsons.dumps(point)
        self.client.produce("data", key=key, value=message)

    def __log__(self, level: str, table_id: str, device_id: str, message: str):
        key = "{}/{}/{}/{}".format(self.project_id, level, table_id, device_id)
        self.client.produce("logs", key=key, value=message)
        pass

    def send_warning(self, warning: WarningData):
        key = "{}/{}/{}".format(self.project_id, warning.table.id, warning.tableData.id)
        message = jsons.dumps(warning)
        self.client.produce("warningStorage", key, message, partition=self.config.partition)

    def send_warning_recovery(self, table_id: str, device_id: str, recovery: WarningRecovery):
        key = "{}/{}/{}".format(self.project_id, table_id, device_id)
        message = jsons.dumps(recovery)
        self.client.produce("warningUpdate", key, message, partition=self.config.partition)

    def start(self):
        logger.info("start connect to kafka, %s", self.config)

        self.client = confluent_kafka.Producer({
            'client.id': "driver_{}_{}".format(self.driver_id, self.service_id),
            'bootstrap.servers': ",".join(self.config.brokers),
            'socket.connection.setup.timeout.ms': self.config.connect_timeout * 1000,
            'reconnect.backoff.ms': self.config.reconnect_interval * 1000,
            'reconnect.backoff.max.ms': self.config.reconnect_interval * 3 * 1000,
            'linger.ms': 500,
            'batch.size': 100,
            'request.timeout.ms': self.config.deliver_timeout * 1000 / 3,
            'delivery.timeout.ms': self.config.deliver_timeout * 1000,
        })

    def stop(self):
        pass
