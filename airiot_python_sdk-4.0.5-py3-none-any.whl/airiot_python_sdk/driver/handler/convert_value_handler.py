import math
from decimal import Decimal
from . import DataHandler
from ..model.tag import Tag, TagValue


class ConvertValueDataHandler(DataHandler):
    """
    将当前数据点的值按在 minRawValue 和 maxRawValue 间位置(百分比, 即: value / (maxRawValue - minRawValue)) 映射到minValue 和 maxValue 间相同百分比的值.

    计算规则:(当前值 - minRawValue) / (maxRawValue - minRawValue) * (maxValue - minValue) + minValue

    假设场景, 某温度计可测量温度范围为 -50.00 到 50.00, 精确到小数点后2位, 并且使用整数值表示温度(即接收到的数据为实际温度 * 100), 例如: 实际温度为 24.52, 接收到的值为 2452.
    使用映射功能将数值还原实际温度.
    表示接收到的温度值测量范围: 温度值 * 100
        minRawValue: -5000
        maxRawValue: 5000
    实际温度值测量范围
        minValue: -50
        maxValue: 50
    1. 当接收到的温度值为 -5000 时, 映射后的值为 -50
    2. 当接收到的温度值为 0 时, 映射后的值为 0
    3. 当接收到的温度值为 5000 时, 映射后的值为 50
    4. 当接收到的温度值为 2358 时, 映射后的值为 23.58
    5. 当接收到的温度值为 -2358 时, 映射后的值为 -23.58
    """

    def name(self) -> str:
        return "数值转换"

    def support(self, table_id: str, device_id: str, tag: Tag, value: any) -> bool:
        if tag is None or value is None:
            return False

        # 数据数据点的值不是数值类型时
        if not isinstance(value, int) and not isinstance(value, float):
            return False

        if tag.tagValue is None:
            return False

        tag_value: TagValue = tag.tagValue
        if tag_value.minValue is None or tag_value.maxValue is None or tag_value.minRaw is None or tag_value.maxRaw is None:
            return False

        return True

    async def handle(self, table_id: str, device_id: str, tag: Tag, value: any) -> dict[str, any]:
        if math.isnan(value) or math.isinf(value):
            return {}

        tag_value: TagValue = tag.tagValue

        min_raw = Decimal.from_float(tag_value.minRaw)
        max_raw = Decimal.from_float(tag_value.maxRaw)
        min_value = Decimal.from_float(tag_value.minValue)
        max_value = Decimal.from_float(tag_value.maxValue)

        # 如果原始最大值和最小值相等, 则不进行映射
        if min_raw.compare(max_raw) == Decimal('0'):
            return {tag.id: value}

        val = Decimal.from_float(value)

        val: Decimal = max(val, min_raw)
        val: Decimal = min(val, max_raw)

        # 计算规则: (当前值 - minRawValue) / (maxRawValue - minRawValue) * (maxValue - minValue) + minValue
        val = (val - min_raw) / (max_raw - min_raw) * (max_value - min_value) + min_value

        return {tag.id: float(val)}

    def order(self) -> int:
        return 5000
