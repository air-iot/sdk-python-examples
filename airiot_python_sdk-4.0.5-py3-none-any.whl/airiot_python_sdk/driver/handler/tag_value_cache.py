import asyncio
from datetime import datetime
from typing import Optional


class TagValue:
    """
    数据点有效值

    Attributes:
        table_id: 工作表标识
        device_id: 设备编号
        tag_id: 数据点标识
        value: 数据点有效值
        timestamp: 数据点有效值时间戳(时间戳, 精确到毫秒)
    """

    def __init__(self, table_id: str, device_id: str, tag_id, value, timestamp):
        self.table_id = table_id
        self.device_id = device_id
        self.tag_id = tag_id
        self.value = value
        self.timestamp = timestamp

    def set_value(self, value: any):
        self.value = value
        self.timestamp = int(datetime.now().timestamp()) * 1000


class DeviceTagValues:
    """
    设备数据点有效值

    Attributes:
        table_id: 工作表标识
        device_id: 设备编号
        tag_values: 数据点有效值. key 为数据点标识, value 为数据点有效值
    """

    def __init__(self, table_id: str, device_id: str):
        self.table_id = table_id
        self.device_id = device_id
        self.tag_values = {}
        self.lock = asyncio.Lock()

    async def set_value(self, tag_id: str, value: any):
        """
        设置数据点有效值

        :param tag_id: 数据点标识
        :param value: 数据点有效值
        """

        await self.lock.acquire()
        try:
            if tag_id in self.tag_values:
                self.tag_values[tag_id].set_value(value)
            else:
                self.tag_values[tag_id] = TagValue(self.table_id, self.device_id, tag_id, value,
                                                   int(datetime.now().timestamp()) * 1000)
        finally:
            self.lock.release()

    async def get_value(self, tag_id: str) -> Optional[any]:
        """
        获取数据点有效值
        :param tag_id: 数据点标识
        :return:
        """

        await self.lock.acquire()
        try:
            if tag_id not in self.tag_values:
                return None
            return self.tag_values[tag_id].value
        finally:
            self.lock.release()


class TagValueCache:
    """
    数据点有效值缓冲
    """

    def __init__(self):
        self.devices = {}
        self.lock = asyncio.Lock()

    async def set_value(self, table_id: str, device_id: str, tag_id: str, value: any):
        """
        设置数据点有效值
        :param table_id: 工作表标识
        :param device_id: 资产编号
        :param tag_id:  数据点标识
        :param value:  数据点的值
        :return:
        """

        key = "{}|#|{}".format(table_id, device_id)
        await self.lock.acquire()
        try:
            if key not in self.devices:
                self.devices[key] = DeviceTagValues(table_id, device_id)
        finally:
            self.lock.release()

        await self.devices[key].set_value(tag_id, value)

    async def get_value(self, table_id: str, device_id: str, tag_id: str) -> Optional[any]:
        """
        获取数据点有效值
        :param table_id: 工作表标识
        :param device_id: 资产编号
        :param tag_id:  数据点标识
        :return:
        """

        key = "{}|#|{}".format(table_id, device_id)
        await self.lock.acquire()
        try:
            if key not in self.devices:
                return None
            return self.devices[key].get_value(tag_id)
        finally:
            self.lock.release()
