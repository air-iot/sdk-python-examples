import asyncio
import logging
import traceback
from concurrent.futures import ThreadPoolExecutor
from typing import Optional, Callable, Coroutine

import grpc
import jsons
from grpc.aio import Metadata, StreamStreamCall

from airiot_python_sdk.algorithm import AlgorithmApp
from airiot_python_sdk.algorithm.config import AlgorithmConfig
from airiot_python_sdk.algorithm.entity import Request, Response
from airiot_python_sdk.algorithm.protos.algorithm_pb2 import HealthCheckRequest, HealthCheckResponse, RunResult
from airiot_python_sdk.algorithm.protos.algorithm_pb2_grpc import AlgorithmServiceStub

logger = logging.getLogger("launcher")


class Launcher:
    """
    算法加载程序
    """

    config: AlgorithmConfig
    app: AlgorithmApp

    executor: ThreadPoolExecutor

    channel: Optional[grpc.aio.Channel]
    run_stream: Optional[StreamStreamCall]
    schema_stream: Optional[StreamStreamCall]

    functions: dict[str, Callable]

    running: bool

    def __init__(self, app: AlgorithmApp, config: AlgorithmConfig):
        self.config = config
        self.app = app
        self.channel = None
        self.run_stream = None
        self.schema_stream = None
        self.functions = {}
        self.running = False
        self.stop_request_fired = asyncio.Event()

        # max_threads = self.config.max_threads if self.config.max_threads > 0 else os.cpu_count()
        # self.executor = ThreadPoolExecutor(max_workers=max_threads, thread_name_prefix="algorithm-")
        # asyncio.get_event_loop().set_default_executor(self.executor)

        # 通过反射获取所有的方法, 并将带有 algorithm_function 注解的方法加入到 functions 中
        for key in dir(app):
            attr = getattr(app, key)
            if hasattr(attr, "__call__"):
                if key.startswith("__"):
                    continue
                if "algorithm_function" in attr.__annotations__:
                    self.functions[attr.__annotations__["algorithm_function"]] = attr

    async def start(self):
        """
        启动算法加载程序
        :return:
        """

        if self.running:
            logger.warning("algorithm program is already running")
            return

        self.running = True

        logger.info("start algorithm program, id = %s, name = %s", self.config.id, self.config.name)
        
        # 执行算法加载程序的启动方法
        self.app.start()

        # 连接算法服务
        await self.__connect__()

        logger.info("algorithm program started")

        # wait for stop signal
        try:
            await self.stop_request_fired.wait()
        except asyncio.CancelledError:
            pass

    async def stop(self):
        """
        停止流程插件
        :return:
        """

        if not self.running:
            return

        logger.info("stopping algorithm program: id = %s, name = %s", self.app.id(), self.app.name())

        self.running = False

        if self.run_stream is not None:
            self.run_stream.cancel()

        if self.schema_stream is not None:
            self.schema_stream.cancel()

        # close grpc channel
        await self.channel.close(grace=5)

        # call plugin stop callback
        self.app.stop()

        # send stop signal
        self.stop_request_fired.set()

        logger.info("algorithm program stopped")

    async def __connect__(self):
        """
        连接算法服务
        :return:
        """

        # 如果已经停止则不再重连
        if not self.running:
            return

        if self.run_stream is not None:
            self.run_stream.cancel()
        if self.schema_stream is not None:
            self.schema_stream.cancel()

        # 关闭现有的 channel
        if self.channel is not None:
            await self.channel.close(grace=5)

        # connect to driver
        await self.__connect_grpc__()

    async def __connect_grpc__(self):
        """
        连接到流程引擎的gRPC服务
        :return:
        """

        logger.info("start to connect flow_plugin enginerpc: grpc://%s:%d", self.config.algorithm_grpc.host,
                    self.config.algorithm_grpc.port)

        self.channel = grpc.aio.insecure_channel(f"{self.config.algorithm_grpc.host}:{self.config.algorithm_grpc.port}")
        self.servicer = AlgorithmServiceStub(self.channel)

        await self.channel.channel_ready()

        logger.info("connected to algorithm service: grpc://%s:%d", self.config.algorithm_grpc.host,
                    self.config.algorithm_grpc.port)

        self.__create_streams__()

    def __create_streams__(self):
        logger.info("start to create streams")

        loop = asyncio.get_event_loop()
        # loop.set_default_executor(self.executor)

        loop.create_task(self.__schema__()),
        loop.create_task(self.__run__()),
        loop.create_task(self.__health_check__(self.__connect__))

        logger.info("streams created")

    def __metadata__(self) -> Metadata:
        metadata = Metadata()
        metadata.add("algorithmid", self.config.id.encode("utf-8").hex())
        metadata.add("algorithmname", self.config.name.encode("utf-8").hex())
        metadata.add("serviceid", self.config.service_id.encode("utf-8").hex())
        return metadata

    async def __schema__(self):
        """
        创建 schema stream
        :return:
        """

        metadata = self.__metadata__()
        logger.debug("grpc metadata: %s", metadata)

        self.schema_stream = self.servicer.SchemaStream(metadata=metadata)

        logger.info("algorithm program schema stream created, start to receive requests")

        async for request in self.schema_stream:
            if request == grpc.aio.EOF:
                logger.info("run stream closed")
                break

            request_id = request.request

            logger.debug("receive schema request, requestId = %s", request_id)

            response = Response()

            try:
                result = await self.app.schema()
                response.code = 200
                response.result = result
                logger.info("algorithm schema request handle success, requestId = %s", request_id)
            except Exception as e:
                traceback.print_exception(e)
                response.code = 400
                response.error = str(e)
                logger.error("algorithm schema request handle exception, requestId = %s, exception = %s", request_id, e)

            await self.schema_stream.write(RunResult(request=request_id, message=jsons.dumps(response).encode("utf-8")))

    async def __run__(self):
        """
        创建 run stream
        :return:
        """

        metadata = self.__metadata__()
        logger.debug("grpc metadata: %s", metadata)

        self.run_stream = self.servicer.RunStream(metadata=metadata)

        logger.info("algorithm program register successfully, start to receive requests")

        async for request in self.run_stream:
            if request == grpc.aio.EOF:
                logger.info("run stream closed")
                break

            req: Request = jsons.loads(request.data, Request)

            project_id = req.projectID
            function = req.function
            params = req.input

            logger.debug("receive run request, projectId = %s, function = %s, params = %s", project_id, function,
                         params)

            # 如果找带有通过注解标记为该该函数名称的方法, 则使用注解标记的方法, 否则使用 run 方法
            if function in self.functions:
                logger.info("run algorithm function '%s', request_id: %s, params: %s", function, request.request,
                            params)
                asyncio.create_task(self.__task__(request.request, self.functions[function](project_id, params)))
            else:
                logger.info("run algorithm function 'run', request_id: %s, function = %s, params: %s", request.request,
                            function, params)
                asyncio.create_task(self.__task__(request.request, self.app.run(project_id, function, params)))

    async def __task__(self, request_id: str, coro: Coroutine):
        response = Response()
        try:
            result = await coro

            logger.info("run algorithm, request_id: %s, result = %s", request_id, result)

            response.code = 200
            response.result = result
        except Exception as e:
            traceback.print_exception(e)
            logger.error("run algorithm failed, request_id: %s, exception = %s", request_id, e)

            response.code = 400
            response.error = str(e)

        await self.run_stream.write(RunResult(request=request_id, message=jsons.dumps(response).encode("utf-8")))

    async def __health_check__(self, reconnect: Callable):
        """
        健康检查
        :param reconnect: 重连方法
        :return:
        """

        a_id = self.config.id
        name = self.config.name
        service_id = self.config.service_id
        interval = 30 if self.config.algorithm_grpc.health_check_interval <= 0 else self.config.algorithm_grpc.health_check_interval

        logger.info("start health check, id = %s, name = %s, interval = %d", a_id, name, interval)

        while self.running:
            try:
                tasks = asyncio.as_completed([
                    asyncio.sleep(interval),
                    self.stop_request_fired.wait()
                ])

                for task in tasks:
                    await task
                    break

                if not self.running:
                    break

                logger.info("send health check request, id = %s, name = %s", a_id, name)
                response: HealthCheckResponse = await self.servicer.HealthCheck(HealthCheckRequest(service=service_id),
                                                                                timeout=5)

                if response.errors is not None and len(response.errors) > 0:
                    for error in response.errors:
                        logger.error("health check failed, id = %s, name = %s, code = %d, message = %s",
                                     a_id, name, error.code, error.message)
                elif response.status == HealthCheckResponse.SERVING:
                    logger.info("health check success, id = %s, name = %s", a_id, name)
                else:
                    logger.error("health check failed, id = %s, name = %s, status = %d", a_id, name, response.status)
                    break
            except Exception as e:
                traceback.print_exception(e)
                logger.error("health check exception, id = %s, name = %s, exception = %s", a_id, name, e)
                break
        # 心跳检测失败, 重连
        await reconnect()
