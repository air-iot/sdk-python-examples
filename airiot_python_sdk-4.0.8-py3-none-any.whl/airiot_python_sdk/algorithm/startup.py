import argparse
import asyncio
import logging
import os.path
import uuid
from concurrent.futures import ThreadPoolExecutor
from typing import Optional

import jsons
import yaml

from airiot_python_sdk.algorithm import AlgorithmApp
from airiot_python_sdk.algorithm.config import AlgorithmConfig
from airiot_python_sdk.algorithm.launcher import Launcher

parser = argparse.ArgumentParser("启动算法服务")
parser.add_argument('--config', type=str, dest='config', default="config.yml",
                    help='配置文件路径 (default: 当前目录下的 config.yml 文件)')

parser.add_argument('--id', type=str, dest='id', help='算法服务ID')
parser.add_argument('--name', type=str, dest='name', help='算法服务名称')

parser.add_argument('--maxThreads', type=int, dest='maxThreads',
                    help='最大线程数量, 如果为 0 则取当前 CPU 核数. 默认为 1')
parser.add_argument('--serviceId', type=str, dest='serviceId', help='算法服务实例ID')

parser.add_argument('--log-level', type=str, dest='logLevel', default="INFO",
                    help='日志等级, 可选项有 DEBUG, INFO, WARNING, ERROR (default: INFO)')


def run_loop(launcher: Launcher, main_loop: asyncio.AbstractEventLoop):
    asyncio.set_event_loop(main_loop)
    main_loop.create_task(launcher.start())
    main_loop.run_forever()


class Startup:
    """
    服务启动类
    """

    id: Optional[str]
    name: Optional[str]
    service_id: Optional[str]
    max_threads: Optional[int]

    # 日志等级
    log_level: str = "INFO"

    log_format: str = '%(asctime)s %(levelname)5s --- [%(module)20s]: %(message)s'

    def __init__(self, id: str = None, name: str = None, service_id: str = None, max_threads: int = 1,
                 log_level: str = None):
        self.id = id
        self.name = name
        self.service_id = service_id
        self.max_threads = max_threads
        self.log_level = log_level

    def load_config(self, path):
        if not os.path.exists(path):
            return

        with open(path, 'r', encoding="utf-8") as f:
            config = yaml.load(f, yaml.FullLoader)

            if "id" not in config and self.id is not None:
                config["id"] = self.id
            if "name" not in config and self.name is not None:
                config["name"] = self.name
            if "service-id" not in config and self.service_id is not None:
                config["service_id"] = self.service_id
            elif "service-id" in config:
                config["service_id"] = config["service-id"]
                del config["service-id"]
            
            if "algorithm-grpc" in config:
                config["algorithm_grpc"] = config["algorithm-grpc"]
                del config["algorithm-grpc"]

            if "max-threads" in config:
                config["max_threads"] = config["max-threads"]
                del config["max-threads"]

            if "log-level" in config:
                self.log_level = config["log-level"]

            return jsons.load(config, cls=AlgorithmConfig)

    def parse(self) -> AlgorithmConfig:
        command_line = parser.parse_args()

        # 如果设置了配置文件, 则加载配置文件
        if command_line.config is not None:
            config = self.load_config(command_line.config)
        else:
            config = AlgorithmConfig()

        # 其它命令行参数优先级高于配置文件
        if command_line.id is not None:
            config.id = command_line.id
        if command_line.name is not None:
            config.name = command_line.name
        if command_line.serviceId is not None:
            config.service_id = command_line.serviceId
        if command_line.maxThreads is not None:
            config.max_threads = command_line.maxThreads
        if command_line.logLevel is not None:
            self.log_level = command_line.logLevel

        if config.id is None:
            raise ValueError("算法服务ID不能为空")
        if config.name is None:
            raise ValueError("算法服务名称不能为空")

        if config.service_id is None:
            config.service_id = uuid.uuid4().hex

        return config

    def run(self, algorithm_app: AlgorithmApp, config: AlgorithmConfig = None):
        if config is None:
            config = self.parse()

        logging.basicConfig(level=self.log_level, format=self.log_format)
        logger = logging.getLogger("startup")

        logger.info("启动算法服务: %s", config)

        launcher = Launcher(algorithm_app, config)

        # main_loop = asyncio.new_event_loop()
        # main_thread = threading.Thread(target=run_loop, args=(launcher, main_loop,), name="algorithm", daemon=True)
        # main_thread.start()

        main_loop = asyncio.new_event_loop()
        max_threads = config.max_threads if config.max_threads > 0 else os.cpu_count()
        executor = ThreadPoolExecutor(max_workers=max_threads, thread_name_prefix="algorithm-")
        main_loop.set_default_executor(executor)

        try:
            main_loop.run_until_complete(launcher.start())
        except KeyboardInterrupt:
            logger.info("接收到退出信号")

        main_loop.run_until_complete(launcher.stop())
