import logging
from abc import abstractmethod
from enum import Enum

formatter = '%(asctime)s %(levelname)5s --- [%(module)20s]: %(message)s'
logging.basicConfig(level="DEBUG", format=formatter)


class FlowPluginType(Enum):
    """
    插件类型

    UserTask: 用户任务
    ServiceTask: 服务任务
    """

    UserTask = "user"
    ServiceTask = "service"


class FlowTask:
    """
    流程插件任务请求信息

    Attributes:
        projectId: 当前流程所属项目ID
        flowId: 当前流程ID
        job: 流程实例ID
        elementId: 当前节点ID
        elementJob: 节点实例ID
        config: 节点配置信息
    """

    # 当前流程所属项目ID
    projectId: str
    # 当前流程ID
    flowId: str
    # 流程实例ID
    job: str
    # 当前节点ID
    elementId: str
    # 节点实例ID
    elementJob: str
    # 节点配置信息
    config: bytes

    def __init__(self, project_id: str, flow_id: str, job: str, element_id: str, element_job: str, config: bytes):
        self.projectId = project_id
        self.flowId = flow_id
        self.job = job
        self.elementId = element_id
        self.elementJob = element_job
        self.config = config

    def __str__(self):
        return "FlowRequest(projectId={}, flowId={}, job={}, elementId={}, elementJob={}, config={})".format(
            self.projectId, self.flowId, self.job, self.elementId, self.elementJob, self.config
        )


class FlowResult:
    """
    流程插件执行结果

    Attributes:
        message: 说明信息
        details: 详细信息
        data: 执行结果数据
    """
    # 说明信息
    message: str
    # 详细信息
    details: str
    # 执行结果数据
    data: dict

    def __init__(self, message: str, details: str, data: dict):
        self.message = message
        self.details = details
        self.data = data

    def __str__(self):
        return "FlowResponse(message={}, details={}, data={})".format(self.message, self.details, self.data)


class DebugTask:
    """
    流程插件调试请求信息

    Attributes:
        projectId: 当前流程所属项目ID
        flowId: 当前流程ID
        elementId: 当前节点ID
        config: 节点配置信息
    """
    # 当前流程所属项目ID
    projectId: str
    # 当前流程ID
    flowId: str
    # 当前节点ID
    elementId: str
    # 节点配置信息
    config: bytes

    def __init__(self, project_id: str, flow_id: str, element_id: str, config: bytes):
        self.projectId = project_id
        self.flowId = flow_id
        self.elementId = element_id
        self.config = config


class DebugLog:
    """
    流程插件调试日志信息

    Attributes:
        level: 日志级别
        time: 时间
        msg: 日志内容
    """
    # 日志级别
    level: str
    # 时间
    time: str
    # 日志内容
    msg: str

    def __init__(self, level: str, time: str, message: str):
        self.level = level
        self.time = time
        self.msg = message

    def __str__(self):
        return "DebugLog(level={}, time={}, message={})".format(self.level, self.time, self.msg)


class DebugResult:
    """
    流程插件调试结果

    Attributes:
        success: 调试是否执行成功
        reason: 调试失败原因
        detail: 调试失败详细信息
        logs: 调试日志
        result: 输出结果. 必须为可序列化的对象, 例如: 自定义 class 或 dict
    """
    # 调试是否执行成功
    success: bool
    # 调试失败原因
    reason: str
    # 调试失败详细信息
    detail: str
    # 调试日志
    logs: list[DebugLog]
    # 输出结果. 必须为可序列化的对象, 例如: 自定义 class 或 dict
    value: any

    def __init__(self, success: bool, reason: str, detail: str, logs: list[DebugLog], value: any):
        self.success = success
        self.reason = reason
        self.detail = detail
        self.logs = logs
        self.value = value
    
    def __str__(self):
        return "DebugResult(success={}, reason={}, detail={}, logs={}, value={})".format(
            self.success, self.reason, self.detail, self.logs, self.value
        )


class FlowPlugin:
    """
    流程插件接口
    """

    @abstractmethod
    def get_name(self) -> str:
        """
        插件名称
        :return:
        """
        pass

    @abstractmethod
    def get_type(self) -> FlowPluginType:
        """
        插件类型
        :return:
        """
        pass

    @abstractmethod
    def on_connection_state_changed(self, state: bool):
        """
        当与流程引擎的连接状态发生变化时调用
        :param state: 变化后的连接状态
        :return:
        """
        pass

    @abstractmethod
    def start(self):
        """
        当插件启动时调用.
        该方法只会调用一次, 并且在 'on_connection_state_changed' 方法之前执行
        :return:
        """
        pass

    @abstractmethod
    def stop(self):
        """
        当流程插件服务停止时执行的操作. 该方法只会调用一次
        :return:
        """
        pass

    @abstractmethod
    async def execute(self, request: FlowTask) -> FlowResult:
        """
        执行流程插件
        :param request: 请求信息
        :return: 执行结果
        :raise Exception: 执行失败时抛出异常
        """
        pass

    @abstractmethod
    async def debug(self, task: DebugTask) -> DebugResult:
        """
        调试流程插件
        Args:
            task: 调试信息

        Returns:
            调试日志和结果
        """
        pass
