import argparse
import asyncio
import logging
import os.path
import signal
import threading

import jsons
import yaml

from airiot_python_sdk.driver.launcher import DriverLauncher
from airiot_python_sdk.flow_extension import FlowExtension
from airiot_python_sdk.flow_extension.config import FlowExtensionConfig
from airiot_python_sdk.flow_extension.launcher import FlowExtensionLauncher

parser = argparse.ArgumentParser("启动流程扩展节点")
parser.add_argument('--config', type=str, dest='config', default="config.yml",
                    help='配置文件路径 (default: 当前目录下的 config.yml 文件)')

parser.add_argument('--log-level', type=str, dest='logLevel', default="INFO",
                    help='日志等级, 可选项有 DEBUG, INFO, WARNING, ERROR (default: INFO)')


def run_loop(launcher: DriverLauncher, main_loop: asyncio.AbstractEventLoop):
    asyncio.set_event_loop(main_loop)
    main_loop.create_task(launcher.start())
    main_loop.run_forever()


class Startup:
    """
    服务启动类
    """

    # 日志等级
    log_level: str = "INFO"

    log_format: str = '%(asctime)s %(levelname)5s --- [%(module)20s]: %(message)s'

    def __init__(self, log_level: str = None):
        self.log_level = log_level

    def load_config(self, path):
        if not os.path.exists(path):
            return

        with open(path, 'r', encoding="utf-8") as f:
            config = yaml.load(f, yaml.FullLoader)

            if "flow-engine" in config:
                flow_engine_config = config["flow-engine"]
                config["host"] = flow_engine_config.get("host", "flow-engine")
                config["port"] = flow_engine_config.get("port", 2333)
                config["health_check_interval"] = flow_engine_config.get("health-check-interval", 30)
                del config["flow-engine"]

            if "log-level" in config:
                self.log_level = config["log-level"]

            return jsons.load(config, cls=FlowExtensionConfig)

    def parse(self) -> FlowExtensionConfig:
        command_line = parser.parse_args()

        # 如果设置了配置文件, 则加载配置文件
        if command_line.config is not None:
            config = self.load_config(command_line.config)
        else:
            config = FlowExtensionConfig()

        # 其它命令行参数优先级高于配置文件
        if command_line.logLevel is not None:
            self.log_level = command_line.logLevel

        return config

    def run(self, flow_extension: FlowExtension, flow_extension_config: FlowExtensionConfig = None):
        if flow_extension_config is None:
            flow_extension_config = self.parse()

        logging.basicConfig(level=self.log_level, format=self.log_format)
        logger = logging.getLogger("startup")

        logger.info("启动流程扩展节点, id = %s, name = %s", flow_extension.id(), flow_extension.name())

        launcher = FlowExtensionLauncher(flow_extension_config, flow_extension)
        
        main_loop = asyncio.new_event_loop()
        main_thread = threading.Thread(target=run_loop, args=(launcher, main_loop,), name="flow-extension", daemon=True)
        main_thread.start()

        loop = asyncio.get_event_loop()
        stop_event = asyncio.Event()

        def raise_graceful_exit(sig, frame):
            logger.info("接收到退出信号")
            stop_event.set()

        signal.signal(signal.SIGINT, raise_graceful_exit)
        signal.signal(signal.SIGTERM, raise_graceful_exit)

        try:
            loop.run_until_complete(stop_event.wait())
        except KeyboardInterrupt:
            print("退出了")

        loop.run_until_complete(launcher.stop())
