from typing import Optional, List

from airiot_python_sdk.client.api import Response, StatusResult, set_project_header, fail, ok_only_data
from airiot_python_sdk.client.api.media_library import MediaLibraryClient, MediaFileUploadResult, MediaFileEntry
from airiot_python_sdk.client.sync import BaseClient


class SyncMediaLibraryClient(MediaLibraryClient):

    base_client: BaseClient

    def __init__(self, base_client: BaseClient):
        self.base_client = base_client

    def query(self, project_id: str, catalog: Optional[str] = None, base64: bool = False,
              headers: Optional[dict[str, str]] = None) -> Response[List[MediaFileEntry]]:
        headers = set_project_header(project_id, headers)

        args = []
        if catalog is not None:
            args.append(f"catalog={catalog}")
        if base64:
            args.append("addBase64=true")

        url = "/core/mediaLibrary"
        if len(args) != 0:
            url += "?" + "&".join(args)
        return self.base_client.perform_get(url, headers=headers, cls=list[MediaFileEntry])

    def upload(self, project_id: str, file: str, catalog: Optional[str] = None, action: Optional[str] = None,
               headers: Optional[dict[str, str]] = None) -> Response[MediaFileUploadResult]:
        headers = set_project_header(project_id, headers)

        args = []
        if catalog is not None:
            args.append(f"catalog={catalog}")
        if action is not None:
            args.append(f"action={action}")

        url = "/core/mediaLibrary/upload"
        if len(args) != 0:
            url += "?" + "&".join(args)

        with open(file, "rb") as f:
            return self.base_client.perform_post(url, headers=headers, files={"file": f}, cls=MediaFileUploadResult)

    def upload_from_url(self, project_id: str, filename: str, url: str, catalog: Optional[str] = None, action: Optional[str] = None,
                        base64: bool = False,
                        headers: Optional[dict[str, str]] = None) -> Response[MediaFileUploadResult]:
        headers = set_project_header(project_id, headers)

        data = {
            "fileUrl": url,
            "saveFileName": filename,
        }
        if catalog is not None:
            data["mediaLibraryPath"] = catalog
        if action is not None:
            data["action"] = action
        if base64:
            data["addBase64"] = "true"

        return self.base_client.perform_post("/core/mediaLibrary/saveFileFromUrl", headers=headers, data=data, cls=MediaFileUploadResult)

    def upload_from_base64(self, project_id: str, filename: str, file_data: str, catalog: Optional[str] = None,
                           action: Optional[str] = None, headers: Optional[dict[str, str]] = None) -> Response[
        MediaFileUploadResult]:
        headers = set_project_header(project_id, headers)

        data = {
            "base64Str": file_data,
            "saveFileName": filename,
        }
        if catalog is not None:
            data["mediaLibraryPath"] = catalog
        if action is not None:
            data["action"] = action

        return self.base_client.perform_post("/core/mediaLibrary/saveImageFromBase64", headers=headers, data=data,
                                             cls=MediaFileUploadResult)

    def download(self, project_id: str, path: str, headers: Optional[dict[str, str]] = None) -> Response[bytes]:
        headers = set_project_header(project_id, headers)

        if path.startswith("/"):
            path = path[1:]

        response = self.base_client.perform_get_stream(f"/core/fileServer/mediaLibrary/{project_id}/{path}", headers=headers)
        if response.status_code == 404:
            return fail(404, "文件不存在", detail=f"文件 '{path}' 不存在")
        elif response.status_code == 200:
            return ok_only_data(response.content)
        else:
            return fail(response.status_code, response.text)

    def mkdir(self, project_id: str, catalog: str, dir_name: str, headers: Optional[dict[str, str]] = None) -> Response[StatusResult]:
        headers = set_project_header(project_id, headers)
        data = {
            "dirName": dir_name,
            "catalog": catalog,
        }
        return self.base_client.perform_post("/core/mediaLibrary/mkdir", headers=headers, data=data, cls=StatusResult)

    def delete(self, project_id: str, path: str, headers: Optional[dict[str, str]] = None) -> Response[StatusResult]:
        headers = set_project_header(project_id, headers)
        return self.base_client.perform_delete(f"/core/mediaLibrary?path={path}&completeDelete=true", headers=headers, cls=StatusResult)