
from ..api import Response
from ..api.spm import SPMUserClient, SPMProjectClient, Project
from ..api.token import Token
from ..sync import BaseClient


class SyncSPMUserClient(SPMUserClient):
    base_client: BaseClient

    def __init__(self, base_client: BaseClient):
        self.base_client = base_client

    def login(self, username: str, password: str) -> Response[Token]:
        return self.base_client.perform_post("/spm/login", data={"username": username, "password": password}, cls=Token)

    def gettoken(self, app_key: str, app_secret: str) -> Response[Token]:
        return self.base_client.perform_post("/spm/token", data={"ak": app_key, "sk": app_secret}, cls=Token)


class SyncSPMProjectClient(SPMProjectClient):
    base_client: BaseClient

    def __init__(self, base_client: BaseClient):
        self.base_client = base_client

    def query_by_id(self, project_id: str) -> Response[Project]:
        return self.base_client.perform_get("/spm/project/{}".format(project_id), cls=Project)
