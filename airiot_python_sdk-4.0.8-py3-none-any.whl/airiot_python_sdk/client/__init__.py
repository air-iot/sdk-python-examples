from abc import abstractmethod

from .api.latest import LatestClient
from .api.media_library import MediaLibraryClient
from .api.spm import SPMUserClient, SPMProjectClient
from .api.system_variable import SystemVariableClient
from .api.timing_data import TimingDataClient
from .api.worktable_data import WorkTableDataClient


class Clients:
    """
    平台客户端列表, 用于获取各个客户端
    """

    @abstractmethod
    def get_spm_user_client(self) -> SPMUserClient:
        """
        获取 SPM 空间管理用户信息管理客户端
        :return: SPM 空间管理用户信息客户端
        """
        pass

    @abstractmethod
    def get_spm_project_client(self) -> SPMProjectClient:
        """
        获取 SPM 空间管理项目信息管理客户端
        :return: SPM 空间管理项目信息管理客户端
        """
        pass

    @abstractmethod
    def get_system_variable_client(self) -> SystemVariableClient:
        """
        获取系统变量(数据字典)客户端
        :return:
        """
        pass

    @abstractmethod
    def get_latest_client(self) -> LatestClient:
        """
        获取数据点最新数据客户端
        :return:
        """
        pass

    @abstractmethod
    def get_timing_data_client(self) -> TimingDataClient:
        """
        获取时序数据查询客户端
        :return:
        """
        pass

    @abstractmethod
    def get_worktable_client(self) -> WorkTableDataClient:
        """
        获取工作表操作客户端
        :return:
        """
        pass

    @abstractmethod
    def get_media_library_client(self) -> MediaLibraryClient:
        """
        获取媒体库操作客户端
        :return:
        """
        pass