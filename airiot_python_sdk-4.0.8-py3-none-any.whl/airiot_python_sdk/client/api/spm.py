import dataclasses
from abc import abstractmethod
from datetime import datetime
from typing import Optional

from . import Response
from .token import Token


@dataclasses.dataclass
class ProjectUser:
    """
    项目信息中的用户信息

    Attributes:
        id: 用户唯一标识
        name: 用户名称
    """

    '''
    用户唯一标识
    '''
    id: str


@dataclasses.dataclass
class Project:
    """
    空间管理-项目信息

    Attributes:
        id: 项目唯一标识
        name: 项目名称
        user: 用户基础信息
        industry: 行业
        remarks: 备注
        createTime: 项目创建时间
        bgColor: 用于设定项目管理卡片展示时，卡片的背景色
        projectType: 项目类型
        status: 项目启用状态
    """

    '''
    项目唯一标识
    创建项目时无须填写
    '''
    id: str

    '''
    项目名称, 必填
    '''
    name: str

    '''
    用户基础信息
    创建项目时无须填写
    '''
    user: ProjectUser

    '''
    行业
    '''
    industry: Optional[str]

    '''
    备注
    '''
    remarks: Optional[str]

    '''
    项目创建时间
    创建项目时无须填写
    '''
    createTime: datetime

    '''
    用于设定项目管理卡片展示时，卡片的背景色
    '''
    bgColor: Optional[str]

    '''
    项目类型
    '''
    projectType: Optional[str]

    '''
    项目启用状态
    true: 启用, false: 禁用
    '''
    status: bool


class SPMUserClient:
    """
    SPM 空间管理-用户信息管理客户端
    """

    @abstractmethod
    def login(self, username: str, password: str) -> Response[Token]:
        """
        登录
        :param username: 用户名
        :param password: 密码
        :return: Token
        """
        pass

    @abstractmethod
    def gettoken(self, app_key: str, app_secret: str) -> Response[Token]:
        """
        使用 appKey 和 appSecret 获取平台 Token
        :param app_key: appKey
        :param app_secret: appSecret
        :return: Token
        """
        pass


class SPMProjectClient:
    """
    SPM 空间管理-项目管理客户端
    """

    @abstractmethod
    def query_by_id(self, project_id: str) -> Response[Project]:
        """
        根据项目 ID 查询项目信息
        :param project_id: 项目ID
        :return: 项目信息
        """
        pass
