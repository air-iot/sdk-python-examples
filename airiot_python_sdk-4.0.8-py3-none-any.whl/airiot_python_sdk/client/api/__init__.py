import dataclasses
from typing import Optional, TypeVar, Generic

T = TypeVar('T')

# 项目ID请求头 key
PROJECT_HEADER_KEY = "x-request-project"


def set_project_header(project_id: str, headers: Optional[dict[str, str]] = None) -> dict[str, str]:
    """
    设置项目ID请求头. 如果请求头为空, 则创建一个新的请求头, 否则在原有请求头上添加项目ID请求头
    :param headers: 请求头
    :param project_id: 项目ID
    :return: 添加了项目ID请求头后的请求头
    """

    if headers is None:
        return {PROJECT_HEADER_KEY: project_id}
    headers[PROJECT_HEADER_KEY] = project_id
    return headers


@dataclasses.dataclass
class StatusResult:
    """
    操作结果

    Attributes:
        status: 操作结果. 通常 'ok' 代表成功
    """

    status: str

    def __init__(self, status: str = "ok"):
        self.status = status


@dataclasses.dataclass
class InsertResult:
    """
    新增数据响应结果数据, 该数据中包含了新增数据的唯一标识
    """

    # 新增数据的唯一标识
    InsertedID: str


@dataclasses.dataclass
class BatchInsertResult:
    """
    批量新增数据响应结果数据, 该数据中包含了新增数据的唯一标识
    """

    # 新增数据的唯一标识列表. 该列表中的数据顺序与请求中的数据顺序一致
    InsertedIDs: list[str]


class Response(Generic[T]):
    """
    请求响应

    Attributes:
        success: 请求是否成功标识
        code: 请求响应状态码. 请求成功时为200, 请求失败时为相应的业务错误码
        message: 响应信息. 当请求失败时保存错误信息
        detail: 详细信息. 当请求失败时保存详细错误信息
        field: 字段名称. 当请求由于字段错误时保存字段名称. 例如: 参数字段校验失败
        data: 请求响应数据
    """

    # 请求是否成功标识
    success: bool = True
    # 请求响应状态码. 请求成功时为200, 请求失败时为相应的业务错误码
    code: int = 200
    # 响应信息. 当请求失败时保存错误信息
    message: str = "OK"
    # 详细信息. 当请求失败时保存详细错误信息
    detail: str = ""
    # 字段名称. 当请求由于字段错误时保存字段名称. 例如: 参数字段校验失败
    field: str = ""
    # 请求响应数据
    data: Optional[T] = None

    def __init__(self, success: bool = True, code: int = 200, message: str = "OK", detail: str = "", field: str = "", data: Optional[T] = None):
        self.success = success
        self.code = code
        self.message = message
        self.detail = detail
        self.field = field
        self.data = data

    @property
    def full_message(self) -> str:
        if self.detail is not None and len(self.detail) != 0:
            return f"{self.message}, {self.detail}"
        return self.message

    def __str__(self):
        return "Response{" + \
            "success=" + str(self.success) + \
            ", code=" + str(self.code) + \
            ", message='" + str(self.message) + '\'' + \
            ", detail='" + str(self.detail) + '\'' + \
            ", field='" + str(self.field) + '\'' + \
            ", data=" + str(self.data) + \
            '}'


def ok(message: str, detail: str) -> Response:
    """
    请求成功响应, 该请求响应中不包含数据
    :param message: 响应信息
    :param detail: 详细信息
    :return: 响应信息
    """
    resp = Response()
    resp.message = message
    resp.detail = detail
    return resp


def ok_only_data(data: any) -> Response:
    """
    请求成功响应, 该请求响应中只包含数据
    :param data: 响应数据
    :return: 响应信息
    """
    resp = Response()
    resp.data = data
    return resp


def ok_with_data(message: str, detail: str, data: any) -> Response:
    """
    请求成功响应, 该请求响应中包含响应信息和数据
    :param message: 响应信息
    :param detail: 详细信息
    :param data: 响应数据
    :return: 响应信息
    """
    resp = Response()
    resp.message = message
    resp.detail = detail
    resp.data = data
    return resp


def fail(code: int, message: str, detail: str = "", field: str = "") -> Response:
    """
    请求失败响应
    :param code: 响应码
    :param message: 响应信息
    :param detail: 详细信息
    :param field: 字段名称
    :return: 响应信息
    """
    resp = Response()
    resp.success = False
    resp.code = code
    resp.message = message
    resp.detail = detail
    resp.field = field
    return resp
