import dataclasses
from abc import abstractmethod
from enum import Enum
from typing import Optional

from airiot_python_sdk.client.api import Response, InsertResult, ok
from airiot_python_sdk.client.api.query import Query


@dataclasses.dataclass
class SystemVariableType(str, Enum):
    Number = "number",
    String = "string"
    Boolean = "boolean"
    Date = "date"
    Object = "object"
    Array = "array"

    @staticmethod
    def from_str(dt: str) -> Optional['SystemVariableType']:
        if dt.lower() == "number":
            return SystemVariableType.Number
        elif dt.lower() == "string":
            return SystemVariableType.String
        elif dt.lower() == "boolean":
            return SystemVariableType.Boolean
        elif dt.lower() == "date":
            return SystemVariableType.Date
        elif dt.lower() == "object":
            return SystemVariableType.Object
        elif dt.lower() == "array":
            return SystemVariableType.Array
        else:
            return None


@dataclasses.dataclass
class SystemVariable:
    """
    系统变量(数据字典)

    Attributes:
        id: 变量唯一标识
        uid: 自定义变量标识
        name: 变量名称
        type: 变量类型
        value: 变量值
    """

    def __init__(self, id: str = None, uid: str = None, name: str = None, type: SystemVariableType = None,
                 value=None):
        self.id = id
        self.uid = uid
        self.name = name
        self.type = type
        self.value = value

    id: str
    uid: str
    name: str
    type: SystemVariableType
    value: any

    @staticmethod
    def __fields__() -> list[str]:
        return ["id", "uid", "name", "type", "value"]


class SystemVariableClient:
    """
    系统变量(数据字典)客户端接口
    """

    @abstractmethod
    def get(self, project_id: str, query: Query, headers: Optional[dict[str, str]] = None) -> Response[
        list[SystemVariable]]:
        """
        自定义查询系统变量(数据字典)列表
        :param headers: 请求头
        :param project_id: 项目ID
        :param query: 查询参数
        :return:
        """
        pass

    @abstractmethod
    def get_by_id(self, project_id: str, id: str, headers: Optional[dict[str, str]] = None) -> Response[SystemVariable]:
        """
        根据变量唯一标识获取系统变量信息
        :param headers: 请求头
        :param project_id: 项目ID
        :param id: 唯一标识
        :return:
        """
        pass

    def get_by_uid(self, project_id: str, uid: str, headers: Optional[dict[str, str]] = None) -> Response[
        list[SystemVariable]]:
        """
        根据自定义变量标识获取系统变量信息
        :param headers: 请求头
        :param project_id: 项目ID
        :param uid: 自定义系统变量标识
        :return:
        """
        query = (Query.new_builder().select(*SystemVariable.__fields__())
                 .filter()
                 .eq("uid", uid)
                 .end()
                 .build())
        return self.get(project_id, query, headers)

    def get_by_uids(self, project_id: str, uids: list[str], headers: Optional[dict[str, str]] = None) -> Response[
        list[SystemVariable]]:
        """
        根据自定义变量标识批量获取系统变量信息
        :param project_id: 项目ID
        :param uids: 自定义系统变量标识列表
        :param headers: 请求头
        :return:
        """
        query = (Query.new_builder().select(*SystemVariable.__fields__())
                 .filter()
                 .in_("uid", uids)
                 .end()
                 .build())
        return self.get(project_id, query, headers)

    def get_by_name(self, project_id: str, name: str, headers: Optional[dict[str, str]] = None) -> Response[
        list[SystemVariable]]:
        """
        根据变量名称获取系统变量信息
        :param headers: 请求头
        :param project_id: 项目ID
        :param name: 系统变量名称
        :return:
        """
        query = (Query.new_builder().select(*SystemVariable.__fields__())
                 .filter()
                 .eq("name", name)
                 .end()
                 .build())
        return self.get(project_id, query, headers)

    def get_by_names(self, project_id: str, names: list[str], headers: Optional[dict[str, str]] = None) -> Response[
        list[SystemVariable]]:
        """
        根据变量名称批量获取系统变量信息
        :param headers: 请求头
        :param project_id: 项目ID
        :param names: 系统变量名称列表
        :return:
        """
        query = (Query.new_builder().select(*SystemVariable.__fields__())
                 .filter()
                 .in_("name", names)
                 .end()
                 .build())
        return self.get(project_id, query, headers)

    @abstractmethod
    def create(self, project_id: str, variable: SystemVariable, headers: Optional[dict[str, str]] = None) -> Response[
        InsertResult]:
        """
        创建系统变量
        :param headers: 请求头
        :param project_id: 项目ID
        :param variable: 系统变量信息
        :return:
        """
        pass

    @abstractmethod
    def update(self, project_id: str, variable: SystemVariable, headers: Optional[dict[str, str]] = None) -> Response:
        """
        更新系统变量
        :param headers: 请求头
        :param project_id: 项目ID
        :param variable: 系统变量信息
        :return:
        """
        pass

    @abstractmethod
    def update_value(self, project_id: str, id: str, value: any, headers: Optional[dict[str, str]] = None) -> Response:
        """
        更新系统变量值
        :param headers: 请求头
        :param project_id: 项目ID
        :param id: 系统变量唯一标识
        :param value: 系统变量值
        :return:
        """
        pass

    @abstractmethod
    def delete(self, project_id: str, id: str, headers: Optional[dict[str, str]] = None) -> Response:
        """
        删除系统变量
        :param headers: 请求头
        :param project_id: 项目ID
        :param id: 系统变量唯一标识
        :return:
        """
        pass

    def delete_by_uid(self, project_id: str, uid: str, headers: Optional[dict[str, str]] = None) -> Response:
        """
        根据系统变量 UID 删除系统变量
        :param project_id: 项目ID
        :param uid: 系统变量 UID
        :param headers: 自定义请求头
        :return: 删除结果
        """
        response = self.get_by_uid(project_id, uid, headers)
        if not response.success:
            return response

        if not response.data or len(response.data) == 0:
            return ok("删除成功", f"未找到对应的系统变量 '{uid}'")

        return self.delete(project_id, response.data[0].id, headers)
