from abc import abstractmethod
from typing import Optional

from airiot_python_sdk.client.api import Response, InsertResult, BatchInsertResult
from airiot_python_sdk.client.api.query import Query


class WorkTableDataClient:
    """
    工作表数据操作客户端
    """

    @abstractmethod
    def query(self, project_id: str, table_id: str, query: Query, headers: Optional[dict[str, str]] = None) -> Response[
        list[dict]]:
        """
        查询工作数据
        :param project_id: 项目ID
        :param table_id: 工作表标识
        :param query: 查询信息
        :param headers: 自定义请求头
        :return:
        """
        pass

    @abstractmethod
    def query_by_id(self, project_id: str, table_id: str, row_id: str, headers: Optional[dict[str, str]] = None) -> \
            Response[dict]:
        """
        根据记录ID查询工作表记录
        :param project_id: 项目ID
        :param table_id: 工作表标识
        :param row_id: 记录ID
        :param headers: 自定义请求头
        :return: 如果记录存在, 返回记录信息
        """

    @abstractmethod
    def create(self, project_id: str, table_id: str, data, headers: Optional[dict[str, str]] = None) -> Response[
        InsertResult]:
        """
        向工作表中写入一条记录
        :param project_id: 项目ID
        :param table_id: 工作表标识
        :param data: 记录数据. 可以为自定义对象, dict 或 str
        :param headers: 自定义请求头
        :return: 写入成功, 返回新增记录的ID
        """
        pass

    @abstractmethod
    def create_batch(self, project_id: str, table_id: str, data, headers: Optional[dict[str, str]] = None) -> \
            Response[BatchInsertResult]:
        """
        批量向工作表中写入数据
        :param project_id: 项目ID
        :param table_id: 工作表标识
        :param data: 记录数据列表, 必须为 list 或 str
        :param headers: 自定义请求头
        :return: 写入成功, 返回新增记录的ID
        """
        pass

    @abstractmethod
    def update(self, project_id: str, table_id: str, row_id: str, data,
               headers: Optional[dict[str, str]] = None) -> Response:
        """
        更新工作表中记录
        :param project_id: 项目ID
        :param table_id: 工作表标识
        :param row_id: 记录ID
        :param data: 更新数据, 可以为自定义对象, dict 或 str
        :param headers: 自定义请求头
        :return:
        """
        pass

    @abstractmethod
    def update_many(self, project_id: str, table_id: str, filter_query: Query, data,
                    headers: Optional[dict[str, str]] = None) -> Response:
        """
        批量更新表中记录. 会更新所有匹配的记录, 如果过滤条件为空, 则会更新表中所有的数据
        :param project_id: 项目ID
        :param table_id: 工作表标识
        :param filter_query: 更新记录过滤器, 只会使用 Query 对象中的 filter 信息
        :param data: 更新的数据, 可以为自定义对象, dict 或 str
        :param headers: 自定义请求头
        :return:
        """
        pass

    @abstractmethod
    def delete_by_id(self, project_id: str, table_id: str, row_id: str,
                     headers: Optional[dict[str, str]] = None) -> Response:
        """
        根据记录ID删除表中记录
        :param project_id:  项目ID
        :param table_id: 工作表标识
        :param row_id: 记录ID
        :param headers: 自定义请求头
        :return:
        """

    @abstractmethod
    def delete(self, project_id: str, table_id: str, filter_query: Query,
               headers: Optional[dict[str, str]] = None) -> Response:
        """
        批量删除工作表中记录. 会删除所有匹配的记录, 如果过滤条件为空, 则会删除表中所有的数据
        :param project_id: 项目ID
        :param table_id: 工作表标识
        :param filter_query: 删除记录过滤器, 只会使用 Query 对象中的 filter 信息
        :param headers: 自定义请求头
        :return:
        """
        pass
