import dataclasses
from abc import abstractmethod
from datetime import datetime
from typing import Optional, List

from . import Response, StatusResult, ok, ok_with_data, fail
from .token import Token
from ...driver.model import ok_only_data


@dataclasses.dataclass
class MediaFileEntry:
    """
    媒体文件查询结果

    Attributes:
        name: 文件名
        isDir: 是否为目录
        path: 相对路径
        filePath: 访问路径
        size: 文件大小(字节)
        modTime: 修改时间
        category: 文件类型
        fileSource: 文件来源. 如果是平台内置资源则会返回该文件的来源. 例如: systemDefault
    """
    name: str
    isDir: bool
    path: str
    filePath: str
    size: int
    modTime: datetime
    category: str
    fileSource: str
    base64: Optional[str] = None

@dataclasses.dataclass
class MediaFileUploadResult:
    """
    文件上传结果

    Attributes:
        url: 文件的访问地址. 例如: /core/fileServer/mediaLibrary/{项目ID}/3.jpeg
        base64Str: 图片的 base64 信息
    """

    url: Optional[str] = str
    base64Str: Optional[str] = None


class MediaLibraryClient:
    """
    媒体库客户端
    """

    @abstractmethod
    def query(self, project_id: str, catalog: Optional[str] = None, base64: bool = False, headers: Optional[dict[str, str]] = None) -> Response[List[MediaFileEntry]]:
        """
        查询媒体文件. 查询指定目录下所有的文件和目录

        :param project_id: 项目ID
        :param headers: 自定义请求头
        :param catalog: 目录. 如果未指定则返回根目录下的文件和目录
        :param base64: 如果文件为图片时, 是否返回该图片的 base64 数据
        """
        pass

    @abstractmethod
    def upload(self, project_id: str, file: str, catalog: Optional[str] = None, action: Optional[str] = None, headers: Optional[dict[str, str]] = None) -> Response[MediaFileUploadResult]:
        """
        上传文件到媒体库

        :param project_id: 项目ID
        :param headers: 自定义请求头
        :param catalog: 文件上传到媒体库中的目录. 例如: a/b
        :param file: 文件路径或文件数据
        :param action: 当文件存在时的处理方式. cover: 覆盖, rename: 文件名自动加1. 如果不传该参数, 则返回文件已存在的错误
        :return: 文件上传结果
        """
        pass

    @abstractmethod
    def upload_from_url(self, project_id: str, filename: str, url: str, catalog: Optional[str] = None, action: Optional[str] = None, base64: bool = False,
               headers: Optional[dict[str, str]] = None) -> Response[MediaFileUploadResult]:
        """
        通过 url 将远端的文件上传文件到媒体库

        :param project_id: 项目ID
        :param headers: 自定义请求头
        :param catalog: 文件上传到媒体库中的目录. 例如: a/b
        :param filename: 上传到媒体库后的文件名称
        :param url: 文件的下载地址
        :param action: 当文件存在时的处理方式. cover: 覆盖, rename: 文件名自动加1. 如果不传该参数, 则返回文件已存在的错误
        :param base64: 上传成功后是否返回该图片的 base64 数据
        :return: 文件上传结果
        """
        pass

    @abstractmethod
    def upload_from_base64(self, project_id: str, filename: str, file_data: str, catalog: Optional[str] = None, action: Optional[str] = None,
                        headers: Optional[dict[str, str]] = None) -> Response[MediaFileUploadResult]:
        """
        通过 url 将远端的文件上传文件到媒体库

        :param project_id: 项目ID
        :param headers: 自定义请求头
        :param catalog: 文件上传到媒体库中的目录. 例如: a/b
        :param filename: 上传到媒体库后的文件名称
        :param file_data: 文件的 base64 数据
        :param action: 当文件存在时的处理方式. cover: 覆盖, rename: 文件名自动加1. 如果不传该参数, 则返回文件已存在的错误
        :return: 文件上传结果
        """
        pass

    @abstractmethod
    def download(self, project_id: str, path: str, headers: Optional[dict[str, str]] = None) -> Response[bytes]:
        """
        下载媒体库文件

        :param project_id: 项目ID
        :param headers: 自定义请求头
        :param path: 媒体文件路径
        :return: 如果文件存在则返回文件的字节流
        """
        pass

    def download_to_file(self, project_id: str, path: str, save_file: str, headers: Optional[dict[str, str]] = None) -> Response[StatusResult]:
        """
        下载媒体库文件并保存到本地

        :param project_id: 项目ID
        :param path: 媒体文件路径
        :param save_file: 保存在本地的路径
        :param headers: 自定义请求头
        """

        response = self.download(project_id, path, headers=headers)
        if not response.success:
            return fail(response.code, response.message, response.detail, field=response.field)

        with open(save_file, 'wb') as f:
            f.write(response.data)
            return ok_with_data("下载成功", detail="" , data=StatusResult())

    @abstractmethod
    def mkdir(self, project_id: str, catalog: str, dir_name: str, headers: Optional[dict[str, str]] = None) -> Response[StatusResult]:
        """
        创建目录.

        :param project_id: 项目ID
        :param headers: 自定义请求头
        :param catalog: 上级目录路径. 例如: a/b
        :param dir_name: 新建目录的名称
        """
        pass

    @abstractmethod
    def delete(self, project_id: str, path: str, headers: Optional[dict[str, str]] = None) -> Response[StatusResult]:
        """
        删除文件或目录

        :param project_id: 项目ID
        :param headers: 自定义请求头
        :param path: 要删除的文件或目录的路径. 例如:
        """
        pass