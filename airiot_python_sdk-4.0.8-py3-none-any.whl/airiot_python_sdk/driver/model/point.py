from enum import Enum
from typing import Optional, List

from ..model.tag import Tag


class FieldType(Enum):
    """
    数据点的类型信息
    """

    # 整数
    Int = "integer"
    # 浮点数
    Float = "float"
    # 字符串
    String = "string"
    # 布尔值
    Boolean = "boolean"

    def __str__(self):
        return self.value


class Field:
    """
    上报平台的数据点信息

    Attributes:
        tag: 数据点信息
        value: 数据点值
    """

    # 数据点信息
    tag: Tag
    # 数据点值
    value: any

    def __init__(self, tag: Tag, value: any):
        self.tag = tag
        self.value = value

    def __str__(self):
        return "Field(tag={}, value={})".format(self.tag, self.value)


class Point:
    """
    上报设备采集数据到平台的信息.

    Attributes:
        id: 设备编号
        cid: 子设备编号
        table: 设备所属工作表标识
        time: 时间(时间戳, 精确到毫秒). 如果为 0 则使用平台接收到数据的时间作为采集时间
        fields: 数据点信息
        fieldTypes: 数据点的类型信息. 字典, key 为数据点标识, value 为数据点类型
    """

    # 设备编号
    id: str
    # 子设备编号
    cid: str = ""
    # 设备所属工作表标识
    table: str
    # 时间
    time: int = 0
    # 数据点信息
    fields: List[Field]
    # 数据点的类型信息
    fieldTypes: dict[str, FieldType] = {}

    def __str__(self):
        return "Point(id={}, cid={}, table={}, time={}, fields={}, fieldTypes={})".format(
            self.id, "" if self.cid is None else self.cid,
            self.table, self.time,
            self.fields, self.fieldTypes
        )


class SimplePoint:
    """
    上报设备采集数据到平台时最终发送信息.
    """
    # 设备编号
    id: str
    # 子设备编号
    cid: Optional[str]
    # 设备所属工作表标识
    table: str
    # 时间
    time: int
    # 数据点信息
    fields: dict[str, any]
    # 数据点的类型信息
    fieldTypes: dict[str, FieldType]

    def __init__(self, table_id: str, device_id: str, fields: dict[str, any], cid: str = None, time: int = None,
                 field_types: dict[str, FieldType] = None):
        self.id = device_id
        self.cid = cid
        self.table = table_id
        self.time = time
        self.fields = fields
        self.fieldTypes = field_types

    def __str__(self):
        return "SimplePoint(id={}, cid={}, table={}, time={}, fields={}, fieldTypes={})".format(
            self.id, self.cid, self.table, self.time, self.fields, self.fieldTypes
        )
