from . import DataHandler
from ..model.tag import Tag


class ByteToHexDataHandler(DataHandler):
    """
    字节数组转十六进制字符串, 并且在字符串前面加上 hex__ 前缀
    """
    
    def name(self) -> str:
        return "字节数组转十六进制字符串"

    def support(self, table_id: str, device_id: str, tag: Tag, value: any) -> bool:
        if tag is None or value is None:
            return False
        # 数据点的值为字节数组
        return isinstance(value, bytes) or isinstance(value, bytearray)

    async def handle(self, table_id: str, device_id: str, tag: Tag, value: any) -> dict[str, any]:
        if isinstance(value, bytes):
            bytes_value: bytes = value
            return {tag.id: "hex__{}".format(bytes_value.hex())}
        elif isinstance(value, bytearray):
            bytes_value: bytearray = value
            return {tag.id: "hex__{}".format(bytes_value.hex())}

    def order(self) -> int:
        return 10000
