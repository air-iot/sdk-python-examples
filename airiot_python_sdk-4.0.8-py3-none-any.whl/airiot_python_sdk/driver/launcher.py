import asyncio
import json
import logging
import traceback
from asyncio import CancelledError
from concurrent.futures.thread import ThreadPoolExecutor
from enum import Enum
from typing import Optional, Callable

import grpc
from grpc.aio import Metadata

from airiot_python_sdk.driver import DriverAppFactory, DriverApp
from airiot_python_sdk.driver.protos.driver_pb2 import SchemaResult, RunResult, StartResult, HealthCheckRequest, \
    HealthCheckResponse, \
    HttpProxyResult
from airiot_python_sdk.driver.protos.driver_pb2_grpc import DriverServiceStub, DriverService
from .config import DriverConfig, DataSenderType
from .handler import DataHandlerChain, DataHandler
from .handler.boolean_to_integer_handler import BooleanToIntegerDataHandler
from .handler.bytes_to_hex_handler import ByteToHexDataHandler
from .handler.convert_value_handler import ConvertValueDataHandler
from .handler.invalid_range_value_handler import InvalidRangeValueDataHandler
from .handler.round_and_scale_handler import RoundAndScaleDataHandler
from .handler.valid_range_value_handler import ValidRangeValueDataHandler
from .service import DataSender
from .service.kafka_data_sender import KafkaDataSender
from .service.mqtt_data_sender import MQTTDataSender

logger = logging.getLogger("launcher")


class DriverState(Enum):
    """
    驱动的运行状态

    0: Stopped 停止
    1: Starting 启动中
    2: Started 已启动
    """
    Stopped = 0
    Starting = 1
    Started = 2


class DriverLauncher:
    """
    驱动启动器
    """

    json_encoder = json.JSONEncoder()

    executor: ThreadPoolExecutor
    loop: asyncio.AbstractEventLoop

    # listener
    channel: Optional[grpc.aio.Channel]
    servicer: DriverService
    stream_servicer: DriverServiceStub

    # custom data handlers
    data_handlers: list[DataHandler] = []
    # data sender
    data_sender: DataSender

    project_id: str
    # 驱动配置
    config: DriverConfig
    # 驱动实例工厂
    factory: DriverAppFactory
    # 驱动实例
    app: DriverApp

    # 驱动的运行状态
    state: DriverState = DriverState.Stopped

    def __init__(self, config: DriverConfig, factory: DriverAppFactory):
        self.project_id = config.project_id
        self.config = config
        self.factory = factory
        self.channel = None
        self.data_handlers = []
        self.stop_request_fired = asyncio.Event()

    def add_data_handler(self, handlers: list[DataHandler]):
        """
        添加自定义数据处理器.
        :param handlers: 自定义数据处理器列表
        :return:
        """
        self.data_handlers.extend(handlers)

    async def start(self):
        if self.state != DriverState.Stopped:
            logger.info("driver is running")
            return

        self.state = DriverState.Starting

        # connect data sender
        self.__connect_data_sender()

        # create driver app
        self.app = self.factory.create(service_id=self.config.service_id, data_sender=self.data_sender)

        await self.__connect__()

        # change state to started
        self.state = DriverState.Started

        # wait for stop signal
        try:
            await self.stop_request_fired.wait()
        except CancelledError:
            pass

    async def stop(self):
        logger.info("stopping driver")

        if self.state == DriverState.Stopped:
            return

        self.state = DriverState.Stopped

        # send stop signal
        self.stop_request_fired.set()

        # stop driver app
        await self.app.stop()

        # stop data sender
        self.data_sender.stop()

        if self.channel is not None:
            logger.debug("closing grpc channel")
            await self.channel.close(grace=5)

        logger.info("grpc channel closed")

        logger.info("driver stopped")

    async def __connect__(self):

        # 如果驱动已被关闭，则不再处理
        if self.state == DriverState.Stopped:
            return

        # 关闭现有的 channel
        if self.channel is not None:
            await self.channel.close(grace=5)

        # connect to driver
        await self.__connect_grpc__()

        # create all streams
        self.__create_streams__()

    def __create_streams__(self):
        logger.info("start to create streams")

        loop = asyncio.get_event_loop()

        # tasks = [loop.create_task(self.__schema_stream__()),
        #          loop.create_task(self.__run_stream__()),
        #          loop.create_task(self.__batch_run_stream__()),
        #          loop.create_task(self.__write_tag_stream__()),
        #          loop.create_task(self.__debug_stream__()),
        #          loop.create_task(self.__start_stream__()),
        #          loop.create_task(self.__health_check__(self.__connect__))
        #          ]

        loop.create_task(self.__schema_stream__()),
        loop.create_task(self.__run_stream__()),
        loop.create_task(self.__batch_run_stream__()),
        loop.create_task(self.__write_tag_stream__()),
        loop.create_task(self.__debug_stream__()),
        loop.create_task(self.__start_stream__()),
        loop.create_task(self.__health_check__(self.__connect__))

        if self.app.http_proxy_enabled():
            # tasks.append(loop.create_task(self.__http_proxy_stream__()))
            loop.create_task(self.__http_proxy_stream__())

        self.state = DriverState.Started

        # asyncio.gather(*tasks, return_exceptions=True)

    def __grpc_metadata__(self):
        """
        生成 grpc metadata
        :return:
        """

        metadata = Metadata()
        metadata.add("projectid", self.project_id.encode("utf-8").hex())
        metadata.add("driverid", self.config.id.encode("utf-8").hex())
        metadata.add("drivername", self.config.name.encode("utf-8").hex())
        metadata.add("serviceid", self.config.service_id.encode("utf-8").hex())
        return metadata

    async def __connect_grpc__(self):
        """
        连接平台 driver 服务
        :return:
        """

        grpc_config = self.config.driver_grpc
        logger.info("connect to driver: grpc://{}:{}".format(grpc_config.host, grpc_config.port))
        self.channel = grpc.aio.insecure_channel("{}:{}".format(grpc_config.host, grpc_config.port))
        self.stream_servicer = DriverServiceStub(self.channel)
        # wait for ready
        await self.channel.channel_ready()
        logger.info("connected to driver: grpc://{}:{}".format(grpc_config.host, grpc_config.port))

    async def __health_check__(self, reconnect: Callable):
        """
        健康检查
        :param reconnect: 重连方法
        :return:
        """

        interval = 30 if self.config.driver_grpc.health_check_interval <= 0 else self.config.driver_grpc.health_check_interval
        service_id = self.config.service_id
        logger.info(f"start health check: {interval}s")

        while self.state == DriverState.Started:
            try:
                tasks = asyncio.as_completed([
                    asyncio.sleep(interval),
                    self.stop_request_fired.wait()
                ])

                for task in tasks:
                    await task
                    break

                if self.state is not DriverState.Started:
                    return

                logger.info("send health check")
                resp: HealthCheckResponse = await self.stream_servicer.HealthCheck(
                    HealthCheckRequest(service=service_id))

                if resp.errors is not None and len(resp.errors) != 0:
                    for error in resp.errors:
                        logger.error("health: code = %s, message = %s", error.code, error.message)

                if resp.status == HealthCheckResponse.SERVING:
                    logger.info("health check success")
                else:
                    logger.error("health check failed, status = %s", resp.status)
                    break
            except Exception as e:
                traceback.print_exception(e)
                logger.warning("health check exception, %s", e)
                break

        await reconnect()

    async def __schema_stream__(self):
        """
        启动 schema 请求
        :return:
        """

        logger.info("create schema stream")

        metadata = self.__grpc_metadata__()
        call = self.stream_servicer.SchemaStream(metadata=metadata)
        logger.info("schema stream created, start to receive requests")

        async for request in call:
            if request == grpc.aio.EOF:
                logger.info("schema stream closed")
                break

            try:
                logger.info("receive schema request: {}".format(request.request))
                schema = await self.app.schema()
                logger.debug("receive schema request: {}, {}".format(request.request, schema))
                result = self.json_encoder.encode({"code": 200, "result": schema})
                await call.write(SchemaResult(request=request.request, message=result.encode("utf-8")))
            except Exception as e:
                traceback.print_exception(e)
                logger.error("schema request execute failed: {}, {}".format(request.request, e))
                result = self.json_encoder.encode({"code": 400, "result": "{}".format(e)})
                await call.write.put(SchemaResult(request=request.request, message=result.encode("utf-8")))

    async def __run_stream__(self):
        """
        启动 run stream
        :return:
        """

        logger.info("create run stream")

        metadata = self.__grpc_metadata__()
        call = self.stream_servicer.RunStream(metadata=metadata)

        logger.info("run stream created, start to receive requests")

        async for request in call:
            if request == grpc.aio.EOF:
                logger.info("run stream closed")
                break

            try:
                logger.info("receive run request: {}".format(request.request))
                result = await self.app.run(request.serialNo, request.tableId, request.id,
                                            request.command.decode("utf-8"))
                logger.info("receive run request: {}, result = {}".format(request.request, result))
                r = self.json_encoder.encode({"code": 200, "result": result})
                await call.write(RunResult(request=request.request, message=r.encode("utf-8")))
            except Exception as e:
                traceback.print_exception(e)
                logger.error("run request execute failed: {}, {}".format(request.request, e))
                result = self.json_encoder.encode({"code": 400, "result": "{}".format(e)})
                await call.write(RunResult(request=request.request, message=result.encode("utf-8")))

    async def __batch_run_stream__(self):
        """
        启动 batch run stream
        :return:
        """

        logger.info("create batch run stream")

        metadata = self.__grpc_metadata__()
        call = self.stream_servicer.BatchRunStream(metadata=metadata)

        logger.info("batch run stream created, start to receive requests")

        async for request in call:
            if request == grpc.aio.EOF:
                logger.info("batch run stream closed")
                break

            try:
                logger.info("receive batch run request: {}".format(request.request))
                result = await self.app.batch_run(request.serialNo, request.tableId, request.id,
                                                  request.command.decode("utf-8"))
                logger.info("receive batch run request: {}, result = {}".format(request.request, result))
                r = self.json_encoder.encode({"code": 200, "result": result})
                await call.write(RunResult(request=request.request, message=r.encode("utf-8")))
            except Exception as e:
                traceback.print_exception(e)
                logger.error("batch run request execute failed: {}, {}".format(request.request, e))
                result = self.json_encoder.encode({"code": 400, "result": "{}".format(e)})
                await call.write(RunResult(request=request.request, message=result.encode("utf-8")))

    async def __write_tag_stream__(self):
        """
        启动 write tag stream
        :return:
        """

        logger.info("create write tag stream")

        metadata = self.__grpc_metadata__()
        call = self.stream_servicer.WriteTagStream(metadata=metadata)

        logger.info("write tag stream created, start to receive requests")

        async for request in call:
            if request == grpc.aio.EOF:
                logger.info("write tag stream closed")
                break

            try:
                logger.info("receive write tag request: {}".format(request.request))
                result = await self.app.write_tag(request.serialNo, request.tableId, request.id,
                                                  request.command.decode("utf-8"))
                logger.info("receive write tag request: {}, result = {}".format(request.request, result))
                r = self.json_encoder.encode({"code": 200, "result": result})
                await call.write(RunResult(request=request.request, message=r.encode("utf-8")))
            except Exception as e:
                traceback.print_exception(e)
                logger.error("write tag request execute failed: {}, {}".format(request.request, e))
                result = self.json_encoder.encode({"code": 400, "result": "{}".format(e)})
                await call.write(RunResult(request=request.request, message=result.encode("utf-8")))

    async def __debug_stream__(self):
        """
        启动 debug stream
        :return:
        """

        logger.info("create debug stream")

        metadata = self.__grpc_metadata__()
        call = self.stream_servicer.BatchRunStream(metadata=metadata)

        logger.info("debug stream created, start to receive requests")

        async for request in call:
            if request == grpc.aio.EOF:
                logger.info("debug stream closed")
                break

            try:
                logger.info("receive debug request: {}".format(request.request))
                result = await self.app.debug(request.data.decode("utf-8"))
                logger.info("receive debug request: {}, result = {}".format(request.request, result))
                r = self.json_encoder.encode({"code": 200, "result": result})
                await call.write(RunResult(request=request.request, message=r.encode("utf-8")))
            except Exception as e:
                traceback.print_exception(e)
                logger.error("debug request execute failed: {}, {}".format(request.request, e))
                result = self.json_encoder.encode({"code": 400, "result": "{}".format(e)})
                await call.write(RunResult(request=request.request, message=result.encode("utf-8")))

    async def __start_stream__(self):
        """
        启动 start stream
        :return:
        """

        logger.info("create start stream")

        metadata = self.__grpc_metadata__()
        call = self.stream_servicer.StartStream(metadata=metadata)

        logger.info("start stream created, start to receive requests")

        async for request in call:
            if request == grpc.aio.EOF:
                logger.info("start stream closed")
                break

            try:
                logger.info("receive start request: {}".format(request.request))
                config = request.config.decode("utf-8")
                logger.debug("receive start request: {}, {}".format(request.request, config))

                await self.app.start(config)

                logger.info("listener start stream: {}, started".format(request.request))
                r = self.json_encoder.encode({"code": 200, "result": "OK"})
                await call.write(StartResult(request=request.request, message=r.encode("utf-8")))
            except Exception as e:
                traceback.print_exception(e)
                logger.error("listener start stream: {}, {}".format(request.request, e))
                result = self.json_encoder.encode({"code": 400, "result": "{}".format(e)})
                await call.write(StartResult(request=request.request, message=result.encode("utf-8")))

    async def __http_proxy_stream__(self):
        """
        启动 http proxy stream
        :return:
        """

        logger.info("create http proxy stream")
        metadata = self.__grpc_metadata__()
        call = self.stream_servicer.HttpProxyStream(metadata=metadata)

        logger.info("http proxy stream created, start to receive requests")

        async for request in call:
            if request == grpc.aio.EOF:
                logger.info("http proxy stream closed")
                break
            try:
                logger.info("receive http proxy request: %s, type: %s, headers: %s, data: %s", request.request,
                            request.type, request.headers, request.data)
                result = await self.app.http_proxy(request.type, request.headers, request.data.decode("utf-8"))
                logger.info("receive http proxy request: %s, result = %s", request.request, result)
                result = self.json_encoder.encode({"code": 200, "result": result})
                await call.write(HttpProxyResult(request=request.request, data=result.encode("utf-8")))
            except Exception as e:
                traceback.print_exception(e)
                logger.error("http proxy request execute failed: %s, %s", request.request, e)
                result = self.json_encoder.encode({"code": 400, "result": "{}".format(e)})
                await call.write(HttpProxyResult(request=request.request, data=result.encode("utf-8")))

    def __connect_data_sender(self):
        """
        连接数据发送器
        :return:
        """

        logger.info("connect to data sender")

        config = self.config.data

        # builtin data handlers
        handlers = [
            RoundAndScaleDataHandler(),
            ConvertValueDataHandler(),
            ValidRangeValueDataHandler(),
            InvalidRangeValueDataHandler(),
            BooleanToIntegerDataHandler(),
            ByteToHexDataHandler(),
        ]

        # add custom data handlers to chain
        if len(self.data_handlers) != 0:
            handlers.extend(self.data_handlers)

        handler_chain = DataHandlerChain(handlers)

        if config.type == DataSenderType.MQTT:
            self.data_sender = MQTTDataSender(self.project_id, self.config.id, self.config.name, self.config.service_id,
                                              config.mqtt, handler_chain)
            self.data_sender.start()
            logger.info("mqtt data sender connected")
        elif config.type == DataSenderType.KAFKA:
            self.data_sender = KafkaDataSender(self.project_id, self.config.id, self.config.name,
                                               self.config.service_id,
                                               config.kafka, handler_chain)
            self.data_sender.start()
            logger.info("kafka sender connected")
        else:
            raise ValueError("不支持的数据发送类型: {}".format(config.type))
