import argparse
import asyncio
import logging
import os.path
import signal
import threading
from typing import Optional

import jsons
import yaml

from airiot_python_sdk.driver import DriverAppFactory
from airiot_python_sdk.driver.config import DriverConfig, DataSenderType
from airiot_python_sdk.driver.launcher import DriverLauncher

parser = argparse.ArgumentParser("启动驱动")
parser.add_argument('--config', type=str, dest='config', default="config.yml",
                    help='配置文件路径 (default: 当前目录下的 config.yml 文件)')

parser.add_argument('--id', type=str, dest='id', help='驱动ID')
parser.add_argument('--name', type=str, dest='name', help='驱动名称')

parser.add_argument('--project', type=str, dest='project', help='驱动所属项目ID')
parser.add_argument('--serviceId', type=str, dest='serviceId', help='驱动实例ID')
parser.add_argument('--groupId', type=str, dest='groupId', help='驱动实例组ID')

parser.add_argument('--log-level', type=str, dest='logLevel', default="INFO",
                    help='日志等级, 可选项有 DEBUG, INFO, WARNING, ERROR (default: INFO)')


def run_loop(launcher: DriverLauncher, main_loop: asyncio.AbstractEventLoop):
    asyncio.set_event_loop(main_loop)
    main_loop.create_task(launcher.start())
    main_loop.run_forever()

class Startup:
    """
    服务启动类
    """

    # 驱动ID
    id: Optional[str] = None
    # 驱动名称
    name: Optional[str] = None

    # 驱动所属项目ID
    project: Optional[str] = None
    # 驱动实例ID
    service_id: Optional[str] = None
    # 驱动实例组ID
    group_id: Optional[str] = None

    # 日志等级
    log_level: str = "INFO"

    log_format: str = '%(asctime)s %(levelname)5s --- [%(module)20s]: %(message)s'

    def __init__(self, id: str = None, name: str = None, log_level: str = None):
        self.id = id
        self.name = name
        self.log_level = log_level

    def load_config(self, path):
        if not os.path.exists(path):
            return

        with open(path, 'r', encoding="utf-8") as f:
            config = yaml.load(f, yaml.FullLoader)

            if "driver-grpc" in config:
                config["driver_grpc"] = config["driver-grpc"]
                del config["driver-grpc"]

            if "log-level" in config:
                self.log_level = config["log-level"]

            return jsons.load(config, cls=DriverConfig)

    def parse(self) -> DriverConfig:
        command_line = parser.parse_args()

        # 如果设置了配置文件, 则加载配置文件
        if command_line.config is not None:
            config = self.load_config(command_line.config)
        else:
            config = DriverConfig()

        # 其它命令行参数优先级高于配置文件
        if command_line.id is not None:
            self.id = command_line.id
            config.id = command_line.id
        if command_line.name is not None:
            self.name = command_line.name
            config.name = command_line.name
        if command_line.project is not None:
            self.project = command_line.project
            config.project_id = command_line.project
        if command_line.serviceId is not None:
            self.service_id = command_line.serviceId
            config.service_id = command_line.serviceId
        if command_line.logLevel is not None:
            self.log_level = command_line.logLevel
        if command_line.groupId is not None:
            self.group_id = command_line.groupId

        mq_type = os.getenv("MQ.TYPE")
        if mq_type is None or mq_type == "mqtt" or mq_type == "MQTT":
            mqtt_scheme = os.getenv("MQ.MQTT.SCHEMA")
            mqtt_host = os.getenv("MQ.MQTT.HOST")
            mqtt_port = os.getenv("MQ.MQTT.PORT")
            mqtt_username = os.getenv("MQ.MQTT.USERNAME")
            mqtt_password = os.getenv("MQ.MQTT.PASSWORD")
            mqtt_skip_verify = os.getenv("MQ.MQTT.TLSCONFIG.INSECURESKIPVERIFY")

            config.data.type = DataSenderType.MQTT
            if mqtt_scheme is not None:
                config.data.mqtt.scheme = DataSenderType.MQTT
            if mqtt_host is not None:
                config.data.mqtt.host = mqtt_host
            if mqtt_port is not None:
                config.data.mqtt.port = int(mqtt_port)
            if mqtt_username is not None:
                config.data.mqtt.username = mqtt_username
            if mqtt_password is not None:
                config.data.mqtt.password = mqtt_password
            if mqtt_skip_verify is not None:
                config.data.mqtt.skip_verify = bool(mqtt_skip_verify)

        return config

    def run(self, factory: DriverAppFactory, driver_config: DriverConfig = None):
        if driver_config is None:
            driver_config = self.parse()

        logging.basicConfig(level=self.log_level, format=self.log_format)
        logger = logging.getLogger("startup")

        logger.info("启动驱动: %s", driver_config.id)

        launcher = DriverLauncher(driver_config, factory)

        main_loop = asyncio.new_event_loop()
        main_thread = threading.Thread(target=run_loop, args=(launcher, main_loop,), name="driver", daemon=True)
        main_thread.start()

        loop = asyncio.get_event_loop()
        stop_event = asyncio.Event()

        def raise_graceful_exit(sig, frame):
            logger.info("接收到退出信号")
            stop_event.set()

        signal.signal(signal.SIGINT, raise_graceful_exit)
        signal.signal(signal.SIGTERM, raise_graceful_exit)

        try:
            loop.run_until_complete(stop_event.wait())
        except KeyboardInterrupt:
            print("退出了")

        loop.run_until_complete(launcher.stop())
